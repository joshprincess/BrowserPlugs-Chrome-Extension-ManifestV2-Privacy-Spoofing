/*
uetq.addHiddenFields
function(n,t,i,r){var e="",u,f;r&&(e=r+".");for(u in n)n.hasOwnProperty(u)&&(typeof n[u]=="object"?this.addHiddenFields(n[u],t,i,e+u):(f=i.createElement("input"),f.setAttribute("type","hidden"),f.setAttribute("name",e+u),f.setAttribute("value",n[u]),t.appendChild(f)))}


uetq.addFraudSignals

function(n){n=this.addPluginData(n);var t=window.navigator.userLanguage||window.navigator.language;return this.stringExists(t)&&(n.lg=t),screen&&(screen.width&&(n.sw=screen.width),screen.height&&(n.sh=screen.height),screen.colorDepth&&(n.sc=screen.colorDepth)),n}






*/
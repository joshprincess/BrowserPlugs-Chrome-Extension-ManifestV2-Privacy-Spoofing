/* 
window:

window.fbAsyncInit
window.sa.
window.tagId "2620110758307"
uetq

rollbar
rollbar
rollbarTokens:
cpg: "081c6eec6350447abe62a5399142d394"
customers: "9a3c2ba0556b4149a1126f4497f9eafb"
default: "9a3c2ba0556b4149a1126f4497f9eafb"
growth: "6fe2c91404af425487f2e681362e7987"
orders: "9d22298dd5844e84846f935046c1a82f"
partners: "081c6eec6350447abe62a5399142d394"
retailers: "47dbe87c1a6b4865ae9a0ac8d9ff2fa0"
search: "20c1f1f2885845559a4c99c41a17ed9f"

superProps:
ahoy_visit_token: "1768d650-06b1-46ba-aab8-a0d731306e30"
ahoy_visitor_token: "b78c0d4e-a39a-4885-be32-a31883dd85f2"
is_new_user: false
platform: "web"
referrer_domain: "https://www.safeway.com/"
whitelabel_retailer: "safeway"

add : function(n){n=this.addPluginData(n);var t=window.navigator.userLanguage||window.navigator.language;return this.stringExists(t)&&(n.lg=t),screen&&(screen.width&&(n.sw=screen.width),screen.height&&(n.sh=screen.height),screen.colorDepth&&(n.sc=screen.colorDepth)),n}
uetq.beaconParams.mid


function(n,t,i,r){var u=0,f=t,e=i===undefined||i===0?!0:!1;return t.toString().indexOf(",")!==-1&&(f=t.replace(/,/g,"")),u=parseFloat(f),(isNaN(f)||isNaN(u)||e&&u.toString().indexOf(".")!==-1)&&this.throwError(n+" should be "+(e?"an integer":"a number")),u>r?this.throwError(n+" cannot be greater than "+r):u<0?this.throwError(n+" cannot be less than 0"):this.getDecimalPlaces(u)>i&&this.throwError(n+" cannot have more than "+i+" decimal places"),u}

*/


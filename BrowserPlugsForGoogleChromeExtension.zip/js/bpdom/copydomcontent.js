/*
 * Name: Copy DOM Content
 * Version: 1.0
 * Author: QoSMicro.com
 * Copyright (c) 2016 QoSMicro.com
 * Licensed under http://opensource.org/licenses/MIT
 */

// Get the current Tab.
function getCurrentTab( callback ) {
	"use strict";

	// Query filter to be passed to chrome.tabs.query - see
	// https://developer.chrome.com/extensions/tabs#method-query
	var queryInfo = {
		active: true,
		currentWindow: true
	};

	chrome.tabs.query( queryInfo, function( tabs ) {
		var tab = tabs[0];
		callback( tab );
	});

}

// Renders Message to Window.
function renderStatus(statusText) {
	"use strict";
	document.getElementById('status').innerHTML = statusText;
}

// Button Was Clicked
document.addEventListener('DOMContentLoaded', function() {
	"use strict";
	
	// Get tab data
	getCurrentTab( function( tab ) {
		
		renderStatus( 'Reading DOM...' );

		// Send a message specifying a callback too
		chrome.tabs.sendMessage( tab.id, {text: 'report_back'},  function( copiedContent ) { 

			if( copiedContent !== undefined ) {

				var displayResult = document.getElementById('results');
				displayResult.value = '<!-- Copied from: ' + tab.url + ' -->\n' + copiedContent;
				displayResult.select();
				try {

					document.execCommand('copy');
					renderStatus( 'DOM has been copied to the clipboard!' );
					setTimeout( function() { window.close(); }, 2000 );

				} catch( exception ) {

					document.getElementById('status').className = 'error';
					document.getElementById('results').className = 'error';
					renderStatus( 'Please press Ctrl/Cmd+C to copy.' );

				}
			
			} else {

					document.getElementById('status').className = 'error';
					renderStatus( 'No content could be copied.' );

			}

		});

	});

});











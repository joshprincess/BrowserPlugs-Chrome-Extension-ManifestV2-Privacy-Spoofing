

   if (window.rollbar) { 
   console.log('Browser Plugs removes window.rollbar');
  window.rollbar = [];
      window.rollbar = undefined;
   
   }
   
   if (window._rollbarShims) { 
   console.log('Browser Plugs removes window._rollbarShims');
  window._rollbarShims = [];
      window._rollbarShims = undefined;
   
   }
   


   if (window.ADBLOCK_DETECTED) { 
   console.log('Browser Plugs removes window.ADBLOCK_DETECTED');
   window.ADBLOCK_DETECTED = [];
       window.ADBLOCK_DETECTED = undefined;
   
   }
   
   
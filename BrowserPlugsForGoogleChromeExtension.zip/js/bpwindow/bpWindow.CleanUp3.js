   if (window.ftr__startScriptLoad) { 
   console.log('Browser Plugs removes window.ftr__startScriptLoad');
  window.ftr__startScriptLoad = [];
      window.ftr__startScriptLoad = undefined;
   
   }
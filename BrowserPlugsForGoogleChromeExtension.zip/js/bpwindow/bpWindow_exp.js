  window.__do_not_use_me_isNodeRendered


   if (window.twttr) { 
   console.log('Browser Plugs removes window.twttr');
   window.twttr = [];
       window.twttr = undefined;
   
   }
   if (window.analytics) { 
   console.log('Browser Plugs removes window.analytics');
  window.analytics = [];
       window.analytics = undefined;
   
   }
      if (window.fbAsyncInit) { 
   console.log('Browser Plugs removes window.fbAsyncInit');
  window.fbAsyncInit = [];
       window.fbAsyncInit = undefined;
   
   }
   
   
   
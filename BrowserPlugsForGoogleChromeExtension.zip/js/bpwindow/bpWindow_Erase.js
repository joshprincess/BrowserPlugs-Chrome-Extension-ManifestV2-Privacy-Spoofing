  window._ic_event_super_props = 
  window.user_channel_props.user_channel_1
  
  window.__do_not_use_me_isNodeRendered
  
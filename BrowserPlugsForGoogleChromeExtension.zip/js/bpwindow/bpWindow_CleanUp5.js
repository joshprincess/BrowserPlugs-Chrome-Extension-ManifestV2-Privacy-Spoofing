

   if (window._rollbarWrappedError) { 
   console.log('Browser Plugs removes window._rollbarWrappedError');
  window._rollbarWrappedError = [];
      window._rollbarWrappedError = undefined;
   
   }
   
   
!window._laq
 delete window.gapi._bs;
/* 


        if (!window._laq) { window._laq = []; }
        window._laq.push(function () {
            liveagent.showWhenOnline('573f4000000QdKw', document.getElementById('liveagent_button_online_573f4000000QdKw'));
            liveagent.showWhenOffline('573f4000000QdKw', document.getElementById('liveagent_button_offline_573f4000000QdKw'));
        });
    
	
	*/
	
	
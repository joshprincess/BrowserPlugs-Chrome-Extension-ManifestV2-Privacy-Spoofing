(function () {


console = function(message, source, lineno, colno, error) { 

 return false;
};

console.warn = function(message, source, lineno, colno, error) { 

 return false;
};
console.log = function(message) { 
 return false;
};
console.error = function(message, source, lineno, colno, error) { 
 return false;
};
console.info = function(message,) { 
 return false;
};
console.trace = function(message,) { 
 return false;
};
console.clear = function() { 
 return false;
};
console.assert = function() { 
 return false;
};
console.timeEnd = function() { 
 return false;
};
console.groupEnd = function() { 
 return false;
};
console.group = function() { 
 return false;
};
console.table = function() { 
 return false;
};
 })()

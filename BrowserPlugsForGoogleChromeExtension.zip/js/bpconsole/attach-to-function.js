console.log = function(msg) {
    // Add whatever you want here
    alert(msg); 
}
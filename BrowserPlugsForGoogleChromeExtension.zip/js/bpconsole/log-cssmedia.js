function getCSSMediaRules() {
    var stylesheets = document.styleSheets;
    var mediaRules = new Array();

    // loop through all CSS files
    for (var i in stylesheets) {
        if (stylesheets.hasOwnProperty(i)) {
            var stylesheets = stylesheets[i];
            var stylesheetRules = stylesheets.cssRules;
            // for every CSS file, loop through all CSS rules
            for (var i in stylesheetRules) {
                if (stylesheetRules.hasOwnProperty(i)) {
                    var stylesheetRule = stylesheetRules[i];
                    // check CSS rule is a type 4 'MEDIA_RULE'
	
                    if (stylesheetRule.type == 4) {
							mediaStringify = JSON.stringify(stylesheetRule);
													console.log (stylesheetRule);
                            mediaRules.push(stylesheetRule);

                    }
                }
            }
        }
    }
	/* console.log ('[BP Detailed Log is ON] Page Media Rules:'); */	

    return mediaRules;

}
/*  console.log ('[BP Detailed Log is ON] Document StyleSheets:');  */
console.log(document.styleSheets[0]);
/* console.log(document.styleSheets[0].media.mediaText); */

function replaceMaxDeviceWidth(rule) {
    rule.media.mediaText = rule.media.mediaText.replace('max-device-width', 'max-width');
}
/*  getCSSMediaRules();  */


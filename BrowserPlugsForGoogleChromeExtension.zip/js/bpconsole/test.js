
function getContent( docDOM ) {
 	"use strict";

	var cloneDOM = docDOM.cloneNode(true);
	var framesDoc = docDOM.getElementsByTagName('iframe');
	var framesClone = cloneDOM.getElementsByTagName('iframe');

	if( framesClone.length > 0 ) {

		for( var i = 0; i < framesClone.length; i++ ) {

			try {

				var newContent = framesDoc[i].contentDocument;
				var divWrap = document.createElement('div');
				divWrap.id = framesDoc[i].id;
				divWrap.style.cssText = framesDoc[i].style.cssText;
				divWrap.className = framesDoc[i].className + ' original_iframe';
				if( framesDoc[i].width!=='' && divWrap.style.width==='' ) { divWrap.style.width = framesDoc[i].width + 'px'; }
				if( framesDoc[i].height!=='' && divWrap.style.height==='' ) { divWrap.style.height = framesDoc[i].height + 'px'; }
				divWrap.innerHTML = getContent( newContent );
				framesClone[i].outerHTML = divWrap.outerHTML;

			} catch( exception ) {
				
				// Return Original iFrame HTML

			}

		}

	}
	return cloneDOM.all[0].outerHTML;

}
try { document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { document.documentElement.dataset.acxscriptallow = true; } catch(e) { }


try { window.document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { window.document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { window.document.documentElement.dataset.acxscriptallow = true; } catch(e) { }

try { top.window.document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { top.window.document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { top.window.document.documentElement.dataset.acxscriptallow = true; } catch(e) { }



try { document.removeAttribute('sandbox'); } catch(e) { }
try { document.body.style.backgroundColor = "cyan"; } catch(e) { }

try { window.document.removeAttribute('sandbox'); } catch(e) { }
try { window.document.body.style.backgroundColor = "orange"; } catch(e) { }
try { top.window.document.removeAttribute('sandbox'); } catch(e) { }
try { top.window.document.body.style.backgroundColor = "navy"; } catch(e) { }

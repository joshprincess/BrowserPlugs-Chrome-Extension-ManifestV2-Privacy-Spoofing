	(function() { 
var oldXHROpen = window.XMLHttpRequest.prototype.open;
window.XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
         
		  console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [XMLHttpRequest.open on ' + window.location.hostname + ']  Method: [' + method + ']  async: [' + async + '] user: [' + user +'] ', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
                console.log('XML HTTP Request open URL: ' + decodeURIComponent(url));

 return oldXHROpen.apply(this, arguments);
}


var oldXHRSend = window.XMLHttpRequest.prototype.send;
window.XMLHttpRequest.prototype.send = function(body) {
JSON.stringify(body);
console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [XMLHttpRequest.send] [Body] ' + decodeURIComponent(body) + ' ', 'color: black; background-color: #b782b7; border: 2px solid black; padding: 5px;');
return oldXHRSend.apply(this, arguments);
}

var oldbtoa = window.btoa;
window.btoa = function(name) {
	   var myJSON = JSON.stringify(arguments);
	   console.log('[Browser Plugs Detailed Log] window.btoa  ' + window.location.hostname);
	  console.log(name);
	  console.log(myJSON);
	  return oldbtoa.apply(this, arguments);
	  }
	  

})();
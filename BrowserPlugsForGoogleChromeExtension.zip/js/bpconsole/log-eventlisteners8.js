var original_Window_addEventListener;
var original_Node_addEventListener;

    original_Window_addEventListener = window.addEventListener;
    original_Node_addEventListener = Node.prototype.addEventListener;
    
    window.addEventListener = function _window_addEventListener(event, listener, useCapture) {
   
	 console.log("window.addEventListener(" + event + ") useCapture("+JSON.stringify(useCapture)+") listener("+listener+")")
        
        if (typeof arguments[1] == "function") {
            arguments[1] = wrappedListener(event, arguments[1])
        }
        original_Window_addEventListener.apply(window, [].slice.call(arguments))
    }
    Node.prototype.addEventListener = function _Node_addEventListener(event, listener, useCapture) {
        console.log("Node.addEventListener(" + event + ") useCapture("+JSON.stringify(useCapture)+") listener("+listener+")")
        
        if (typeof arguments[1] == "function") {
            arguments[1] = wrappedListener(event, arguments[1])
        }
        original_Node_addEventListener.apply(this, [].slice.call(arguments))
    }

//--------------------------------------------------------------------
function wrappedListener(event, listener) {
    return function _wrappedListener() {
        try {
            listener.apply(this, [].slice.call(arguments))
            console.log(getStackTrace())
       
        }
        catch(e) {
            console.log("exception running event listener " + event + " for " + this + ": " + e)
            console.log("--- stack begin ---")
            console.log(e.stack)
            console.log("--- stack end ---")
            console.log("--- calc stack begin ---")
            console.log(getStackTrace())
            console.log("--- calc stack end ---")
        }
    }
}
//--------------------------------------------------------------------
function getStackTrace() {
    var result = []
    var visitedFuncs = []
    
    var func = arguments.callee.caller
    
    while (func) {
        var name = func.displayName || func.name || "<anonymous>"
        result.push(name + "()")
        if (-1 != visitedFuncs.indexOf(func)) {
            result.push("... recursion")
            break
        }
        
        visitedFuncs.push(func)
        
        func = func.caller
    }
    
    return result.join("\n")
}
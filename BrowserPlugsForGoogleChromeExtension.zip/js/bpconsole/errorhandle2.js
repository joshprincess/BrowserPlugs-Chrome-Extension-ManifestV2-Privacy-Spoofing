onerror = function(message, source, lineno, colno, error) { 
 return false;
};


(function () {
window.onerror = function(message, source, lineno, colno, error) { 
 
 return false;

};

document.onerror = function(message, source, lineno, colno, error) { 
 return false;
};


window.addEventListener('onerror', function(event) {

 window.onerror = function(){
   return false;
   
};

window.addEventListener('error', function(event) {

 window.onerror = function(){
   return false;
   
};

 })
})();
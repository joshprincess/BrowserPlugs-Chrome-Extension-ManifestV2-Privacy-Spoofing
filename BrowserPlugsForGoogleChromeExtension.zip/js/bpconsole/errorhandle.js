/* console.warn = function(message, source, lineno, colno, error) { 
 return false;
};
console.log = function(message, source, lineno, colno, error) { 
 return false;
};
*/

DOMError = function(message, source, lineno, colno, error) { 
 		 console.log('DOMError: ' + message + ' ' + source + ' ' + lineno + ' ' + colno + '  ' + error);

 return true;
};

onerror = function(message, source, lineno, colno, error) { 
 		 console.log('onerror: ' + message + ' ' + source + ' ' + lineno + ' ' + colno + '  ' + error);

 return true;
};

// throw console.error
(function () {

window.onerror = function(message, source, lineno, colno, error) { 
 		 console.log('window onerror: ' + message + ' ' + source + ' ' + lineno + ' ' + colno + '  ' + error);

 return true;

};


document.onerror = function(message, source, lineno, colno, error) { 
 		 console.log('document onerror: ' + message + ' ' + source + ' ' + lineno + ' ' + colno + '  ' + error);

 return true;
};

/*
(function () {

console.warn = function(message, source, lineno, colno, error) { 
 	 console.log('console warn: ' + message + ' ' + source + ' ' + lineno + ' colno ' + ' error ' + error);

 return true;
};
console.log = function(message) { 
  	 console.log('console log: ' + message);
	  return true;


};
console.error = function(message, source, lineno, colno, error) { 
 	 console.log('console error: ' + message + ' ' + source + ' ' + lineno + ' colno ' + ' error ' + error);

 return true;
};
console.info = function(message) { 
 	 console.log('console info: ' + message);

 return true;
};
console.trace = function(message) { 
 	 console.log('console trace: ' + message);

 return true;
};
console.clear = function() { 
 	 console.log('console clear :' + document.location.pathname);

 return true;
};
console.assert = function() { 
 	 console.log('console assert :' + document.location.pathname);

 return true;
};
console.timeEnd = function() { 
  	 console.log('console timeEnd :' + document.location.pathname);

 return true;
};
console.groupEnd = function() { 
 	 console.log('console groupEnd :' + document.location.pathname);

 return true;
};
console.group = function() { 
 	 console.log('console group :' + document.location.pathname);

 return true;
};
console.table = function() { 
 	 console.log('console table :' + document.location.pathname);

 return true;
};
window.console = function() { 
 	 console.log('window.console :' + document.location.pathname);

 return true;
};
window.console.warn = function(message, source, lineno, colno, error) { 
 	 console.log('window.console.warn :' + document.location.pathname);

 return true;
};
window.console.log = function(message) { 
 	// console.log(message);

 return true;
};
window.console.error = function(message, source, lineno, colno, error) { 
 	 console.log('window.console.error :' + document.location.pathname);

 return true;
};
window.console.info = function(message) { 
 	 console.log('window.console.info :' + document.location.pathname);

 return true;
};
window.console.trace = function(message) 
{ 
 console.log('window.console.trace :' + document.location.pathname);
 return true;
};
window.console.clear = function() { 
 	 console.log('window.console.clear :' + document.location.pathname);

 return true;
};
 })()

*/
window.addEventListener('onerror', function(event) {

 window.onerror = function(){
	  	 console.log('window.onerror event listener :');

   return true;
   
};
})

window.addEventListener('error', function(event) {

 window.onerror = function(){
	  	 console.log('window.console.onerror :');

   return true;
   
};

 })
})();
/*
(function() {

	// just place a div at top right
	var div = document.createElement('div');
	div.style.position = 'fixed';
	div.style.background = 'cyan';
	div.style.top = 3;
	div.style.right = 3;
	div.style.opacity = 0.8;
	div.textContent = 'Secure';
	document.body.appendChild(div);

})();
*/

(function() {

	// just place a div at top right
	var div = document.createElement('div');
	div.style.position = 'fixed';
	div.style.background = 'orange';
	div.style.top = 2;
	div.style.right = 2;
	div.style.opacity = 1;
	div.textContent = 'B';
	document.body.appendChild(div);

})();
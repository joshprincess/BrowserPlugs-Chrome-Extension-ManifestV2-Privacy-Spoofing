	(function() { 
var oldFunctionCall = Function.prototype.call;
Function.prototype.call = function(method, url, async, user, password) {
            var myJSON = (JSON.stringify(method));
            var myJSON2 = (JSON.stringify(url));
            var myJSON3 = (JSON.stringify(async));
			var myArguments = (JSON.stringify(arguments));
         //   var myJSON4 = JSON.stringify(user);
       // var myJSON5 = JSON.stringify(password);
		  console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Function.prototype.call on ' + window.location.hostname + '] arguments:')
		 console.log ('[' + myArguments + ']');
		 console.log ('1: [' + myJSON + '] 2: [' + myJSON2 +']  3: [' + myJSON3 +']');
//console.log('4: [' + myJSON4 +'] 5: [' + myJSON5 +'] ', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
//console.log('URL: ' + decodeURIComponent(url));

 return oldFunctionCall.apply(this, arguments);
}
	  

})();

/*
  const _nativeRemoveAttribute = Element.prototype.removeAttribute; 
 Element.prototype['removeAttribute'] = function(name) { 
   var myJSON = JSON.stringify(arguments);
  console.log('%c [BP Super Log] removeAttribute: ' + name, 'color: red; font-weight: bold;');
   return _nativeRemoveAttribute.apply(this, arguments);
 }; 
 
  const _nativeSetAttribute = Element.prototype.setAttribute; 
 Element.prototype['setAttribute'] = function(name, value) { 
      var myJSON = JSON.stringify(arguments);

     console.log('%c [BP Super Log] setAttribute: ' + name + ' Value: ' + value + ' Attributes: ' + myJSON, 'color: green; font-weight: bold;');
 return _nativeSetAttribute.apply(this, arguments);
 }; 
 
   const _nativegetClientRects = Element.prototype.getClientRects; 
 Element.prototype['getClientRects'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Super Log] getClientRects: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');

 return _nativegetClientRects.apply(this, arguments);
 }; 
  const _nativegetBoundingClientRect = Element.prototype.getBoundingClientRect; 
 Element.prototype['getBoundingClientRect'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Super Log] getBoundingClientRect: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');

 return _nativegetBoundingClientRect.apply(this, arguments);
 }; 

  
*/
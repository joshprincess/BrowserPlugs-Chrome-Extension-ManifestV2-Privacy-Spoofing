﻿var script = '';

function defineGetter(object, name, returnValue) {
  script += `Object.defineProperty(${object}, '${name}',  { configurable: true, enumerable: true, get: function() { return ${returnValue}; } });`;
}

function updateCanvas() {
  script += "HTMLCanvasElement.prototype.toDataURL = function() {return '';};";
    script += "HTMLCanvasElement.prototype.toBlob = function() {return '';};";
	   script += "HTMLCanvasElement.mozGetAsFile = function() {return '';};";
	   script += "window.HTMLCanvasElement.prototype.toDataURL = function() {return '';};";
    script += "window.HTMLCanvasElement.prototype.toBlob = function() {return '';};";
	   script += "window.HTMLCanvasElement.mozGetAsFile = function() {return '';};";
	   
	     script += "Object.defineProperty(HTMLCanvasElement.prototype, 'toDataURL', { set: function() {} });";
		 
	     script += "Object.defineProperty(HTMLCanvasElement.prototype, 'toBlob', { set: function() {} });";
}


function updateStyleDeclaration() {
  script += "Object.defineProperty(CSSStyleDeclaration.prototype, 'fontFamily', { set: function() {} });";
    script += "Object.defineProperty(CSSStyleDeclaration.prototype, 'font-Family', { set: function() {} });";
	  script += "Object.defineProperty(CSSStyleDeclaration.prototype, 'fontFamily', { set: function() {} });";
}

function updateTimezone() {
  script += 'Date.prototype.getTimezoneOffset = function() {return 0;};';
}
function noMediaDevices() {
  script += 'navigator.mediaDevices.getUserMedia = function() {return 0;};';
}

function updateDocument(url) {
  script += `window.document.__defineGetter__('referrer', function() {return '${url}';});\n`;
}

function updateHistory() {
  script += "History.prototype.__defineGetter__('length', function() {return 0;});\n";
}


function resetScript() {
  script = '';
}
		

function updateNavigator(userAgent) {
	
  defineGetter('window.navigator', 'appName', "'Netscape'");
 
    defineGetter('window.navigator', 'language', 'en-US');
  defineGetter('window.navigator', 'languages', 'en-US,en');
  defineGetter('window.navigator', 'platform', "'Win32'");
  defineGetter('window.navigator', 'plugins', '[]');
  defineGetter('window.navigator', 'product', "'Gecko'");
  defineGetter('window.navigator', 'productSub', "'20030107'");
  defineGetter('window.navigator', 'vendor', "'Google Inc.'");
  defineGetter('window.navigator', 'buildID', "''");
  defineGetter('window.navigator', 'id', "''");
   defineGetter('window.navigator', 'doNotTrack', "''");
	 defineGetter('window.navigator', 'vendorSub', "''");
	  defineGetter('window.navigator', 'vibrate', "''");
	  defineGetter('window.navigator', 'webkitPointer', "''");
	  defineGetter('window.navigator', 'registerContentHandler', "''");
 defineGetter('window.navigator', 'registerProtocolHandler', "''");
		  defineGetter('window.navigator', 'requestWakeLock', "''");

				   
}
function updateNavigatorPlug(userAgent) {
	
  defineGetter('window.navigator', 'plugins', '[]');
    	  defineGetter('window.navigator', 'webkitGetGamepads', "''");
		   defineGetter('window.navigator', 'webkitGetUserMedia', "''");
 defineGetter('window.navigator', 'mediaDevices', '[]');  

 
}
function updateNavigatorCpu(userAgent) {
  defineGetter('window.navigator', 'hardwareConcurrency',"'2'");
  defineGetter('window.navigator', 'deviceMemory', "'4'");
    	
				   
}
 function updateNavigatorNetwork(userAgent) {

  defineGetter('window.navigator', 'appName', "'Netscape'");
script += 'navigator.connection.rtt = function() {return 0;};';
			
}
function updateNavigatorAudio(userAgent) {
  defineGetter('window', 'OfflineAudioContext',"''");
  defineGetter('window', 'webkitAudioContext', "''");
  defineGetter('window', 'AudioContext', "''");
				   
}



function createScript(userAgent, url) {
  resetScript();

  updateDocument(url);
  updateHistory();
  updateNavigator(userAgent);
  updateCanvas();
  updateStyleDeclaration();
  updateTimezone();
noMediaDevices();
  return script;
}
function createPlugins(userAgent, url) {
 resetScript();
  updateNavigatorPlug(userAgent);
  return script;

}
function createCpu(userAgent, url) {
  resetScript();
  updateNavigatorCpu(userAgent);
  return script;
}
function createNetwork(userAgent, url) {
  resetScript();
  updateNavigatorNetwork(userAgent);
  return script;
}

function createAudio(userAgent, url) {
  resetScript();
  updateNavigatorAudio(userAgent);
  return script;
}

function updateContent(doc, userAgent) {
  const documentElement = (doc.head || doc.documentElement);
  const scriptElement = doc.createElement('script');

  scriptElement.textContent = createScript(userAgent, doc.URL);
  documentElement.insertBefore(scriptElement, documentElement.firstChild);
  scriptElement.parentNode.removeChild(scriptElement);
}
function updatePlugins(doc, userAgent) {
 const documentElement = (doc.head || doc.documentElement);
  const scriptElement = doc.createElement('script');

  scriptElement.textContent = createPlugins(userAgent, doc.URL);
  documentElement.insertBefore(scriptElement, documentElement.firstChild);
  scriptElement.parentNode.removeChild(scriptElement);
}
function updateCpu(doc, userAgent) {
  const documentElement = (doc.head || doc.documentElement);
  const scriptElement = doc.createElement('script');

  scriptElement.textContent = createCpu(userAgent, doc.URL);
  documentElement.insertBefore(scriptElement, documentElement.firstChild);
  scriptElement.parentNode.removeChild(scriptElement);
}
function updateNetwork(doc, userAgent) {
  const documentElement = (doc.head || doc.documentElement);
  const scriptElement = doc.createElement('script');

  scriptElement.textContent = createNetwork(userAgent, doc.URL);
  documentElement.insertBefore(scriptElement, documentElement.firstChild);
  scriptElement.parentNode.removeChild(scriptElement);
}

function updateAudio(doc, userAgent) {
  const documentElement = (doc.head || doc.documentElement);
  const scriptElement = doc.createElement('script');
try {
  scriptElement.textContent = createAudio(userAgent, doc.URL);
  documentElement.insertBefore(scriptElement, documentElement.firstChild);
  scriptElement.parentNode.removeChild(scriptElement);
}
catch(e) { /* Content Settings */ }

}




if (typeof module !== 'undefined') {
  module.exports = updateContent;
}

console.log ('Browser Plugs is enabling spellcheck and autocomplete!');


	var input_controls;	
		var all = true;
		var labels = true;
		var divs = true;
		var buttons = true;
		var input_controls = true;
		
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}

losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('input[type=radio]');
		losTextboxes = document.querySelectorAll('input[type=text]');
		losPassword = document.querySelectorAll('input[type=password]');
		losCheckboxes = document.querySelectorAll('input[type=checkbox]');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('input[type=submit]');
		losBotones = document.querySelectorAll('input[type=button]');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
		losDivs = document.getElementsByTagName("div");
	} else { losDivs = []; }
	if(labels){
		losTD = document.querySelectorAll('input[type=td]');
		losTR = document.querySelectorAll('input[type=tr]');
		losSpan = document.querySelectorAll('input[type=span]');
		losLabels = document.querySelectorAll('input[type=label]');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";
for (var i = 0; i < max; i++) {
    if (allElements[i].hasAttribute('spellcheck')) {
        allElements[i].disabled = true;
        highlightElement(allElements[i]);
    }
	    if (allElements[i].hasAttribute('autocomplete')) {
        allElements[i].autocomplete = true;
        highlightElement(allElements[i]);
    }
}

			
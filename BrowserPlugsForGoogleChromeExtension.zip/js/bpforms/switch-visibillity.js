function myFunction() {
    var x = document.getElementByTag("password");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
/*

classes:
offer-popup 
image-popup ng-scope
dialog-container
cropimage_overlay
sample_overlay
overlay-mask
stp--overlay
page-mask
resell-modal
email-overlay
overlay-inner
overlay-message

ng-click="hidePopup()"

cover

thd-overlay--hide 
thd-overlay-desktop 
thd-overlay 
thd-overlay-d983f19a
thd-overlay-a5c07553
pre-loader 
thd-overlay--hide
thd-overlay__wrapper 
segment-spinner
thd-overlay__content 
col__12-12 loading
thd-overlay-style-d983f19a


<div id="zoomSlate" style="display: block;">&nbsp;</div>
modal-backdrop
overlay
advertisement
backdrop
adblock
overlayscreen
overlay-backdrop 
overlay-backdrop-visible
disclaimerRequired
waitscreen
offer-popup 
image-popup
cropimage_overlay
sample_overlay
overlay-mask
stp--overlay
page-mask
overlayAnnouncement
ACA_Announcement_Window_Detail_Overlayer
ACA_Hide
ACA_Announcement_Window
NullBlock
NotShowLoading
OverrideTabKey
lnkBeginFocusAnn
ui-widget-overlay
ui-front
mask_iframe
iframeBlocker
page-overlay-blocker
mask_iframe
divGlobalLoadingMask
dvACADialogLayerMask
page-overlay-blocker
nav-cover
ACA_MaskDiv 
ACA_Hide
ACA_MaskDiv
Cardinal-Modal
cardinalOverlay-content
cardinalOverlay-open
Cardinal-ModalContent
mask
masked
overlay__item
overlay
overlay__social
modal-facelift 
modal in
modal-dialog
modal-content
modal-header
dialog
modal-backdrop in
modalDeliveryFeeHelp
deliveryfeehelplbl
data-backdrop = static
aria-modal = true
z-index: 29;
dialog-container
PopUpDlg
fsrModalBackdrop
overviewModalBackdrop
hidden 
hide-with-nojs
glasspaneContainer
backdrop
error-close no-outline
modal-title text-center ng-binding
modal-body error-modal-body
error.code
error-modal ng-scope
modal-content
modal-body error-modal-body
error-modal ng-scope
modal-backdrop
ui-widget-overlay
ReactModal__Overlay 
ReactModal__Overlay--after-open
 icModalOverlay

id: exitintel-overlay = erase class and style  and exitintel-popup

<div class="ui-dialog ui-widget ui-widget-content ui-corner-all ui-front ui-dialog-buttons ui-draggable" tabindex="-1" role="dialog" aria-describedby="formSubmissionErrors" aria-labelledby="ui-id-1" style="height: auto; width: 500px; top: 178.5px; left: 421px; display: block;"><div class="ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix"><span id="ui-id-1" class="ui-dialog-title">Field Validation Errors</span><button class="ui-button ui-widget ui-state-default ui-corner-all ui-button-icon-only ui-dialog-titlebar-close" role="button" aria-disabled="false" title="close"><span class="ui-button-icon-primary ui-icon ui-icon-closethick"></span><span class="ui-button-text">close</span></button></div><div id="formSubmissionErrors" style="width: auto; min-height: 0px; max-height: none; height: 201px;" class="ui-widget ui-state-error ui-corner-all ui-dialog-content ui-widget-content">
	      <p><span class="ui-icon ui-icon-alert" style="float:left; margin-right:10px;"></span><strong>Your registration request has NOT been processed successfully. Please correct any errors and re-submit your request.</strong></p>Password must be minimum 8 and maximum 20 characters; the first character must be an alpha character.It must contain at least one number, one uppercase character, one lowercase character, one special character (~! @ # $ % ^ &amp;) and must not contain more than 2 consecutive repeating characters.<br>Phone Number should be NNN-NNN-NNNN format.</div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"><div class="ui-dialog-buttonset"><button type="button" class="ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only" role="button" aria-disabled="false"><span class="ui-button-text">Ok</span></button></div></div></div>
		  
		  
<body data-inq-observer="1" class="modal-open" style="padding-right: 17px;"><div id="lightboxjs-lightboxlib" style="display: none;"><div><iframe frameborder="0" id="lightboxjs-frame-lightboxlib"></iframe></div></div><div class="lto_spinner" id="lto_spinner" aria-hidden="true" style="display: none;"></div>
	<!-- BEGIN MessageDisplay.jspf -->
<div class="modal in" id="f" aria-hidden="false" style="display: block;"><div class="modal-backdrop  in"></div>
		<div class="modal-dialog">
			<div class="modal-content text-center">
				<div class="modal-header">
					<h1 tabindex="0" class="modal-title"></h1>

					

					

					<div id="Cardinal-Modal" class="cardinalOverlay-content shadow-effect cardinalOverlay-open fade-and-drop " style="">
    <div id="Cardinal-ModalHeader">
        <div id="Cardinal-MerchantContent">
                
        </div>
        <button id="Cardinal-CloseButton" class="cardinalOverlay-closeButton close-button cardinal-hide">×</button>
    </div>
    <div id="Cardinal-ModalContent">
        
<iframe src="" id="Cardinal-CCA-IFrame" border="0" width="400" height="400" frameborder="0">
  <head></head>
  <body><div></div></body>
</iframe>
    </div>
</div>
					
*/


	var nosizecount = 0;
		var hidden_elemcount = 0;
		var stylevisibilitycount = 0;
		var hiddenelementcount = 0;
		var nonedisplaycount = 0;
		var opacitycount = 0;
		var moderncount = 0;
		
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid orange";
}
losAll = [];
col1 = [];
col2 = [];
col3 = [];

var allElements = document.getElementsByTagName("*");

var max = allElements.length;
var paint = "rgb(255,200,200)";

//if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('Element: ' + i + ' / ' + max + ' | For: ' + allElements[1].getAttribute("for") + ' | id: ' + allElements[i].getAttribute("id") + ' | Type: ' + allElements[i].type);
/*
Classes: 

.fb_hidden

Attributes:

overflow:hidden;
position:relative

*/

	var nosizecount = 0;
		var hidden_elemcount = 0;
		var stylevisibilitycount = 0;
		var hiddenelementcount = 0;
		var nonedisplaycount = 0;
		var opacitycount = 0;
		var moderncount = 0;
	var ariacount = 0;
	var ifcount = 0;
	
for (var i = 0; i < max; i++) {
    if (allElements[i].hasAttribute("zIndex")||allElements[i].removeAttribute("z-Index")||allElements[i].removeAttribute("z-index")) {
        allElements[i].removeAttribute("zIndex");
		        allElements[i].removeAttribute("z-Index");
        allElements[i].removeAttribute("z-index");

		stylevisibilitycount = stylevisibilitycount + 1;
    }
   
   
   	   	   if (allElements[i].getAttribute('id') === "form_agree") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('text')||allElements[i].type('hidden')) { 
	   allElements[i].setAttribute('value','1');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Triggered true for form_agree input')
    }
	   }
	   
	   
   	   	   if (|allElements[i].getAttribute('id') === "mask") {
         allElements[i].removeAttribute("height");
		 allElements[i].removeAttribute("width");
		 		 allElements[i].removeAttribute("position");
		 		 allElements[i].removeAttribute("style");
				 		 		 allElements[i].removeAttribute("id");

		 		 allElements[i].setAttribute("visibility","hidden");
				         allElements[i].style.visibility = "hidden";

    
	   }
   
   if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElement(allElements[i]);
				nosizecount = nosizecount + 1;

    }
	
		 allElements[i].removeAttribute('zIndex');
	
		 allElements[i].removeAttribute('z-Index');
	
	    if (allElements[i].style.hidden_elem === "none") {
        allElements[i].style.display = "block";
        highlightElementOrange(allElements[i]);
				nosizecount = nosizecount + 1;

    }
	
    if (allElements[i].type === "hidden") {
        allElements[i].type = "text";
        highlightElement(allElements[i]);
		hidden_elemcount = hidden_elemcount + 1;
    }
	
	  if (allElements[i].style.opacity === "0"||allElements[i].style.opacity === "0.0"||allElements[i].style.opacity === "0.1"||allElements[i].style.opacity === "0.2"||allElements[i].style.opacity === "0.3"||allElements[i].style.opacity === "0.10") {
        allElements[i].style.opacity = "1";
        highlightElementOrange(allElements[i]);
opacitycount = opacitycount + 1;
    }
	
	  if (allElements[i].height > "7000"||allElements[i].height === "100%" || allElements[i].style.height > "7000"||allElements[i].style.height === "100%" || ) {
        allElements[i].removeAttribute("height");
		 allElements[i].removeAttribute("width");
		 		 allElements[i].removeAttribute("position");
		 		 allElements[i].removeAttribute("style");
		 		 allElements[i].setAttribute("visibility","hidden");
				         allElements[i].style.visibility = "hidden";


   
opacitycount = opacitycount + 1;
    }
	
	
	
	
	totalcount = nosizecount + hidden_elemcount + nonedisplaycount + opacitycount + moderncount + ariacount + ifcount;
}
// hidden-sm hidden-md hidden-lg
console.log("Browser Plugs removed " + totalcount + " possible or suspected overlays. Including " + opacitycount + " elements based on size or percentages, and " + nosizecount + " block or positioned elements. There were " + stylevisibilitycount + "  zIndex properties that were found, with ");

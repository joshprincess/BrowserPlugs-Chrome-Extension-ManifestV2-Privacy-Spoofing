var noscript = document.querySelectorAll("noscript");
var head = document.getElementsByTagName("head")[0];

var content = noscript.innerHTML;
//head.removeAttributeNode(noscript);
head.innerHTML += content;
// console.log ('Browser Plugs is enabling form elements without restrictions!');



		
		var all = false;
		var labels = true;
		var divs = true;
		var buttons = true;
		var input_controls = true;
		
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid orange";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){
/*
	losTD = document.querySelectorAll('input[type=td]');
		losTR = document.querySelectorAll('input[type=tr]');
		losSpan = document.querySelectorAll('input[type=span]');
		losLabels = document.querySelectorAll('input[type=label]');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
*/		

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('a');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";
for (var i = 0; i < max; i++) {

if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('Element: ' + i + ' / ' + max + ' | For: ' + allElements[1].getAttribute("for") + ' | id: ' + allElements[i].getAttribute("id") + ' | Type: ' + allElements[i].type);

	if (allElements[i].type === "hidden") {
        allElements[i].type = "text";
		      allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('zIndex');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								  allElements[i].removeAttribute('border');
								     allElements[i].removeAttribute('protected');
									  allElements[i].removeAttribute('std-maxlength');
									   allElements[i].removeAttribute('anchor');
										allElements[i].removeAttribute('anchors');
										allElements[i].removeAttribute('dialogWidth');
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													 allElements[i].removeAttribute('overflow');
													  allElements[i].removeAttribute('margins');
													 allElements[i].removeAttribute('marginBottom');
													 	 allElements[i].removeAttribute('marginLeft');
														  allElements[i].removeAttribute('marginTop');
														  	  allElements[i].removeAttribute('override-ltr');
															   allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
															   
       highlightElementRed(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
	
	
   
	
	
	 if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed disabled attribute!')
    }
	
   if (allElements[i].hasAttribute('disabled')) {
        allElements[i].disabled = false;
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Forced false disabled value!')
    }
	/*
	
	 en_US countryUS USD src_ en st_ Smartv2 Desktop Chrome
	 
	 
	
	if (window.location.hostname === 'secure.booking.com') { bp_prepayment_policy    font-size: 160% }

*/
		 allElements[i].classList.remove('disabled');
		 	 allElements[i].classList.remove('required');
			 	 	 allElements[i].classList.remove('failed');
	
		 	 allElements[i].classList.remove('required');
			 	 	 allElements[i].classList.remove('ui-disabled');
			 
		  allElements[i].classList.remove('has-error');
    allElements[i].classList.remove('ng-invalid');
	 allElements[i].classList.remove('required-text');
 allElements[i].classList.remove('form-control--error');
  allElements[i].classList.remove('error');
   allElements[i].classList.remove('error-label');
  allElements[i].classList.remove('invalid');
  allElements[i].classList.remove('disallow');
    allElements[i].classList.remove('form-ada-error-text');
  allElements[i].classList.remove('icon-exclamation-circle');
   allElements[i].classList.remove('form-ada-error-message');
 allElements[i].classList.remove('validation-group');
   allElements[i].classList.remove('unavailable');
 allElements[i].classList.remove('problem');
 allElements[i].classList.remove('unauthorized');
  allElements[i].classList.remove('void');
   allElements[i].classList.remove('alert');
      allElements[i].classList.remove('alert-danger');
   allElements[i].classList.remove('NotEnoughLoyaltyPointsException');
  allElements[i].classList.remove('NotEnough');
  allElements[i].classList.remove('NoPoints');
  allElements[i].classList.remove('exception');
  allElements[i].classList.remove('warning');
   allElements[i].classList.remove('notready');
   allElements[i].classList.remove('incomplete');
   allElements[i].classList.remove('incompleted');
 allElements[i].classList.remove('incompleted');
  allElements[i].classList.remove('incompleted');
  
   allElements[i].classList.remove('blocked');
   allElements[i].classList.remove('notfound');
      allElements[i].classList.remove('masked');
	  					allElements[i].classList.remove('hasErrorTooltipRuleSpecific');
				allElements[i].classList.remove('hasErrorTooltipRequired');
											allElements[i].classList.remove('errloading');
										allElements[i].classList.remove('icon_warn');
							
					allElements[i].classList.remove('mask');
						allElements[i].classList.remove('untouched');
						allElements[i].classList.remove('pristine');
				allElements[i].classList.remove('locked');
		
						allElements[i].classList.remove('nc-required-js-1');
						allElements[i].classList.remove('nc-required-js-2');
						allElements[i].classList.remove('nc-required-js-3');
							allElements[i].classList.remove('required-js-1');
							
							allElements[i].classList.remove('myc-field-error');
							allElements[i].classList.remove('field-error');
		allElements[i].classList.remove('gc-disabled');
		
							
						
							allElements[i].disabled = false;
							allElements[i].enabled = true;
						
	allElements[i].classList.add('enabled');
	allElements[i].classList.add('optional');
		allElements[i].classList.add('ng-valid-required');
		allElements[i].classList.add('valid');
		allElements[i].classList.add('allowed');
		allElements[i].classList.add('unlocked');
		allElements[i].classList.add('not-void');
		allElements[i].classList.add('ng-valid');
				allElements[i].classList.add('ng-not-empty');
					allElements[i].classList.add('ng-valid-parse');
				
					allElements[i].classList.add('ng-valid-luhn');
							allElements[i].classList.add('ng-valid-pattern');
							allElements[i].classList.add('ng-valid-maxlength');
							allElements[i].classList.add('ng-valid-len');
							allElements[i].classList.add('ng-valid-validator');
							allElements[i].classList.add('ng-valid-prod-type');
							allElements[i].classList.add('aamIframeLoaded');
					 allElements[i].classList.add('loaded');
			allElements[i].classList.add('unmasked');
			
			allElements[i].classList.add('ng-dirty');
			
			allElements[i].classList.add('acceptable');
		allElements[i].classList.add('ng-enabled');
			allElements[i].classList.add('canuse');
			allElements[i].classList.add('can-use');
			allElements[i].classList.add('available');
			allElements[i].classList.add('usable');
			allElements[i].classList.add('allow');
			allElements[i].classList.add('allowedincontext');
			allElements[i].classList.add('editable');
			allElements[i].classList.add('validated');
		allElements[i].classList.add('novalidate');
		allElements[i].classList.add('ng-touched');
		allElements[i].classList.add('enough');
		allElements[i].classList.add('clickable');
				allElements[i].classList.add('enableTextSelection');
				allElements[i].classList.add('identified');
								allElements[i].classList.add('state-recognized');
				allElements[i].classList.add('state-initialized');
					allElements[i].classList.add('gc-enabled');
						allElements[i].classList.remove('disableTextSelection');
					allElements[i].classList.remove('removeFocusOutline');
					allElements[i].classList.remove('mktoRequired');
			
			/*
			
			notIE7 ms-fwt-r customScrollBar disableTextSelection mainWindow removeFocusOutline
			
			preloadDiv
			removeFocusOutline
			onerror
			
			 img svgsrc=
			 img data-bind
			 
			 img class="mobileMode"  "desktopMode"
			 
			 mktoField mktoTextField mktoHasWidth mktoRequired mktoValid
			 rich-snippet-hidden
			 <link rel="dns-prefetch" href="//fonts.googleapis.com">

			 
			ismodal
			aria-atomic
			
			unselectable = "on"
			
			
			div autoid
			div regioncontainer
			
			allElements[i].classList.remove('removeFocusOutline');
			
				allElements[i].debug = true;
					allElements[i].debugger = true;
							allElements[i].debugmode = true;

							allElements[i].admin = true;
							allElements[i].log = true;
					
								 allElements[i].classList.remove('geolocation');
						
				     	 allElements[i].classList.remove('page-loader');
		   allElements[i].classList.remove('modal-backdrop');
    allElements[i].classList.remove('spinner');
	  allElements[i].classList.remove('preloader');
	      allElements[i].classList.remove('ui-input-mobile');
		 allElements[i].classList.remove('fix-ada-iphone');
	     allElements[i].classList.remove('demo');
		     allElements[i].classList.remove('defer');
		 			allElements[i].classList.remove('noFloatingLabel');
      allElements[i].classList.remove('ghost');
							allElements[i].classList.remove('confidential');
		
	  				allElements[i].classList.remove('nc-loading-circle');
					allElements[i].classList.remove('icon_ban');
							allElements[i].classList.remove('captcha_error');
								allElements[i].classList.remove('inlinesvg');
								
								allElements[i].classList.remove('no-js');
								
						allElements[i].classList.add('standard');
		 	allElements[i].classList.add('happy');
			allElements[i].classList.add('accurate');
			allElements[i].classList.add('match');
			allElements[i].classList.add('matched');
			allElements[i].classList.add('loaded');
			allElements[i].classList.add('accuracy');
			allElements[i].classList.add('done');
			allElements[i].classList.add('complete');
					allElements[i].classList.add('ready');
		allElements[i].classList.add('confirmed');
				allElements[i].classList.add('debug');
				allElements[i].classList.add('debugmode');
				allElements[i].classList.add('admin');
				allElements[i].classList.add('staff');
					allElements[i].classList.add('loggedin');
					allElements[i].classList.add('logged-in');
					allElements[i].classList.add('member');
					allElements[i].classList.add('native');
					allElements[i].classList.add('official');
					allElements[i].classList.add('paid');
		allElements[i].classList.add('confirm');
				allElements[i].classList.add('true');
		allElements[i].classList.add('public');
					allElements[i].classList.add('normal');
			allElements[i].classList.add('working');
		allElements[i].classList.add('unused');
				allElements[i].classList.add('has-success');
			allElements[i].classList.add('working');
				allElements[i].classList.add('verified');'
				
					
					
					allElements[i].classList.add('found');
		allElements[i].classList.add('good');
		allElements[i].classList.add('root');
				
				allElements[i].classList.add('notIE8');	
				
				data-permanent="1" crossorigin="anonymous"
				
				link type=
				a
				meta
				html
				head
				meta charset="utf-8"
				
				script
				
				
				*/
				
				
				allElements[i].classList.remove('data-std-maxlength');
		allElements[i].classList.remove('data-relaxed-maxlength');
		allElements[i].classList.remove('data-cs-mask');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
	allElements[i].classList.remove('hidden_elem');
	
		
		
				allElements[i].classList.remove('icon-error');
				allElements[i].classList.remove('has-failure');
				allElements[i].classList.remove('has-fail');
				allElements[i].classList.remove('has-error');
				allElements[i].classList.remove('has-failed');
				allElements[i].classList.remove('has-errors');
					allElements[i].classList.remove('unknown');
						allElements[i].classList.remove('ws-error');
				
		allElements[i].classList.add('data-ng-enabled');
		
			if (allElements[i].hasAttribute('directionality')) {
          allElements[i].setAttribute('directionality','ltr');
		console.log(' ' + i + ' - Forced directionality attribute ltr!')
    }	

				if (allElements[i].hasAttribute('ws-modify-Unavbl')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log(' ' + i + ' - Removed ws-modify-Unavbl attribute!')
    }	
	
		if (allElements[i].hasAttribute('data-std-maxlength')) {
          allElements[i].removeAttribute('data-std-maxlength');
		console.log(' ' + i + ' - Removed data-std-maxlength attribute!')
    }	
	
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].removeAttribute('unselectable');
		console.log(' ' + i + ' - Removed unselectable attribute!')
    }	
	
						if (allElements[i].hasAttribute('data-cs-mask')) {
          allElements[i].removeAttribute('data-cs-mask');
		console.log(' ' + i + ' - Removed data-cs-mask attribute!')
    }	
	
		if (allElements[i].hasAttribute('data-relaxed-maxlength')) {
          allElements[i].removeAttribute('data-relaxed-maxlength');
		console.log(' ' + i + ' - Removed data-relaxed-maxlength attribute!')
    }	
	if (allElements[i].hasAttribute('data-mask-credit-card')) {
          allElements[i].removeAttribute('data-mask-credit-card');
		console.log(' ' + i + ' - Removed data-mask-credit-card attribute!')
    }	
	
		if (allElements[i].hasAttribute('ng-if')) {
          allElements[i].removeAttribute('ng-if');
		console.log(' ' + i + ' - Removed ng-if attribute!')
    }	
	
		if (allElements[i].hasAttribute('data-ng-if')) {
          allElements[i].removeAttribute('data-ng-if');
		console.log(' ' + i + ' - Removed data-ng-if attribute!')
    }	
	
	if (allElements[i].hasAttribute('zip-error-key')) {
          allElements[i].removeAttribute('zip-error-key');
        highlightElement(allElements[i]);
		console.log(' ' + i + ' - Removed zip-error-key attribute!')
    }	
	if (allElements[i].hasAttribute('zip-required')) {
          allElements[i].removeAttribute('zip-required');
        highlightElement(allElements[i]);
		console.log(' ' + i + ' - Removed zip-required attribute!')
    }	
	if (allElements[i].hasAttribute('onblur')) {
          allElements[i].removeAttribute('onblur');
        highlightElementRed(allElements[i]);
		console.log(' ' + i + ' - Removed blur attribute!')
    }	
		if (allElements[i].hasAttribute('keypress')) {
          allElements[i].removeAttribute('keypress');
        highlightElementRed(allElements[i]);
		console.log(' ' + i + ' - Removed keypress attribute!')
    }			
		if (allElements[i].hasAttribute('validate-submit')) {
          allElements[i].removeAttribute('validate-submit');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed validate-submit attribute!')
    }							
					if (allElements[i].hasAttribute('data-error-key')) {
          allElements[i].removeAttribute('data-error-key');
		console.log(' ' + i + ' - Removed data-error-key attribute!')
    }	
				if (allElements[i].hasAttribute('xo-error-tooltip')) {
          allElements[i].removeAttribute('xo-error-tooltip');
		console.log(' ' + i + ' - Removed xo-error-tooltip attribute!')
    }	
	
			if (allElements[i].hasAttribute('autocapitalize')) {
          allElements[i].setAttribute('autocapitalize','on');
		console.log(' ' + i + ' - Forced autocapitalize on attribute!')
    }	
	if (allElements[i].hasAttribute('autocorrect')) {
          allElements[i].setAttribute('autocorrect','on');
		// console.log(' ' + i + ' - Forced autocorrect on attribute!')
    }	
		if (!allElements[i].hasAttribute('placeholder')) {
          allElements[i].setAttribute('placeholder',allElements[i].getAttribute("id"));
		 console.log(' ' + i + ' - Added placeholder attribute!')
    }	


allElements[i].setAttribute('data-ux-jq-mouseenter','true');
allElements[i].setAttribute('data-hj-whitelist','true');
			 	 allElements[i].setAttribute('novalidate','novalidate');
	 allElements[i].setAttribute('autocomplete','on');
	 	 allElements[i].setAttribute('autocorrect','on');
		 allElements[i].setAttribute('spellcheck','on');
		  
		 
		// allElements[i].setAttribute('autocapitalize','on');

		
	 	 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
		 
		 	if (!allElements[i].hasAttribute('title')) {
          allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
		console.log(' ' + i + ' - Added title to attribute')
    }	
		 
	  if (allElements[i].hasAttribute('aria-hidden')) {
        allElements[i].setAttribute('aria-hidden',false);
			console.log(' ' + i + ' - Forced false aria-hidden value!')
    }
	
	  if (allElements[i].hasAttribute('aria-busy')) {
        allElements[i].setAttribute('aria-busy',false);
			console.log(' ' + i + ' - Forced false aria-busy value!')
    }
	
	if (allElements[i].hasAttribute('unless-feature')) {
          allElements[i].removeAttribute('unless-feature');
        highlightElement(allElements[i]);
		console.log(' ' + i + ' - Removed unless-feature attribute!')
    }
	
	
	if (allElements[i].hasAttribute('unless')) {
          allElements[i].removeAttribute('unless');
        highlightElement(allElements[i]);
		console.log(' ' + i + ' - Removed unless attribute!')
    }
	
	if (allElements[i].hasAttribute('unknown')) {
          allElements[i].removeAttribute('unknown');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed unknown attribute!')
    }
		if (allElements[i].hasAttribute('ws-error')) {
          allElements[i].removeAttribute('ws-error');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ws-error attribute!')
    }
	
	if (allElements[i].hasAttribute('data-rule-allowedincontext')) {
          allElements[i].removeAttribute('data-rule-allowedincontext');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed data-rule-allowedincontext attribute!')
    }
		if (allElements[i].hasAttribute('aria-invalid')) {
          allElements[i].removeAttribute('aria-invalid');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed aria-invalid attribute!')
    }
		if (allElements[i].hasAttribute('minlength')) {
          allElements[i].removeAttribute('minlength');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed minlength attribute!')
    }
	if (allElements[i].hasAttribute('numberonly')) {
          allElements[i].removeAttribute('numberonly');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - removed numberonly attribute!')
    }
	
	
	   if (allElements[i].hasAttribute('aria-disabled')) {
          allElements[i].removeAttribute('aria-disabled');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed aria-disabled attribute!')
    }
		   if (allElements[i].hasAttribute('aria-required')) {
          allElements[i].removeAttribute('aria-required');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed aria-disabled attribute!')
    }

	  if (allElements[i].hasAttribute('required')) {
        allElements[i].required = false;
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Forced required value to false!')
    }
	 
	
	  if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed required attribute!')
    }
	
	  if (allElements[i].hasAttribute('aria-valuemax')) {
          allElements[i].removeAttribute('aria-valuemax');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed aria-valuemax attribute!')
    }
	
	
	if (allElements[i].hasAttribute('aria-valuemin')) {
          allElements[i].removeAttribute('aria-valuemin');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed aria-valuemi attribute!')
    }
	
	
		  if (allElements[i].hasAttribute('data-rule-luhn')) {
          allElements[i].removeAttribute('data-rule-luhn');
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Removed data-rule-luhn attribute!')
    }
		  if (allElements[i].hasAttribute('ng-init')) {
          allElements[i].removeAttribute('ng-init');
        highlightElementOrange(allElements[i]);
		console.log(' ' + i + ' - Removed ng-init attribute!')
    }
		  if (allElements[i].hasAttribute('inputmode')) {
          allElements[i].removeAttribute('inputmode');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed inputmode attribute!')
    }
	
    if (allElements[i].hasAttribute('readonly')) {
        allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed readonly attribute!')
    }
		
    if (allElements[i].hasAttribute('read-only')) {
        allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed read-only attribute!')
    }
	    if (allElements[i].hasAttribute('override-pattern-js')) {
        allElements[i].removeAttribute('override-pattern-js');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed override-pattern-js attribute!')
    }
	
	
	 
	   if (allElements[i].hasAttribute('ng-required')) {
        allElements[i].removeAttribute('ng-required');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ng-required attribute!')
    }
		   if (allElements[i].hasAttribute('ng-empty')) {
        allElements[i].removeAttribute('ng-empty');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ng-empty attribute!')
    }
		   if (allElements[i].hasAttribute('ng-invalid-required')) {
        allElements[i].removeAttribute('ng-invalid-required');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ng-invalid-required attribute!')
    }
	   if (allElements[i].hasAttribute('ng-pristine')) {
        allElements[i].removeAttribute('ng-pristine');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ng-pristine attribute!')
    }
 if (allElements[i].hasAttribute('ng-untouched')) {
        allElements[i].removeAttribute('ng-untouched');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed ng-untouched attribute!')
    } 
    if (allElements[i].hasAttribute('maxLength')) {
        allElements[i].removeAttribute('maxLength');
        highlightElementGreen(allElements[i]);
				console.log(' ' + i + ' - Removed maxLength attribute!')
    }
	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed data-ng-disabled attribute!')
    }
	   if (allElements[i].hasAttribute('data-ng-minlength')) {
        allElements[i].removeAttribute('data-ng-minlength');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed data-ng-minlength attribute!')
    }
	   if (allElements[i].hasAttribute('data-ng-maxlength')) {
        allElements[i].removeAttribute('data-ng-maxlength');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed data-ng-maxlength attribute!')
    }
		   if (allElements[i].hasAttribute('data-ng-pattern')) {
        allElements[i].removeAttribute('data-ng-pattern');
        highlightElementGreen(allElements[i]);
		console.log(' ' + i + ' - Removed data-ng-pattern attribute!')
    }
	   if (allElements[i].hasAttribute('my-maxlength')) {
        allElements[i].removeAttribute('my-maxlength');
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Removed my-maxlength attribute!')
    }
	   if (allElements[i].hasAttribute('data-rule-regularexpression')) {
        allElements[i].removeAttribute('data-rule-regularexpression');
					console.log(' ' + i + ' - Removed data-rule-regularexpression attribute!')
        highlightElementGreen(allElements[i]);
    }
    if (allElements[i].hasAttribute('pattern')) {
        allElements[i].removeAttribute('pattern');
        highlightElementGreen(allElements[i]);
					console.log(' ' + i + ' - Removed pattern attribute!')
    }
    if (allElements[i].type === "email") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
    if (allElements[i].type === "url") {
        allElements[i].type = "text";
    highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
	  if (allElements[i].type === "tel") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
		  if (allElements[i].type === "inputbox") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
		  if (allElements[i].type === "password") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
		  if (allElements[i].type === "option") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' - Changed element type to text!')
    }
	
	  
	
	
	
}

			
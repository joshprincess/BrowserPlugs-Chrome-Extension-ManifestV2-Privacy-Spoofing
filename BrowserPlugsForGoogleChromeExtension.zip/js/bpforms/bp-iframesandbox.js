// console.log ('Browser Plugs is enabling form elements without restrictions!','color: green;font-weight: 500;');



		
		var all = false;
		var labels = false;
		var divs = false;
		var buttons = true;
		var input_controls = true;
		
function highlightElementPink(anElement) {
    anElement.style.border = "thin solid #e83e8c";
}
function highlightElementWhite(anElement) {
    anElement.style.border = "thin solid white";
}
function highlightElementAuto(anElement) {
   console.log('Element Debug: ' + anElement.type);

if (anElement.type === "hidden") anElement.style.border = "thin solid #dc3545";
if (anElement.type === "text") anElement.style.border = "thin solid #dc3545";



}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid #dc3545";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid #ffc107";
}
function highlightElementBlack(anElement) {
    anElement.style.border = "thin solid #343a40";
}
function highlightElementFrame(anElement) {
    anElement.style.frameborder = "thin solid #343a40";
}
function highlightElementPurple(anElement) {
    anElement.style.border = "thin solid #6f42c1";
}
function highlightElementBlue(anElement) {
    anElement.style.border = "thin dotted #007bff";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('fieldset');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";
for (var i = 0; i < max; i++) {


							
if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('%c ' + i + ' / ' + max + ' | id: ' + allElements[i].getAttribute("id") + ' | async: ' + allElements[i].async + ' | title: ' + allElements[i].getAttribute("title") + ' | alt : ' + allElements[i].getAttribute("alt") + ' | type: ' + allElements[i].type + ' ','color: blue;font-weight: 500;');

// For ALL elements, Targeted
	
	if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }

		 	if (allElements[i].hasAttribute('data-rule-allowedincontext')) {
          allElements[i].removeAttribute('data-rule-allowedincontext');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-rule-allowedincontext attribute!','color: green;font-weight: 500;')
    }
	

	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-disabled attribute!','color: green;font-weight: 500;')
    }
		 
		 
	  if (allElements[i].hasAttribute('aria-disabled')) {
          allElements[i].removeAttribute('aria-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }
	
	   if (allElements[i].getAttribute('id') === "disable_restrictions") {
        allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced disable_restrictions true')
    }
	
	  
				if (allElements[i].hasAttribute('ws-modify-Unavbl')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log('%c  ' + i + ' - Removed ws-modify-Unavbl attribute!','color: green;font-weight: 500;')
    }	
	
	
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].removeAttribute('unselectable');
		console.log('%c  ' + i + ' - Removed unselectable attribute!','color: green;font-weight: 500;')
    }	
	
	
	 if (allElements[i].hasAttribute('contenteditable')) {
          allElements[i].setAttribute('contenteditable','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced contenteditable true!','color: green;font-weight: 500;')
    }
	
			
if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }

	
	if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	
		
	if (allElements[i].hasAttribute('readonly')) {
          allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('masked')) {
          allElements[i].removeAttribute('masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed masked attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ui-disabled')) {
          allElements[i].removeAttribute('ui-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ui-disabled attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('unavailable')) {
          allElements[i].removeAttribute('unavailable');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed unavailable attribute!','color: green;font-weight: 500;')
    }
		
		 allElements[i].setAttribute('enabled');
					
	

// For ALL elements, Global *
		
							
							allElements[i].disabled = false;
							allElements[i].enabled = true;
						
  
   allElements[i].classList.remove('ui-disabled');
     allElements[i].classList.remove('ui-state-disabled');
 allElements[i].classList.remove('disabled');
			 allElements[i].classList.remove('unavailable');	
			 	 allElements[i].classList.remove('ui-state-disabled');
						// The global added styles
						
					
				
		
		allElements[i].classList.add('data-ng-enabled');
		allElements[i].classList.add('ng-enabled');
			allElements[i].classList.add('canuse');
			allElements[i].classList.add('can-use');
			allElements[i].classList.add('available');
			allElements[i].classList.add('usable');
			allElements[i].classList.add('allow');
			allElements[i].classList.add('allowedincontext');
			allElements[i].classList.add('editable');
		allElements[i].classList.add('clickable');
				allElements[i].classList.add('enableTextSelection');
						allElements[i].classList.add('allowTextSelection');
					

	allElements[i].classList.add('enabled');
		allElements[i].classList.add('allowed');
		allElements[i].classList.add('unlocked');
					
					allElements[i].classList.add('gc-enabled');	
		allElements[i].classList.remove('inactive');	
				
	
				
allElements[i].classList.add('toggle-edit');	

	

		 
		 	 allElements[i].classList.remove('read-only');	
			 	 allElements[i].classList.remove('ui-disabled');	
		 			allElements[i].classList.remove('disableTextSelection');
	allElements[i].classList.remove('disableSelection');
	allElements[i].classList.remove('restricted');
					
			 	 	 allElements[i].classList.remove('ui-disabled');		
 
        allElements[i].classList.remove('masked');
		allElements[i].classList.remove('hide-focus');
 allElements[i].classList.remove('unavailable');
  allElements[i].classList.remove('disallow');
					allElements[i].classList.remove('mask');
					
				allElements[i].classList.remove('locked');
						

				
		 allElements[i].classList.remove('disabled');
		 	
		
			

	
// FOR IFRAME

	if (allElements[i].type === "iframe"||allElements[i].type === "frame") {
			
			 if (allElements[i].hasAttribute('scrolling')) {
        allElements[i].setAttribute('scrolling','yes');
        highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Forced iframe scrolling attribute to yes')
    }
				 if (allElements[i].hasAttribute('sandbox')) {
       //allElements[i].setAttribute('sandbox','allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox');
         allElements[i].removeAttribute('sandbox');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed certain iframe sandbox restrictions')
    }
	
	

			allElements[i].removeAttribute('disabled');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							  
								     allElements[i].removeAttribute('protected');
									 
			 
								
										
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
         allElements[i].setAttribute('allowtransparency','false');
		       allElements[i].removeAttribute('allowtransparency');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed iframe allowtransparency attribute')
    }
	
	
// FOR ALL DIV, P and INPUT Elements, Span
if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text/javascript"||allElements[i].type === "select-one"||allElements[i].type === "strong"||allElements[i].type === "i"||allElements[i].type === "p"||allElements[i].type === "hidden"||allElements[i].type === "ul"||allElements[i].type === "li"||allElements[i].type === "table"||allElements[i].type === "selection"||allElements[i].type === "legend"||allElements[i].type === "form"||allElements[i].type === "div"||allElements[i].type === "pre"||allElements[i].type === "p"||allElements[i].type === "span"||allElements[i].type === "h1"||allElements[i].type === "sup"||allElements[i].type === "main"||allElements[i].type === "text"||allElements[i].type === "input"||allElements[i].type === "select"||allElements[i].type === "option"||allElements[i].type === "form"||allElements[i].type === "inputbox"||allElements[i].type === "password"||allElements[i].type === "hidden"||allElements[i].type === "email"||allElements[i].type === "url"||allElements[i].type === "tel"||allElements[i].type === "tel"||allElements[i].type === "textarea"||allElements[i].type === "radio"||allElements[i].type === "checkbox"||allElements[i].type === "fieldset"||allElements[i].type === "button"||allElements[i].type === "submit"||allElements[i].type === "reset"||allElements[i].type === "input[type=td]"||allElements[i].type === "input[type=tr]"||allElements[i].type === "input[type=span]"||allElements[i].type === "input[type=label]")) {


		
	
}

// JUST BASIC TEXT INPUTS AND BUTTONS

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text"||allElements[i].type === "button"||allElements[i].type === "hidden"||allElements[i].type === "submit"||allElements[i].type === "checkbox")) {

 
	
	
}

// JUST ALL INPUTS AND FORM ELEMENTS

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "ul"||allElements[i].type === "li"||allElements[i].type === "hidden"||allElements[i].type === "text"||allElements[i].type === "input"||allElements[i].type === "select"||allElements[i].type === "option"||allElements[i].type === "form"||allElements[i].type === "inputbox"||allElements[i].type === "password"||allElements[i].type === "hidden"||allElements[i].type === "email"||allElements[i].type === "url"||allElements[i].type === "tel"||allElements[i].type === "tel"||allElements[i].type === "textarea"||allElements[i].type === "radio"||allElements[i].type === "checkbox"||allElements[i].type === "fieldset"||allElements[i].type === "button"||allElements[i].type === "submit"||allElements[i].type === "reset"||allElements[i].type === "input[type=td]"||allElements[i].type === "input[type=tr]"||allElements[i].type === "input[type=span]"||allElements[i].type === "input[type=label]")) {

	
	
	
		
		/*
	
		if (allElements[i].hasAttribute('ng-keypress')) {
          allElements[i].removeAttribute('ng-keypress');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-keypress attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('ng-if')) {
          allElements[i].removeAttribute('ng-if');
		console.log('%c  ' + i + ' - Removed ng-if attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-ng-if')) {
          allElements[i].removeAttribute('data-ng-if');
		console.log('%c  ' + i + ' - Removed data-ng-if attribute!','color: green;font-weight: 500;')
    }	
	
	
	if (allElements[i].hasAttribute('unless-feature')) {
          allElements[i].removeAttribute('unless-feature');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless-feature attribute!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('unless')) {
          allElements[i].removeAttribute('unless');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless attribute!','color: green;font-weight: 500;')
    }
	
	class: inspectlet-sensitive
	
*/
		 
	  if (allElements[i].hasAttribute('aria-busy')) {
        allElements[i].setAttribute('aria-busy','false');
			console.log('%c  ' + i + ' - Forced false aria-busy value!','color: green;font-weight: 500;')
    }
	
	
		
	
	
	

	 
    
    }
	
	 }
	  
	 
	


			
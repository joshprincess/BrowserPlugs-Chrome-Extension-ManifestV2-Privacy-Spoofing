function myFunction() {
    var x = document.getElementByTag("form");
    if (x.method === "get") {
        x.method = "post";
    } else {
        x.method = "post";
    }
}
 console.log ('Browser Plugs is enabling form elements without restrictions!','color: green;font-weight: 500;');



		
		var all = false;
		var labels = false;
		var divs = false;
		var buttons = true;
		var input_controls = true;
		
function highlightElementPink(anElement) {
    anElement.style.border = "thin solid #e83e8c";
}
function highlightElementWhite(anElement) {
    anElement.style.border = "thin solid white";
}
function highlightElementAuto(anElement) {
   console.log('Element Debug: ' + anElement.type);

if (anElement.type === "hidden") anElement.style.border = "thin solid #dc3545";
if (anElement.type === "text") anElement.style.border = "thin solid #dc3545";



}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid #dc3545";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid #ffc107";
}
function highlightElementBlack(anElement) {
    anElement.style.border = "thin solid #343a40";
}
function highlightElementFrame(anElement) {
    anElement.style.frameborder = "thin solid #343a40";
}
function highlightElementPurple(anElement) {
    anElement.style.border = "thin solid #6f42c1";
}
function highlightElementBlue(anElement) {
    anElement.style.border = "thin dotted #007bff";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('fieldset');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";
for (var i = 0; i < max; i++) {


							
if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('%c ' + i + ' / ' + max + ' | id: ' + allElements[i].getAttribute("id") + ' | async: ' + allElements[i].async + ' | title: ' + allElements[i].getAttribute("title") + ' | alt : ' + allElements[i].getAttribute("alt") + ' | type: ' + allElements[i].type + ' ','color: blue;font-weight: 500;');

// For ALL elements, Targeted
	
	if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }

		 	if (allElements[i].hasAttribute('data-rule-allowedincontext')) {
          allElements[i].removeAttribute('data-rule-allowedincontext');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-rule-allowedincontext attribute!','color: green;font-weight: 500;')
    }
	

	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-disabled attribute!','color: green;font-weight: 500;')
    }
		 
		 
	  if (allElements[i].hasAttribute('aria-disabled')) {
          allElements[i].removeAttribute('aria-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }
	
	   if (allElements[i].getAttribute('id') === "disable_restrictions") {
        allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced disable_restrictions true')
    }
	
	  
				if (allElements[i].hasAttribute('ws-modify-Unavbl')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log('%c  ' + i + ' - Removed ws-modify-Unavbl attribute!','color: green;font-weight: 500;')
    }	
	
	
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].removeAttribute('unselectable');
		console.log('%c  ' + i + ' - Removed unselectable attribute!','color: green;font-weight: 500;')
    }	
	
	
	 if (allElements[i].hasAttribute('contenteditable')) {
          allElements[i].setAttribute('contenteditable','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced contenteditable true!','color: green;font-weight: 500;')
    }
	
			
if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }

	
	if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	
		
	if (allElements[i].hasAttribute('readonly')) {
          allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('masked')) {
          allElements[i].removeAttribute('masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed masked attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ui-disabled')) {
          allElements[i].removeAttribute('ui-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ui-disabled attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('unavailable')) {
          allElements[i].removeAttribute('unavailable');
        highlightElementGreen(allElements[i]);
		console.log('%c 
		' + i + ' - Removed unavailable attribute!','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('aria-invalid')) {
          allElements[i].removeAttribute('aria-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-invalid attribute!','color: green;font-weight: 500;')
    }
	
		 allElements[i].classList.remove('read-only');	
			 	 allElements[i].classList.remove('ui-disabled');	
		 			allElements[i].classList.remove('disableTextSelection');
	allElements[i].classList.remove('disableSelection');
	allElements[i].classList.remove('restricted');
					
			 	 	 allElements[i].classList.remove('ui-disabled');		
 
		allElements[i].classList.remove('hide-focus');
 allElements[i].classList.remove('unavailable');
  allElements[i].classList.remove('disallow');
				
				allElements[i].classList.remove('locked');
						

				
		 allElements[i].classList.remove('disabled');
		


		  

			allElements[i].removeAttribute('disabled');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							  
								     allElements[i].removeAttribute('protected');
				
										
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													
													
													
							   allElements[i].classList.remove('ng-invalid');
							    allElements[i].classList.remove('ng-invalid-card');
								 allElements[i].classList.remove('ng-invalid-parse');
				 allElements[i].classList.remove('ng-invalid-valdr-expiration-validator');
	allElements[i].classList.remove('ng-invalid-valdr');
	
   allElements[i].classList.remove('ui-disabled');
     allElements[i].classList.remove('ui-state-disabled');
 allElements[i].classList.remove('disabled');
			 allElements[i].classList.remove('unavailable');	
			 	 allElements[i].classList.remove('ui-state-disabled');
															allElements[i].classList.remove('inactive');	
	
		 	allElements[i].classList.remove('data-std-maxlength');
		allElements[i].classList.remove('data-relaxed-maxlength');
		 	
        if (allElements[i].hasAttribute('data-ng-minlength')) {
        allElements[i].removeAttribute('data-ng-minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-minlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-ng-maxlength')) {
        allElements[i].removeAttribute('data-ng-maxlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-maxlength attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('data-ng-pattern')) {
        allElements[i].removeAttribute('data-ng-pattern');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-pattern attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('my-maxlength')) {
        allElements[i].removeAttribute('my-maxlength');
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Removed my-maxlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-rule-regularexpression')) {
        allElements[i].removeAttribute('data-rule-regularexpression');
					console.log('%c  ' + i + ' - Removed data-rule-regularexpression attribute!','color: green;font-weight: 500;')
        highlightElementGreen(allElements[i]);
    }
    if (allElements[i].hasAttribute('pattern')) {
        allElements[i].removeAttribute('pattern');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed pattern attribute!','color: green;font-weight: 500;')
    }
	
		 
	   if (allElements[i].hasAttribute('ng-required')) {
        allElements[i].removeAttribute('ng-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-required attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-empty')) {
        allElements[i].removeAttribute('ng-empty');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-empty attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-invalid-required')) {
        allElements[i].removeAttribute('ng-invalid-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid-required attribute!','color: green;font-weight: 500;')
    }
	  
 	
	  if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed required attribute!','color: green;font-weight: 500;')
    }
	
	

    if (allElements[i].hasAttribute('maxLength')) {
        allElements[i].removeAttribute('maxLength');
        highlightElementGreen(allElements[i]);
				console.log('%c  ' + i + ' - Removed maxLength attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-disabled attribute!','color: green;font-weight: 500;')
    }


		if (allElements[i].hasAttribute('minlength')) {
          allElements[i].removeAttribute('minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed minlength attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('numberonly')) {
          allElements[i].removeAttribute('numberonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - removed numberonly attribute!','color: green;font-weight: 500;')
    }
	
	

// JUST BASIC TEXT INPUTS AND BUTTONS

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "submit"||allElements[i].type === "button")) {

 
		allElements[i].disabled = false;
					allElements[i].enabled = true;
	
}


		
    }
	
	
			
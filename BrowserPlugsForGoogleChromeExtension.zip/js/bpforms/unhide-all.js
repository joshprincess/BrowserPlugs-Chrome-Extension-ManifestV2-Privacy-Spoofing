	var nosizecount = 0;
		var hidden_elemcount = 0;
		var stylevisibilitycount = 0;
		var hiddenelementcount = 0;
		var nonedisplaycount = 0;
		var opacitycount = 0;
		var moderncount = 0;
		
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid orange";
}
losAll = [];
col1 = [];
col2 = [];
col3 = [];

var allElements = document.getElementsByTagName("*");

var max = allElements.length;
var paint = "rgb(255,200,200)";

//if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('Element: ' + i + ' / ' + max + ' | For: ' + allElements[1].getAttribute("for") + ' | id: ' + allElements[i].getAttribute("id") + ' | Type: ' + allElements[i].type);
/*
Classes: 

.fb_hidden

Attributes:

overflow:hidden;
position:relative

*/

	var nosizecount = 0;
		var hidden_elemcount = 0;
		var stylevisibilitycount = 0;
		var hiddenelementcount = 0;
		var nonedisplaycount = 0;
		var opacitycount = 0;
		var moderncount = 0;
	var ariacount = 0;
	var ifcount = 0;
	
for (var i = 0; i < max; i++) {
    if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElement(allElementsGreen[i]);
		stylevisibilitycount = stylevisibilitycount + 1;
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElement(allElements[i]);
				nosizecount = nosizecount + 1;

    }
	    if (allElements[i].style.hidden_elem === "none") {
        allElements[i].style.display = "block";
        highlightElementOrange(allElements[i]);
				nosizecount = nosizecount + 1;

    }
	
    if (allElements[i].type === "hidden") {
        allElements[i].type = "text";
        highlightElement(allElements[i]);
		hidden_elemcount = hidden_elemcount + 1;
    }
	
	  if (allElements[i].style.opacity === "0"||allElements[i].style.opacity === "0.0"||allElements[i].style.opacity === "0.1"||allElements[i].style.opacity === "0.2"||allElements[i].style.opacity === "0.3"||allElements[i].style.opacity === "0.10") {
        allElements[i].style.opacity = "1";
        highlightElementOrange(allElements[i]);
opacitycount = opacitycount + 1;
    }
	
	  if (allElements[i].height === "0"||allElements[i].height === "0%" || allElements[i].height === 0||allElements[i].height === "0px"||allElements[i].height === "1px"||allElements[i].height === 1||allElements[i].height === "1%") {
        allElements[i].removeAttribute("height");
        highlightElementRed(allElements[i]);
opacitycount = opacitycount + 1;
    }
	
	
	
	
	totalcount = nosizecount + hidden_elemcount + stylevisibilitycount + nonedisplaycount + opacitycount + moderncount + ariacount + ifcount;
}
// hidden-sm hidden-md hidden-lg
console.log("Browser Plugs made " + totalcount + " objects visible. Including " + opacitycount + " small or transparent elements and " + nosizecount + " block or positioned elements. There were " + hidden_elemcount + " hidden inputs converted into visible textboxes.");

/* 
SineIn: ƒ ()
SineInOut: ƒ ()
SineOut: ƒ ()



*/
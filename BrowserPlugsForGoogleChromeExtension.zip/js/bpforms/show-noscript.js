var ancors3 = document.getElementsByTagName("noscript");

for ( var i=0; i < ancors3.length; i++ ) {
    var span = document.createElement("SPAN");
    if ( ancors3[i].className ) {
        span.className = ancors3[i].className;
    }

    if ( ancors3[i].id ) {
        span.id = ancors3[i].id;
		console.log(ancors3[i].id);
    }

    span.innerHTML = ancors3[i].innerHTML;
console.log(ancors3[i].innerHTML);
    ancors3[i].parentNode.replaceChild(span, ancors3[i]);
}


var nos = document.getElementsByTagName("noscript") 
var nos2 = document.querySelectorAll("NOSCRIPT")
var nos3 = document.getElementsByTagName("comment")

// in some browsers, contents of noscript hang around in one form or another
var nosHtml = nos.innerHTML += nos2.innerHTML += nos3.innerHTML;
var head = document.getElementsByTagName("head");
var body = document.getElementsByTagName("body");


 body.innerHTML += "<!-- BP Noscript Insert -->";
 body.innerHTML += nosHtml;
  head.innerHTML += nosHtml;

    console.log(nosHtml);

if ( nosHtml )
{
	 body.innerHTML += "<!-- BP Noscript Insert -->";
 body.innerHTML += nosHtml;
  head.innerHTML += nosHtml;

    console.log(nosHtml);

}


var noscript = document.querySelectorAll("noscript");
var head = document.getElementsByTagName("head")[0];

var content = noscript.innerHTML;
//head.parentNode.replaceChild(noscript);
head.innerHTML += content;

//class hide-with-nojs

/*
var anchors = document.querySelectorAll("noscript");

for ( var i=0; i < anchors.length; i++ ) {
    var span = document.createElement("");
    if ( anchors[i].className ) {
        span.className = anchors[i].className;
    }

    if ( anchors[i].id ) {
        span.id = anchors[i].id;
    }

    span.innerHTML = anchors[i].innerHTML;

    anchors[i].parentNode.replaceChild(span, anchors[i]);
}
*/

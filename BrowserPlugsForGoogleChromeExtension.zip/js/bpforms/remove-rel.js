// rel=dns-prefetch
// rel="alternate"
//  rel="preload"
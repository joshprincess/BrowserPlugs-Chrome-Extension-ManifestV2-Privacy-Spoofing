 /*   
 <option value="" selected="selected" disabled="disabled">Month</option>

 
 add class: cart__item--active
 
 remove class: focus-defocus-harder
 
 wf-sofiapro-n3-active wf-sofiapro-i3-active wf-sofiapro-n4-active wf-sofiapro-i4-active wf-sofiapro-n7-active wf-sofiapro-i7-active wf-active
 
 
 
 */
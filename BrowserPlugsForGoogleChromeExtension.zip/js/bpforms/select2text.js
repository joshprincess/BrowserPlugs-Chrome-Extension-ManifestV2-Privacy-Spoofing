
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid orange";
}
losAll = [];
col1 = [];
col2 = [];
col3 = [];

var allElements = document.getElementsByTagName("*");

var max = allElements.length;
var paint = "rgb(255,200,200)";


for (var i = 0; i < max; i++) {
 
   if (allElements[i].type === "select") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed select type into text!','color: green;font-weight: 500;')
    }
  
   if (allElements[i].type === "select-one ") {
        allElements[i].type = "select-one ";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed select-one type into text!','color: green;font-weight: 500;')
    }
 

 
}

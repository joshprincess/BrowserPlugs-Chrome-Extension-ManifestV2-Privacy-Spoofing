// console.log ('Browser Plugs is enabling form elements without restrictions!','color: green;font-weight: 500;');



		
		var all = true;
		var labels = true;
		var divs = true;
		var buttons = true;
		var input_controls = true;
		
function highlightElementPink(anElement) {
    anElement.style.border = "thin solid #e83e8c";
}
function highlightElementWhite(anElement) {
    anElement.style.border = "thin solid white";
}
function highlightElementAuto(anElement) {
   console.log('Element Debug: ' + anElement.type);

if (anElement.type === "hidden") anElement.style.border = "thin solid #dc3545";
if (anElement.type === "text") anElement.style.border = "thin solid #dc3545";



}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid #dc3545";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid #ffc107";
}
function highlightElementBlack(anElement) {
    anElement.style.border = "thin solid #343a40";
}
function highlightElementFrame(anElement) {
    anElement.style.frameborder = "thin solid #343a40";
}
function highlightElementPurple(anElement) {
    anElement.style.border = "thin solid #6f42c1";
}
function highlightElementBlue(anElement) {
    anElement.style.border = "thin dotted #007bff";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){
/*

'email'||'url'||'tel'||'tel'||'textarea'||'radio'||'checkbox'||'fieldset'||'button'||'submit'||'reset'||'input[type=td]'||'input[type=tr]'||'input[type=span]'||'input[type=label]'

legend selection 

	losTD = document.querySelectorAll('input[type=td]');
		losTR = document.querySelectorAll('input[type=tr]');
		losSpan = document.querySelectorAll('input[type=span]');
		losLabels = document.querySelectorAll('input[type=label]');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
*/		

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('fieldset');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";
for (var i = 0; i < max; i++) {


							
if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('%c ' + i + ' / ' + max + ' | id: ' + allElements[i].getAttribute("id") + ' | async: ' + allElements[i].async + ' | title: ' + allElements[i].getAttribute("title") + ' | alt : ' + allElements[i].getAttribute("alt") + ' | type: ' + allElements[i].type + ' ','color: blue;font-weight: 500;');

// For ALL elements, Targeted

if (allElements[i].hasAttribute('onerror')) {
          allElements[i].removeAttribute('onerror');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onerror attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('onerrorupdate')) {
          allElements[i].removeAttribute('onerrorupdate');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onerrorupdate attribute!','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].hasAttribute('contenteditable')) {
          allElements[i].setAttribute('contenteditable','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced contenteditable true!','color: green;font-weight: 500;')
    }
	
if (allElements[i].hasAttribute('disabled')||allElements[i].hasAttribute('enabled')) {
        allElements[i].removeAttribute('disabled');
		allElements[i].enabled = true;
        highlightElementGreen(allElements[i]);
			console.log(' ' + i + ' Removed Disabled Attribute!','color: green;font-weight: 500;')
			console.log(' ' + i + ' Forced true for Enabled Attribute!','color: green;font-weight: 500;')
    }
	
								if (allElements[i].hasAttribute('validate-submit')) {
          allElements[i].removeAttribute('validate-submit');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed validate-submit attribute!','color: green;font-weight: 500;')
    }				 
					 
if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	
		
	if (allElements[i].hasAttribute('readonly')) {
          allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ng-invalid')) {
          allElements[i].removeAttribute('ng-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('masked')) {
          allElements[i].removeAttribute('masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed masked attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('ui-disabled')) {
          allElements[i].removeAttribute('ui-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ui-disabled attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ng-invalid')) {
          allElements[i].removeAttribute('ng-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('unavailable')) {
          allElements[i].removeAttribute('unavailable');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed unavailable attribute!','color: green;font-weight: 500;')
    }
	
	
					   allElements[i].disabled = false;
							allElements[i].enabled = true;

// For ALL elements, Global *
		
					
		 allElements[i].classList.remove('disabled');
		 	 allElements[i].classList.remove('required');
		 allElements[i].removeAttribute('read-only');
		 	 allElements[i].classList.remove('read-only');	
			 	 allElements[i].classList.remove('ui-disabled');	
		 			allElements[i].classList.remove('disableTextSelection');
	allElements[i].classList.remove('disableSelection');
	allElements[i].classList.remove('restricted');
					allElements[i].classList.remove('removeFocusOutline');
					allElements[i].classList.remove('mktoRequired');
			 	 	 allElements[i].classList.remove('ui-disabled');		
  allElements[i].classList.remove('required-text');
        allElements[i].classList.remove('masked');
		allElements[i].classList.remove('hide-focus');
    allElements[i].classList.remove('ng-invalid');
 allElements[i].classList.remove('unavailable');
   allElements[i].classList.remove('notready');
  allElements[i].classList.remove('invalid');
  allElements[i].classList.remove('disallow');
					allElements[i].classList.remove('mask');
						allElements[i].classList.remove('untouched');
						allElements[i].classList.remove('pristine');
				allElements[i].classList.remove('locked');
						allElements[i].classList.remove('nc-required-js-1');
						allElements[i].classList.remove('nc-required-js-2');
						allElements[i].classList.remove('nc-required-js-3');
							allElements[i].classList.remove('required-js-1');
  allElements[i].classList.remove('void');


			
			 
// FOR VIDEO elements

 if (allElements[i].type === "video"||allElements[i].type === "audio") {
			
			 if (allElements[i].hasAttribute('autoplay')) {
        allElements[i].removeAttribute('autoplay');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed autoplay attribute!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('webkit-playsinline')) {
        allElements[i].setAttribute('webkit-playsinline','false');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Forced webkit-playsinline false!','color: green;font-weight: 500;')
    }
		 if (allElements[i].hasAttribute('playsinline')) {
        allElements[i].setAttribute('playsinline','false');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Forced playsinline false!','color: green;font-weight: 500;')
    }

				 if (!allElements[i].hasAttribute('controls')) {
        allElements[i].setAttribute('controls');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Added controls attribute!','color: green;font-weight: 500;')
    }
	
	
 }
	
	
	
	// FOR IMAGE elements

 if (allElements[i].type === "img"||allElements[i].type === "image") {
		
	 if (allElements[i].hasAttribute('data-imagetype')) {
        allElements[i].removeAttribute('data-imagetype');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-image attribute from image!','color: green;font-weight: 500;')
    }
	
		 if (allElements[i].hasAttribute('blockedimagesrc')) {
        allElements[i].removeAttribute('blockedimagesrc');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed blockedimagesrc attribute from image!','color: green;font-weight: 500;')
    }
	
	
 }
	
				 
// FOR A and LINK elements

	 if (allElements[i].type === "link"||allElements[i].type === "a"||allElements[i].type === "form") {
			
			if (allElements[i].hasAttribute('rel')) {
          allElements[i].removeAttribute('rel');
     //   highlightElementBlue(allElements[i]);
		console.log('%c  ' + i + ' - Removed rel attribute from link!','color: green;font-weight: 500;')
    }
	 }	
	 
// FOR META and HTML
	 		// js applicationcache geolocation history postmessage websockets localstorage sessionstorage websqldatabase webworkers hashchange audio canvas canvastext video webgl cssgradients multiplebgs opacity rgba inlinesvg hsla supports svgclippaths smil no-touchevents fontface generatedcontent textshadow cssanimations backgroundsize borderimage borderradius boxshadow flexbox cssreflections csstransforms csstransforms3d csstransitions js_active  vc_desktop  vc_transform  vc_transform no-skrollr" lang="en-US"		 

	 if (allElements[i].type === "body"||allElements[i].type === "header"||allElements[i].type === "html") {
			
			 allElements[i].setAttribute('supports');
		  allElements[i].removeAttribute('webgl');
		 allElements[i].removeAttribute('geolocation');
		  allElements[i].removeAttribute('webgl');
		   allElements[i].removeAttribute('audio');
		    allElements[i].removeAttribute('webworkers');
			 allElements[i].removeAttribute('svgclippaths');
			  allElements[i].removeAttribute('postmessage');

			  
			  	    allElements[i].removeAttribute('applicationcache');
			 allElements[i].removeAttribute('history');
			  allElements[i].removeAttribute('websqldatabase');
			  
			    allElements[i].removeAttribute('hsla');
			 allElements[i].removeAttribute('history');
			  allElements[i].removeAttribute('fontface');
			  allElements[i].removeAttribute('hashchange');
			    allElements[i].removeAttribute('localstorage');
				 allElements[i].removeAttribute('localstorage');
						  allElements[i].removeAttribute('postmessage');
			 allElements[i].removeAttribute('inlinesvg');
			
			  allElements[i].removeAttribute('smil');
		
		   
    }
		
	 
	// FOR Scripts

	 
	 if  ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text/javascript"||allElements[i].type === "script"||allElements[i].type === "application/ld+json"||allElements[i].type === "application/ld"||allElements[i].type === "application/javascript")) {
			
			 if (allElements[i].hasAttribute('async')) {
        allElements[i].removeAttribute('async');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('data-cfasync')) {
        allElements[i].removeAttribute('data-cfasync');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: green;font-weight: 500;')
    }
	
				 if (allElements[i].hasAttribute('_hjRemoteVarsFrame')) {
        allElements[i].removeAttribute('_hjRemoteVarsFrame');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed _hjRemoteVarsFrame attribute from script!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('style')) {
        allElements[i].removeAttribute('style');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed style attribute from script!','color: green;font-weight: 500;')
    }
	
	
			 if (allElements[i].hasAttribute('data-ssk-ready')) {
        allElements[i].removeAttribute('data-ssk-ready');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Added data-ssk-ready attribute to script!','color: green;font-weight: 500;')
    }
		
	
	 }
	 
	 // META
	 
	 if  (allElements[i].type === "meta") {
			
			 if (allElements[i].hasAttribute('async')) {
        allElements[i].removeAttribute('async');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('data-cfasync')) {
        allElements[i].removeAttribute('data-cfasync');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: green;font-weight: 500;')
    }
	
			 if (allElements[i].hasAttribute('data-ssk-ready')) {
        allElements[i].removeAttribute('data-ssk-ready');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Added data-ssk-ready attribute to script!','color: green;font-weight: 500;')
    }
		
	
	 }
	
// FOR IFRAME

	if (allElements[i].type === "iframe"||allElements[i].type === "frame") {
			
			 if (allElements[i].hasAttribute('scrolling')) {
        allElements[i].setAttribute('scrolling','yes');
        highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Forced iframe scrolling attribute to yes')
    }
				 if (allElements[i].hasAttribute('sandbox')) {
       //allElements[i].setAttribute('sandbox','allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox');
         allElements[i].removeAttribute('sandbox');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed certain iframe sandbox restrictions')
    }
	
	  allElements[i].setAttribute('allow','encrypted-media');

	
		 if (allElements[i].hasAttribute('allowtransparency')) {
         allElements[i].setAttribute('allowtransparency','false');
		       allElements[i].removeAttribute('allowtransparency');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed iframe allowtransparency attribute')
    }
		 if (allElements[i].hasAttribute('allowfullscreen')) {
         allElements[i].setAttribute('allowfullscreen','false');
		       allElements[i].removeAttribute('allowfullscreen');
					console.log('%c  ' + i + ' - Removed iframe allowfullscreen attribute')
	}
			 if (allElements[i].hasAttribute('tabindex')) {
         allElements[i].removeAttribute('tabindex');
		console.log('%c  ' + i + ' - Removed iframe tabindex attribute')
	
	}
	
	
	 if (allElements[i].hasAttribute('aria-hidden')) {
         allElements[i].removeAttribute('aria-hidden');
		console.log('%c  ' + i + ' - Removed iframe aria-hidden attribute')
	
	}
 
	 if (allElements[i].hasAttribute('width')) {
      if (allElements[i].getAttribute('width' === '1')||allElements[i].getAttribute('width' === '0')) {
		
			allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								  allElements[i].removeAttribute('border');
								  
								  allElements[i].setAttribute('frameborder','3');
								     allElements[i].removeAttribute('protected');
									  allElements[i].removeAttribute('std-maxlength');
									   allElements[i].removeAttribute('anchor');
										allElements[i].removeAttribute('anchors');
										allElements[i].removeAttribute('dialogWidth');
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													 allElements[i].removeAttribute('overflow');
													  allElements[i].removeAttribute('margins');
													 allElements[i].removeAttribute('marginBottom');
													 	 allElements[i].removeAttribute('marginLeft');
														  allElements[i].removeAttribute('marginTop');
														  	  allElements[i].removeAttribute('override-ltr');
	   }
	 }
         allElements[i].setAttribute('allowtransparency','false');
		       allElements[i].removeAttribute('allowtransparency');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed iframe allowtransparency attribute')
    }
	
	
	//width="1" height="1" src="https://bid.g.doubleclick.net/xbbe/pixel?d=KAE" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" style="display:none" scrolling="no"

	
	

// FOR ALL IMAGES
/*
		 if  (allElements[i].type === "image"||allElements[i].type === "image/x-icon"||allElements[i].type === "image/png"||allElements[i].type === "img"||allElements[i].type === "") {


if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
	
	
if (allElements[i].hasAttribute('rel')) {
          allElements[i].removeAttribute('rel');
     //   highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed rel attribute!','color: green;font-weight: 500;')
    }
	

	
	if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed required attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('ondrag')) {
          allElements[i].removeAttribute('ondrag');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ondrag attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('onpaste')) {
          allElements[i].removeAttribute('onpaste');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onpaste attribute!','color: green;font-weight: 500;')
    }
			
		if (allElements[i].hasAttribute('onselectstart')) {
          allElements[i].removeAttribute('onselectstart');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onselectstart attribute!','color: green;font-weight: 500;')
    }
	
	}
	
	*/
// FOR ALL DIV, P and INPUT Elements, Span
if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text/javascript"||allElements[i].type === "select-one"||allElements[i].type === "strong"||allElements[i].type === "i"||allElements[i].type === "p"||allElements[i].type === "hidden"||allElements[i].type === "ul"||allElements[i].type === "li"||allElements[i].type === "table"||allElements[i].type === "selection"||allElements[i].type === "legend"||allElements[i].type === "form"||allElements[i].type === "div"||allElements[i].type === "pre"||allElements[i].type === "p"||allElements[i].type === "span"||allElements[i].type === "h1"||allElements[i].type === "sup"||allElements[i].type === "main"||allElements[i].type === "text"||allElements[i].type === "input"||allElements[i].type === "select"||allElements[i].type === "option"||allElements[i].type === "form"||allElements[i].type === "inputbox"||allElements[i].type === "password"||allElements[i].type === "hidden"||allElements[i].type === "email"||allElements[i].type === "url"||allElements[i].type === "tel"||allElements[i].type === "tel"||allElements[i].type === "textarea"||allElements[i].type === "radio"||allElements[i].type === "checkbox"||allElements[i].type === "fieldset"||allElements[i].type === "button"||allElements[i].type === "submit"||allElements[i].type === "reset"||allElements[i].type === "input[type=td]"||allElements[i].type === "input[type=tr]"||allElements[i].type === "input[type=span]"||allElements[i].type === "input[type=label]")) {

			 if (!allElements[i].hasAttribute('ng-non-bindable')) {
        allElements[i].removeAttribute('ng-non-bindable');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-non-bindable attribute!','color: green;font-weight: 500;')
    }
			 if (!allElements[i].hasAttribute('ng-cloak')) {
        allElements[i].removeAttribute('ng-cloak');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-cloak attribute!','color: green;font-weight: 500;')
    }
	

if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
	
					     	 allElements[i].classList.remove('page-loader');
		   allElements[i].classList.remove('modal-backdrop');
    allElements[i].classList.remove('spinner');
	  allElements[i].classList.remove('preloader');
	  		 		allElements[i].classList.add('good');
						allElements[i].classList.add('has-success');
				allElements[i].classList.add('verified');

	allElements[i].classList.add('enabled');
	allElements[i].classList.add('optional');
		allElements[i].classList.add('ng-valid-required');
		allElements[i].classList.add('valid');
		allElements[i].classList.add('allowed');
		allElements[i].classList.add('unlocked');
		allElements[i].classList.add('not-void');
		allElements[i].classList.add('ng-valid');
				allElements[i].classList.add('ng-not-empty');
					allElements[i].classList.add('ng-valid-parse');				
					allElements[i].classList.add('ng-valid-luhn');
							allElements[i].classList.add('ng-valid-pattern');
							allElements[i].classList.add('ng-valid-maxlength');
							allElements[i].classList.add('ng-valid-len');
							allElements[i].classList.add('ng-valid-validator');
							allElements[i].classList.add('ng-valid-prod-type');
							allElements[i].classList.add('aamIframeLoaded');
					 allElements[i].classList.add('loaded');
			allElements[i].classList.add('unmasked');
			allElements[i].classList.add('ng-dirty');
			allElements[i].classList.add('acceptable');
		allElements[i].classList.add('ng-enabled');
			allElements[i].classList.add('canuse');
			allElements[i].classList.add('can-use');
			allElements[i].classList.add('available');
			allElements[i].classList.add('usable');
			allElements[i].classList.add('allow');
			allElements[i].classList.add('allowedincontext');
			allElements[i].classList.add('editable');
			allElements[i].classList.add('validated');
		allElements[i].classList.add('novalidate');
		allElements[i].classList.add('ng-touched');
		allElements[i].classList.add('enough');
		allElements[i].classList.add('clickable');
				allElements[i].classList.add('enableTextSelection');
						allElements[i].classList.add('allowTextSelection');
					
					
				allElements[i].classList.add('identified');
								allElements[i].classList.add('state-recognized');
				allElements[i].classList.add('state-initialized');
					allElements[i].classList.add('gc-enabled');	
	allElements[i].classList.add('md-input-has-value');	
	allElements[i].classList.add('ng-valid-maxlength');	
		allElements[i].classList.remove('inactive');	
				
		//zone-off wsite-theme-clean wsite-theme-light logo-scroll-off show-mega-panel-off  has-bm
		//skip-link skip-main skip-bm     style:is_customized: 1;
		
						allElements[i].classList.add('logo-scroll-off');	
	allElements[i].classList.add('show-mega-panel-off');	
				allElements[i].classList.add('has-bm');	
	allElements[i].classList.remove('zone-off');	
allElements[i].classList.add('toggle-edit');	
	allElements[i].classList.add('app-zone');
			allElements[i].classList.remove('data-hj-masked');		
					
					
					if (allElements[i].hasAttribute('inactive')) {
          allElements[i].removeAttribute('inactive');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed inactive attribute!','color: green;font-weight: 500;')
    }
	
	
				if (allElements[i].hasAttribute('aria-keyshortcuts')) {
          allElements[i].removeAttribute('aria-keyshortcuts');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-keyshortcuts attribute!','color: green;font-weight: 500;')
    }
	
					
					
						 if (allElements[i].hasAttribute('data-hj-masked')) {
          allElements[i].removeAttribute('data-hj-masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-hj-masked attribute!','color: green;font-weight: 500;')
    
	}
		 if (allElements[i].hasAttribute('data-masked')) {
          allElements[i].removeAttribute('data-masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-hj-masked attribute!','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].hasAttribute('inputmode')) {
          allElements[i].removeAttribute('inputmode');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed inputmode attribute!','color: green;font-weight: 500;')
    }
	
	 
	    if (allElements[i].hasAttribute('override-pattern-js')) {
        allElements[i].removeAttribute('override-pattern-js');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed override-pattern-js attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('data-dismiss')) {
        allElements[i].removeAttribute('data-dismiss=');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-dismiss attribute!','color: green;font-weight: 500;')
    }

	  if (allElements[i].hasAttribute('aria-disabled')) {
          allElements[i].removeAttribute('aria-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('aria-required')) {
          allElements[i].removeAttribute('aria-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }

	  if (allElements[i].hasAttribute('required')) {
        allElements[i].required = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced required value to false!','color: green;font-weight: 500;')
    }
	
    if (allElements[i].hasAttribute('readonly')) {
        allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
		
    if (allElements[i].hasAttribute('read-only')) {
        allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	
	   if (allElements[i].getAttribute('id') === "disable_restrictions") {
        allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced disable_restrictions true')
    }
	
	   if (allElements[i].getAttribute('id') === "simulated") {
        allElements[i].setAttribute('value','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced simulated false')
    }
	
	allElements[i].classList.remove('has-failure');
				allElements[i].classList.remove('has-fail');
				allElements[i].classList.remove('has-error');
				allElements[i].classList.remove('has-failed');
				allElements[i].classList.remove('has-errors');
						
				if (allElements[i].hasAttribute('ws-modify-Unavbl')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log('%c  ' + i + ' - Removed ws-modify-Unavbl attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-std-maxlength')) {
          allElements[i].removeAttribute('data-std-maxlength');
		console.log('%c  ' + i + ' - Removed data-std-maxlength attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].removeAttribute('unselectable');
		console.log('%c  ' + i + ' - Removed unselectable attribute!','color: green;font-weight: 500;')
    }	
	
						if (allElements[i].hasAttribute('data-cs-mask')) {
          allElements[i].removeAttribute('data-cs-mask');
		console.log('%c  ' + i + ' - Removed data-cs-mask attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-relaxed-maxlength')) {
          allElements[i].removeAttribute('data-relaxed-maxlength');
		console.log('%c  ' + i + ' - Removed data-relaxed-maxlength attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('data-mask-credit-card')) {
          allElements[i].removeAttribute('data-mask-credit-card');
		console.log('%c  ' + i + ' - Removed data-mask-credit-card attribute!','color: green;font-weight: 500;')
    }	
	
	if (allElements[i].hasAttribute('zip-error-key')) {
          allElements[i].removeAttribute('zip-error-key');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed zip-error-key attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('zip-required')) {
          allElements[i].removeAttribute('zip-required');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed zip-required attribute!','color: green;font-weight: 500;')
    }			
					if (allElements[i].hasAttribute('data-error-key')) {
          allElements[i].removeAttribute('data-error-key');
		console.log('%c  ' + i + ' - Removed data-error-key attribute!','color: green;font-weight: 500;')
    }	
				if (allElements[i].hasAttribute('xo-error-tooltip')) {
          allElements[i].removeAttribute('xo-error-tooltip');
		console.log('%c  ' + i + ' - Removed xo-error-tooltip attribute!','color: green;font-weight: 500;')
    }	
	
			if (allElements[i].hasAttribute('autocapitalize')) {
          allElements[i].setAttribute('autocapitalize','on');
		// console.log('%c  ' + i + ' - Forced autocapitalize on attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('autocorrect')) {
          allElements[i].setAttribute('autocorrect','on');
		// console.log('%c  ' + i + ' - Forced autocorrect on attribute!','color: green;font-weight: 500;')
    }	
		if (allElements[i].hasAttribute('oncontextmenu')) {
          allElements[i].removeAttribute('oncontextmenu');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed oncontextmenu attribute!','color: green;font-weight: 500;')
    }
}

// JUST TEXT INPUTS AND BUTTONS

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text"||allElements[i].type === "button"||allElements[i].type === "hidden"||allElements[i].type === "submit"||allElements[i].type === "checkbox")) {

  if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }
	
	    if (allElements[i].style.opacity === "0"||allElements[i].style.opacity === "0.0"||allElements[i].style.opacity === "0.1"||allElements[i].style.opacity === "0.2"||allElements[i].style.opacity === "0.3"||allElements[i].style.opacity === "0.10") {
        allElements[i].style.opacity = "1";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }
	
	
}

// JUST FORM INPUTS AND BUTTONS

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "ul"||allElements[i].type === "li"||allElements[i].type === "hidden"||allElements[i].type === "text"||allElements[i].type === "input"||allElements[i].type === "select"||allElements[i].type === "option"||allElements[i].type === "form"||allElements[i].type === "inputbox"||allElements[i].type === "password"||allElements[i].type === "hidden"||allElements[i].type === "email"||allElements[i].type === "url"||allElements[i].type === "tel"||allElements[i].type === "tel"||allElements[i].type === "textarea"||allElements[i].type === "radio"||allElements[i].type === "checkbox"||allElements[i].type === "fieldset"||allElements[i].type === "button"||allElements[i].type === "submit"||allElements[i].type === "reset"||allElements[i].type === "input[type=td]"||allElements[i].type === "input[type=tr]"||allElements[i].type === "input[type=span]"||allElements[i].type === "input[type=label]")) {

	
	
	if (allElements[i].type === "hidden") {
			

  allElements[i].type = "text";
			 
			 	var namename4 = allElements[i].getAttribute("aria-label");
				var namename5 = allElements[i].getAttribute("name");
			var namename6 = " " + namename4 + " " + namename5;
				if (!namename4 && !namename5) namename6 = "";
				if (namename4 !== null && namename5 !== null) namename6 = "";



	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id") + namename6);
	 	 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id") + namename6);
		 	 	 if (!allElements[i].hasAttribute("placeholder")) allElements[i].setAttribute('placeholder',allElements[i].getAttribute("id") + namename6);
		 	 	 if (!allElements[i].hasAttribute("title")) allElements[i].setAttribute('title',allElements[i].getAttribute("id") + namename6);

			allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								  allElements[i].removeAttribute('border');
								     allElements[i].removeAttribute('protected');
									  allElements[i].removeAttribute('std-maxlength');
									   allElements[i].removeAttribute('anchor');
										allElements[i].removeAttribute('anchors');
										allElements[i].removeAttribute('dialogWidth');
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													 allElements[i].removeAttribute('overflow');
													  allElements[i].removeAttribute('margins');
													 allElements[i].removeAttribute('marginBottom');
													 	 allElements[i].removeAttribute('marginLeft');
														  allElements[i].removeAttribute('marginTop');
														  	  allElements[i].removeAttribute('override-ltr');
															  
															  	  	  allElements[i].removeAttribute('z-Index');
																	  
															    allElements[i].removeAttribute('zIndex');
																	    allElements[i].removeAttribute('invalid');
																	
																	  
																	  
															  
															   
       highlightElementRed(allElements[i]);
			console.log('%c  ' + i + ' - Changed hidden input to unrestricted textbox!','color: green;font-weight: 500;')
			
				 allElements[i].removeAttribute('zIndex');
	
		 allElements[i].removeAttribute('z-Index');
			
    }
	
	
	
/* en_US countryUS USD src_ en st_ Smartv2 Desktop Chrome
*/

 allElements[i].classList.remove('validation-group');
    allElements[i].classList.remove('problem');
 allElements[i].classList.remove('unauthorized');
  allElements[i].classList.remove('failed');
 
		  allElements[i].classList.remove('has-error');
 allElements[i].classList.remove('form-control--error');
  allElements[i].classList.remove('error');
   allElements[i].classList.remove('error-label');
    allElements[i].classList.remove('form-ada-error-text');
  allElements[i].classList.remove('icon-exclamation-circle');
   allElements[i].classList.remove('form-ada-error-message');
   

							
   allElements[i].classList.remove('alert');
      allElements[i].classList.remove('alert-danger');
   allElements[i].classList.remove('NotEnoughLoyaltyPointsException');
  allElements[i].classList.remove('NotEnough');
  allElements[i].classList.remove('NoPoints');
  allElements[i].classList.remove('exception');
  allElements[i].classList.remove('warning');
   allElements[i].classList.remove('incomplete');
   allElements[i].classList.remove('incompleted');
 allElements[i].classList.remove('incompleted');
  allElements[i].classList.remove('incompleted');
  
   allElements[i].classList.remove('blocked');
   allElements[i].classList.remove('notfound');
	  					allElements[i].classList.remove('hasErrorTooltipRuleSpecific');
				allElements[i].classList.remove('hasErrorTooltipRequired');
											allElements[i].classList.remove('errloading');
										allElements[i].classList.remove('icon_warn');
							 

							
					
						
							allElements[i].disabled = false;
							allElements[i].enabled = true;
						
						// The global added styles
						
					
					
		
							allElements[i].classList.remove('hidden-lg-down');
					allElements[i].classList.remove('IPE_hidden');
					allElements[i].classList.remove('hidden-print');
				allElements[i].classList.remove('hidden-form');
				
				
			/*
			
			notIE7 ms-fwt-r customScrollBar disableTextSelection mainWindow removeFocusOutline
		<ch-skip-nav ng-if="$root.featureFlags.SKIP_NAV"><div ch-skip-nav-toggle="$ctrl.activateSkipNav" id="skip-nav" class="flex flex-col jc-center skip-nav text-white fs-13" ng-class="{'skip-nav-active': $ctrl.activateSkipNav}">
		
		<main ng-if="featureFlags.SYSTEM_ALERTS">
		 <div ch-notice=""><div class="ch-notice ng-hide" ng-class="[backgroundColor, opacity]" ng-show="show" aria-hidden="true">
		  <div ng-bind-html="content"></div>
		<div ui-view="">
		
		<div id="root" ng-non-bindable=""></div>
			preloadDiv
			removeFocusOutline
			onerror
			
			 img svgsrc=
			 img data-bind
			 
			 img class="mobileMode"  "desktopMode"
			 
			 mktoField mktoTextField mktoHasWidth mktoRequired mktoValid
			 rich-snippet-hidden
			 <link rel="dns-prefetch" href="//fonts.googleapis.com">

			 
			ismodal
			aria-atomic
			
			<div id="ariaAssertiveAlert" class="accessible_elem" aria-live="assertive"></div>
			
			unselectable = "on"
			
			// SET VARIABLES AS IDS
			 <div id="mainDiv" class="mouse">
        <script>

            var mainLogonDiv = window.document.getElementById("mainDiv");
            mainLogonDiv.className = mainLogonDivClassName;
        </script>
		
			
			div autoid
			div regioncontainer
			id="remember-me"
			<input id="form_agree" name="form[agree]" type="checkbox" value="1">
			
			<input class="disable_restrictions" id="disable_restrictions" name="disable_restrictions" type="hidden" value="false">
			
			block fonts:
			<link rel="preload" href="//img1.wsimg.com/ux/fonts/uxfont/1.4/uxfont.woff2" 
			as="font" type="font/woff2" crossorigin="">
			
			// footers  ss_box_footer ss_form_footer  ss_form_footer_msg   <ch-ukasl-footer></ch-ukasl-footer>   main-footer-wrapper  
			
			allElements[i].classList.remove('removeFocusOutline');
			
				allElements[i].debug = true;
					allElements[i].debugger = true;
							allElements[i].debugmode = true;
							
							<!-- OwaPage = ASP.auth_errorfe_aspx -->
							
							<div class="diagnosticToggle" id="diagnosticToggle" tabindex="0" onclick="toggleDiagnosticDetails()">More details...</div>
							
							<pre class="errorDetails OCRFriendly" id="diagnosticDiv" style="display:none;">X-ClientId: 2DD52B921FD345C9BB511C1F88136126


							allElements[i].admin = true;
							allElements[i].log = true;
							<ch-footer-container cp-user="cpUser"
							<ch-footer-container cp-user="cpAdmin"  user-logged-in="$ctrl.userLoggedIn"
					
								 allElements[i].classList.remove('geolocation');
						
						<body lang="en" data-mobile="false" data-scrolltop="376" data-loggedin="false" data-page="">
<html lang="en" dir="auto">
<div data-component="user" class="user-module-desktop"><div class="user-module-wrapper expand-off"><div>
    <div class="user-module">
        <div class="user-others">
		     <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><symbol viewBox="0 0 28 21" id="AED"><title>AE</title><defs><path id="aaa" d="M0 0h28v20H0z"></path><path id="aac" d="M0 0h28v20H0z"></path></defs><g transform="translate(0 .167)" fill="none" fill-rule="evenodd"><mask id="aab" fill="#fff"><use xlink:href="#aaa"></use></mask>
			 <symbol viewBox="0 0 28 21" id="AUD"><title>AU</title><defs><path id="aba" d="M0 0h28v20H0z"></path
			 <dl class="dl-horizontal">
                <dt>Address</dt>
                <dd></dd>
            </dl>

			 
	      allElements[i].classList.remove('ui-input-mobile');
		 allElements[i].classList.remove('fix-ada-iphone');

	     allElements[i].classList.remove('demo');
		     allElements[i].classList.remove('defer');
		 			allElements[i].classList.remove('noFloatingLabel');
      allElements[i].classList.remove('ghost');
							allElements[i].classList.remove('confidential');
		
	  				allElements[i].classList.remove('nc-loading-circle');
					allElements[i].classList.remove('icon_ban');
							allElements[i].classList.remove('captcha_error');
								allElements[i].classList.remove('inlinesvg');
								
								allElements[i].classList.remove('no-js');
								
						allElements[i].classList.add('standard');
		 	allElements[i].classList.add('happy');
			allElements[i].classList.add('accurate');
			allElements[i].classList.add('match');
			allElements[i].classList.add('matched');
			allElements[i].classList.add('loaded');
			allElements[i].classList.add('accuracy');
			allElements[i].classList.add('done');
			allElements[i].classList.add('complete');
					allElements[i].classList.add('ready');
		allElements[i].classList.add('confirmed');
				allElements[i].classList.add('debug');
				allElements[i].classList.add('debugmode');
				allElements[i].classList.add('admin');
				allElements[i].classList.add('staff');
					allElements[i].classList.add('loggedin');
					allElements[i].classList.add('logged-in');
					allElements[i].classList.add('member');
					allElements[i].classList.add('native');
					allElements[i].classList.add('official');
					allElements[i].classList.add('paid');
		allElements[i].classList.add('confirm');
				allElements[i].classList.add('true');
		allElements[i].classList.add('public');
					allElements[i].classList.add('normal');
			allElements[i].classList.add('working');
		allElements[i].classList.add('unused');
			
			allElements[i].classList.add('working');
			

					
					
					allElements[i].classList.add('found');

				
		allElements[i].classList.add('root');
				
				allElements[i].classList.add('notIE8');	
				
				data-permanent="1" crossorigin="anonymous"
				
				link type=
				a
				meta
				html
				head
				meta charset="utf-8"
				
				script
				
				
				visibility:
				onclick="document.getElementById('cmdContinue').style.visibility = 'hidden';document.getElementById('cmdCancel').style.visibility = 'hidden';
				document.getElementById('divShowText').style.visibility = 'visible';document.Form1.submit();"
				
				cookie: lc_window_state: minimized
				
				cleanpage:
				copyright
				
				
				
				// global add funxtion
				
				<script type="text/javascript">
  $(function(){

    // Add/remove .focused class to inputs
    $('body').on('focus', 'input,textarea', function(event) {
      $(this).parents('.field_block').eq(0).find('label').eq(0).addClass('focused');
    });
    $('body').on('blur', 'input,textarea', function(event) {
      if (!$(this).val()) {
        $(this).parents('.field_block').eq(0).find('label').eq(0).removeClass('focused');    
      }
    })

    // Add tabindex to alternative checks/radios
    $('.ss_alt_icon').attr('tabindex', '0');

    // Toggle alternative checks/radios with spacebar
    $('body').on('keyup', function(event) {
      if ($(event.target).is('.ss_alt_icon') && event.keyCode === 32) {
        $(event.target).prev().click();
      }
    });

    // Remove .focused after successful submit
    $('body').on('success.form', function() {
      $('.field_block label').removeClass('focused');
    });

  });
</script>
				
					
				// global add funxtion
					
				// global add function
				
				<img data-imagetype="External" blockedimagesrc="http://www.hainanairlines.com:80/go/emai/confirmed-ico.png" width="57" height="57" align="left" alt="OK" style="text-align:left">
				
				<ul id="ss_cimico" style="display:none;"></ul>
			//invisible-apps app-zone
				*/
				
				
				allElements[i].classList.remove('invisible-apps');
				
				allElements[i].classList.remove('data-std-maxlength');
		allElements[i].classList.remove('data-relaxed-maxlength');
		allElements[i].classList.remove('data-cs-mask');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
	allElements[i].classList.remove('hidden_elem');
	
		
		
				
		allElements[i].classList.add('data-ng-enabled');
		
			if (allElements[i].hasAttribute('directionality')) {
          allElements[i].setAttribute('directionality','ltr');
		console.log('%c  ' + i + ' - Forced directionality attribute ltr!','color: green;font-weight: 500;')
    }	

	
			
	
		if (allElements[i].hasAttribute('ng-if')) {
          allElements[i].removeAttribute('ng-if');
		console.log('%c  ' + i + ' - Removed ng-if attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-ng-if')) {
          allElements[i].removeAttribute('data-ng-if');
		console.log('%c  ' + i + ' - Removed data-ng-if attribute!','color: green;font-weight: 500;')
    }	
	
	
						allElements[i].classList.remove('unknown');
						
		allElements[i].classList.remove('icon-error');
			

						allElements[i].classList.remove('ws-error');
						
	if (allElements[i].hasAttribute('onblur')) {
          allElements[i].removeAttribute('onblur');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed blur attribute!','color: green;font-weight: 500;')
    }	
		if (allElements[i].hasAttribute('keypress')) {
          allElements[i].removeAttribute('keypress');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed keypress attribute!','color: green;font-weight: 500;')
    }			
					
	 // ADD Placeholder to all elements
	
		if (!allElements[i].hasAttribute('placeholder')) {
					 
			 	var namename4 = allElements[i].getAttribute("aria-label");
				var namename5 = allElements[i].getAttribute("name");
			var namename6 = " " + namename4 + " " + namename5;
				if (!namename4 && !namename5||namename4 === null && namename5 === null) namename6 = "";



	 	 allElements[i].setAttribute('placeholder',allElements[i].getAttribute("id") + namename6);

		// console.log('%c  ' + i + ' - Added placeholder attribute!','color: green;font-weight: 500;')
    }	


allElements[i].setAttribute('data-ux-jq-mouseenter','true');
allElements[i].setAttribute('data-hj-whitelist','true');
			 	 allElements[i].setAttribute('novalidate','novalidate');
	 allElements[i].setAttribute('autocomplete','on');
	 	 allElements[i].setAttribute('aria-autocomplete','both');
	 
	 
	 	// allElements[i].setAttribute('autocorrect','on');
		// allElements[i].setAttribute('spellcheck','true');
		  
		  if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }

	

		// allElements[i].setAttribute('autocapitalize','on');
		
		/*
		
		
		allowTextSelection _rp_k allowTextSelection regionbehavior="1" <div autoid="_n_d" role="document" class="allowTextSelection" regionbehavior="1" style=""> <div class="conductorContent" role="presentation" style=""><div class="_rp_k" tabindex="-1" customtabindex="-1"><
		
		https://shop.safeway.com/welcome/sign-in.html
		<input type="checkbox" name="rememberMeCheckbox" id="label-rememberme" onclick="AB.COMMON.rememberMe('kmsi')">
		<input type="checkbox" name="rememberMeCheckbox" id="label-rememberme">
		<div class="checkbox">
							    <label for="label-rememberme"><input type="checkbox" name="rememberMeCheckbox" id="label-rememberme">Remember me </label>
						    </div>
							   this.rememberMe = function (event) {
        if (AB.DATALAYER.dl.user.userPreference == event) {
            AB.DATALAYER.dl.user.userPreference = '';
        } else {
            AB.DATALAYER.dl.user.userPreference = event;
        }
		
		
	 ng-keypress="ngKeypress" data-pii="" shipping-form-focus="" required="required" aria-required="true" aria-invalid="true"
	
		test

		!this.spout.isTest
		
		id 
		
	spout-overlay
	// modal fade in
	modal-table
	modal-content
	crossBannerModal
	modal-dialog full-bleed-row
	modal-open
	//createAccountModal
	//miniCartModal
	tpl-global-cookie-policy cookie-policy_2
	
	
	//safeway
	ADBLOCK_DETECTED false
	Backbone.emulateJSON false
	Backbone.emulateHTTP false
	Backbone.history._hasHashChange true
	
	// Major New
	<svg ng-click="tc.confirmCheck = !tc.confirmCheck" focusable="false" role="none" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="Icon InputIndicator injected-svg js-svg-inject" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 20 20" data-src="./assets/images/icons/checkbox.svg" tabindex="0">
                             <title>Checkbox Off Icon</title>
                             <desc>Created with Sketch.</desc>
                             <g>
                                 <rect class="Icon-property--stroke InputIndicator-outline" y="0" fill="none" stroke="#000" stroke-width="1" width="20" height="20"></rect>
                                 <path class="Icon-property--stroke InputIndicator-on" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="   M4,9.548l4.286,4.441L16,5.995"></path>
                             </g>
                         </svg>
						 
						 <svg ng-click="tc.confirmCheck = !tc.confirmCheck" focusable="false" role="none" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="Icon InputIndicator injected-svg js-svg-inject" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 20 20" data-src="./assets/images/icons/checkbox.svg" tabindex="0">
                             <title>Checkbox Off Icon</title>
                             <desc>Created with Sketch.</desc>
                             <g>
                                 <rect class="Icon-property--stroke InputIndicator-outline" y="0" fill="none" stroke="#000" stroke-width="1" width="20" height="20"></rect>
                                 <path class="Icon-property--stroke InputIndicator-on" fill="none" stroke="#000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="   M4,9.548l4.286,4.441L16,5.995"></path>
                             </g>
                         </svg>
						 
						                         <rect x="25.451" y="25.572" fill="#3A3A39" width="5.789" height="9.613"></rect>
                        <circle fill="#3A3A39" cx="28.4" cy="20.767" r="3.277"></circle>
                        <path fill="#3A3A39" d="M56.334,16.482c-0.781-1.962-1.934-3.63-3.43-4.958c-2.631-2.339-6.324-3.604-10.697-3.676V7.842H21.436

						                        <rect x="25.451" y="25.572" fill="#3A3A39" width="5.789" height="9.613"></rect>
                        <circle fill="#3A3A39" cx="28.4" cy="20.767" r="3.277"></circle>
                        <path fill="#3A3A39" d="M56.334,16.482c-0.781-1.962-1.934-3.63-3.43-4.958c-2.631-2.339-6.324-3.604-10.697-3.676V7.842H21.436

						<gms-forms-ui><!-- Login PopUp -->
<div id="gms-login-modal-parent-id" class="GSplash-wrapper Footer-GSplash-wrapper ng-class=" {'maxwidth-logo-wrap':="" fullwidthlogoenabled}"="">

<guest-retrive-form><div id="guests-retrieve-modal-parent-id" class="GSplash-wrapper Footer-GSplash-wrapper ng-class=" {'maxwidth-logo-wrap':="" fullwidthlogoenabled}"="">

<guest-retrive-form><div id="guests-retrieve-modal-parent-id" class="GSplash-wrapper Footer-GSplash-wrapper ng-class=" {'maxwidth-logo-wrap':="" fullwidthlogoenabled}"="">
<footer-bar><footer class="Footer-wrap HeaderButton-content">

class : toast-error 
<switch-room class="ng-scope">

<div class="switchRoom GSplash-wrapper GSplash-multiroom-wrapper Footer-GSplash-wrapper alternateproperties-splash-wrapper" ng-class="{'MaxWidth-logo-wrap': fullWidthLogoEnabled}"


<delete-package

			<div class="js-blocker Checkout-disabledBlocker"></div>


<!-- ngIf: bookNowDisplay && (ingenico || reddot) -->
<nav-bar class="Header--top"><nav class="Header" ng-class="{'is-collapsed': !toggle.collapse};">

<my tag=""></my>

<img alt="" height="1" width="1" style="display: none;" 			
						// end of major
	
	
	// clear header
			header-mobile-fixed
			
	
	class
		placement-top-offscreen spout-mode-
		placement-top-offscreen spout-mode-
		jqx-window-modal jqx-window-modal-energyblue
		
		autoclose: <input type="button" style="cursor: pointer;" id="close_win" value="Close" role="button" class="jqx-rc-all jqx-button jqx-widget jqx-fill-state-normal jqx-danger" aria-disabled="false">
		autoclose: <div id="msg" style="margin: 0px auto; z-index: 18001; outline: none; width: 650px; height: 150px; min-height: 50px; max-height: 600px; min-width: 100px; max-width: 800px; top: 924px; left: 99px;" role="dialog" class="jqx-rc-all jqx-rc-all-energyblue jqx-window jqx-window-energyblue jqx-popup jqx-popup-energyblue jqx-widget jqx-widget-energyblue jqx-widget-content jqx-widget-content-energyblue" tabindex="0" hidefocus="true">
popupRegion popup-show


		<meta http-equiv="x-dns-prefetch-control" content="on">

		auto check: <i data-bind="tick" class="checkbox checked"></i>
		
	
		
		 A CLASS
		spout-ad-block
		
		class="spout-ad-image
		spout-ad-fade
		"spout-ad-info
		
		spout-ad-copy
		spout-ad-site
		
		// autocheck :  name="bp_rlu_do_not_show_again" id="rlu_persistent_dismissal"
		<input id="rememberMe" name="WDS_SAVE_COOKIE" type="checkbox" value="YES">
		<input name="WDS_SAVE_COOKIE_IS_CHECKED" type="hidden" value="NO" tabindex="-1">
		
		continue session:
		<button class="primary sessBtn" type="button" id="sessYes" role="button" aria-atomic="false"> <span class="text yes">Yes</span> </button>
		<input type="hidden" value="true" name="RESTRICTION">   (change to false?)
		<input name="SESS_SESSION_DURATION" value="10" type="hidden">
		<input type="hidden" name="SESS_OUT_MSG" value="Your session will expire in 2 mins, this is the last time you can refresh your session.">

		aria-invalid="false"
		events: change , getData , keydown , keypress , keyup , setData
		
		
		<svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path></svg>
		<button class="Tg7LZd" jsname="Tg7LZd" aria-label="Google Search" type="button"> 
		<div jscontroller="iDPoPb" class="a4bIc" jsname="gLFyf" jsaction="dFyQEf;input:d3sQLd;focus:dFyQEf;blur:jI3wzf"><div class="vdLsw gsfi" jsname="vdLsw"></div>
		jsaction="paste:puy29d" aria-autocomplete="both" 
		
// clone e-mail

		<input type="email" name="WDS_CONFIRM_EMAIL_1" id="emailConfirmation" placeholder="" required="" aria-required="true" data-rule-equaltonocase="#CONTACT_POINT_EMAIL_1" data-msg-email="Contact Information : Invalid <a>e-mail address</a>." autocomplete="off" data-msg-required="Contact Information : <a>Email confirmation</a> should be the same as the first mail" data-msg-equaltonocase="Contact Information : <a>Email confirmation</a> should be the same as the first mail" class="" aria-describedby="emailConfirmation-error" aria-invalid="false">
<input type="email" name="WDS_CONFIRM_EMAIL_1" id="emailConfirmation" placeholder="" required="" aria-required="true" data-rule-equaltonocase="#CONTACT_POINT_EMAIL_1" data-msg-email="Contact Information : Invalid <a>e-mail address</a>." autocomplete="off" data-msg-required="Contact Information : <a>Email confirmation</a> should be the same as the first mail" data-msg-equaltonocase="Contact Information : <a>Email confirmation</a> should be the same as the first mail" class="" aria-describedby="emailConfirmation-error" aria-invalid="false">
		<input type="hidden" id="modsURL"> <div class="copyOver"></div> -->  
		
		<input name="SESS_TIMEOUT_NOTIFICATION_ADVANCE" value="2" type="hidden">
		
		
		// Clearify confusing room policies
		if (window.location.hostname === 'secure.booking.com') { bp_prepayment_policy    font-size: 160% }
		
		// remove:    link rel="preload"
		// experimental: remove: script type = "application/ld+json"
		
			ctHidden form-control
			
			// FOR CSS :
			
			.noopclass{}
			
			// DHOPPING    Base.cors: Sending async post request to https://writer.cardinalcommerce.com/prod/log with a timeout value of 30000ms

			
			Base.Events.PostMessageHandler: Post Message message received: {
 "iss": "582245af33fadd274025e9f2",
 "iat": 1538591194,
 "exp": 1538598394,
 "jti": "9fe8845d-ed25-41c0-8d32-e0a44188da81",
 "ConsumerSessionId": "0_8bb6e5d7-4f74-44ca-a73b-5e86ed65fb9c",
 "ReferenceId": "15911498-cb24-4a1f-9290-89834b76887f",
 "aud": "HD.COM",
 "Payload": {
  "Validated": true,
  "Payment": {
   "Type": "CCA",
   "ProcessorTransactionId": "YVpuCKBzpd2NjUJM22C1",
   "ExtendedData": {
    "CAVV": "",
    "ECIFlag": "07",
    "XID": "WVZwdUNLQnpwZDJOalVKTTIyQzE=",
    "PAResStatus": "B",
    "SignatureVerification": "Y"
   }
  },
  "ActionCode": "NOACTION",
  "ErrorNumber": 0,
  "ErrorDescription": "Success"
 }
}
			
			// SHOPPING
			
			window.dd4b.is_expense_code_enabled: false
			window.dd4b.is_prospective_customer: false
			consumer_data.account_credits: 0
			default_country: "US"
			default_currency: "USD"
			consumer_data.default_card.fingerprint = "xxxXXX000XXXXXxxX"
			consumer_data.default_card.has_existing_card: true
			consumer_data.has_accepted_latest_terms_of_service: true
			consumer_data.has_usable_password = false
			consumer_data.is_guest: false
			consumer_data.is_repeat_consumer; true
			consumer_data.only_ordered_once: false
			consumer_data.order_count: 2
			consumer_data.receive_marketing_push_notifications: false
			consumer_data.receive_push_notifications: false
			consumer_data.referral_code: 
			consumer_data.referree_amount: 700
			consumer_data.show_alcohol_experience: true
			consumer_data.referree_amount_monetary_fields.unit_amount: 700
			experiments.add_promo_code_modal: "treatment"
			orderCart.applied_service_fee: 517
			orderCart.applied_service_rate: 18
			orderCart.asap_time: 44
			orderCart.cancelled_at: null
			orderCart.charge: null
			orderCart.dasher_location_available: false
			orderCart.dasher_route_available: false
			orderCart.delivery_fee_details.discount.amount.unit_amount: 499
			orderCart.delivery_fee: 100
			orderCart.driver_confirmed_time: null
			orderCart.extra_sos_delivery_fee: 0
			orderCart.driver_approaching_customer_time: null
			orderCart.group_cart: false
			orderCart.promo_code.discount_percent: null
			orderCart.inflation_amount: 0
			order_cart_data.pricing_strategy: ""hybrid_fee""
			
			
			// FOR ADMIN / BETA:
			
			window.STAGING: true
			window.PRODUCTION: false
			window.DEBUG: true
			fake_checkout_css: "https://ingest.doordash.com/noop_checkout.css"
			use_new_submit_cart_api: false
			dd4b
			
			// FOR LESS TRACKING
			
			window.FB_ID: "4016967232XXXXX" (Random Last)
			
			// autoconfirm auto agree:
			<input type="checkbox" name="chkConfirm" id="chkConfirm" value="checkbox">
			
			// performance:
			performance.memory.jsHeapSizeLimit
			window.performance.memory.jsHeapSizeLimit 2217857988
			performance.memory.totalJSHeapSize performance.memory.totalJSHeapSize
			performance.memory.usedJSHeapSize performance.memory.usedJSHeapSize
			performance.navigation.redirectCount 1
			document.fonts.status "loaded"
			document.designMode = "on"
			outerHeight 
			pageYOffset
			clientInformation.deviceMemory 4
			clientInformation.hardwareConcurrency 2
			more  events:
			onKeyUpNew
			onKeyUp2
			ogcctxfunc8675309
			nothingtest
			navigator.budget.__proto__[""Symbol(Symbol.toStringTag)""]
			locationbar
			locationbar.visible true
			innerWidth
			i
			clientInformation.doNotTrack true
			clientInformation.onLine true
			bType "IE"
			AudioContext false
			isSecureContext true
			history.length 10
			history.scrollRestoration auto
			history.state null
			
			document.pictureInPictureEnabled false
			document.wasDiscarded false
			document.visibilityState = visible
			document.webkitHidden false
		document.hidden false
			nothingtest 14
			meta.paymentsdk false
			meta.geolocation "US"
			meta.deployMode true
			meta.corp false
			meta.corp true
			 meta.logURL ""
			 
			 parent.$AddBankModel.clearCache
			 parent.$AddBankModel.clearCache
			 parent.TLT.logGeolocation
			 parent.TLT.logDOMCapture
			 parent.TLT._hasSameOrigin
			 pre.freeReturnShippingEcForcedSignupExp
			 
			
			ng-valid-maxlength ng-touched
			ng-isolate-scope
			ng-class="{'validated': billingAddressValidated}"
			<xo-xoon-header
			<xo-message
			<xo-message
			 <div ui-view="" class="ng-scope">
			 
			 
			 global-header
			 globalHeader
			 utilities
			 
			pre.freeReturnShippingEcOptionalSignupExp.res.data
tracking_tags: "qt=4967,10061,5402,10719,7503,7509,7516,7651,8692,8719,8858,9081,9108,4303,5520,10547&qc=2621440,2623488,2622464,2623488,2622464,2623488,2621440,2621440,2622464,2623488,2622464,2621440,2623488,2623488,2623488&uqt=2567&uqc=2621440"
treatments: []
__proto__: Object


			navigator.plugins.__proto__[""Symbol(Symbol.unscopables)""].keys
		
		<a class="spout-header-close placement-top-offscreen spout-mode-" href="#" id="spout-header-close"></a>
		
		function Yetii(){this.defaults={id:null,active:1,interval:null,wait:null,persist:null,tabclass:"tab",transitionclass:"transition",
		activeclass:"active",callback:null,leavecallback:null,toggle:false};this.activebackup=null;for(var n in arguments[0]){this.defaults[n]=arguments[0][n]}this.getTabs=function(){var a=[];var b=document.getElementById(this.defaults.id).getElementsByTagName("*");var c=new RegExp("(^|\\s)"+this.defaults.tabclass.replace(/\-/g,"\\-")+"(\\s|$)");for(var i=0;i<b.length;i++){if(c.test(b[i].className)){a.push(b[i])}}return a};this.links=document.getElementById(this.defaults.id+"-nav").getElementsByTagName("a");this.listitems=document.getElementById(this.defaults.id+"-nav").getElementsByTagName("li");this.show=function(a){for(var i=0;i<this.tabs.length;i++){if((i+1)==a && (!this.defaults.toggle || !this.hasClass(this.tabs[i],this.defaults.activeclass)) ){this.removeClass(this.tabs[i],this.defaults.transitionclass);this.addClass(this.tabs[i],this.defaults.activeclass);this.addClass(this.links[i],this.defaults.activeclass);this.addClass(this.listitems[i],this.defaults.activeclass+"li")}else{this.addClass(this.tabs[i],this.defaults.transitionclass);this.removeClass(this.tabs[i],this.defaults.activeclass);this.removeClass(this.links[i],this.defaults.activeclass);this.removeClass(this.listitems[i],this.defaults.activeclass+"li")}}if(this.defaults.leavecallback&&(a!=this.activebackup)){this.defaults.leavecallback(this.defaults.active)}this.activebackup=a;this.defaults.active=a;if(this.defaults.callback){this.defaults.callback(a)}};this.rotate=function(a){this.show(this.defaults.active);this.defaults.active++;if(this.defaults.active>this.tabs.length){this.defaults.active=1}var b=this;if(this.defaults.wait){clearTimeout(this.timer2)}this.timer1=setTimeout(function(){b.rotate(a)},a*1000)};this.next=function(){var a=(this.defaults.active+1>this.tabs.length)?1:this.defaults.active+1;this.show(a);this.defaults.active=a};this.previous=function(){var a=((this.defaults.active-1)==0)?this.tabs.length:this.defaults.active-1;this.show(a);this.defaults.active=a};this.previous=function(){this.defaults.active--;if(!this.defaults.active){this.defaults.active=this.tabs.length}this.show(this.defaults.active)};this.gup=function(a){a=a.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");var b="[\\?&]"+a+"=([^&#]*)";var c=new RegExp(b);var d=c.exec(window.location.href);if(d==null){return null}else{return d[1]}};this.parseurl=function(a){var b=this.gup(a);if(b==null){return null}if(parseInt(b)){return parseInt(b)}if(document.getElementById(b)){for(var i=0;i<this.tabs.length;i++){if(this.tabs[i].id==b){return(i+1)}}}return null};this.createCookie=function(a,b,c){if(c){var d=new Date();d.setTime(d.getTime()+(c*24*60*60*1000));var e="; expires="+d.toGMTString()}else{var e=""}document.cookie=a+"="+b+e+"; path=/"};this.readCookie=function(a){var b=a+"=";var d=document.cookie.split(";");for(var i=0;i<d.length;i++){var c=d[i];while(c.charAt(0)==" "){c=c.substring(1,c.length)}if(c.indexOf(b)==0){return c.substring(b.length,c.length)}}return null};this.contains=function(a,b,c){return a.indexOf(b,c)!=-1};this.hasClass=function(a,b){return this.contains(a.className,b," ")};this.addClass=function(a,b){if(!this.hasClass(a,b)){a.className=(a.className+" "+b).replace(/\s{2,}/g," ").replace(/^\s+|\s+$/g,"")}};this.removeClass=function(a,b){try{a.className=a.className.replace(new RegExp("(^|\\s)"+b+"(?:\\s|$)"),"$1");a.className.replace(/\s{2,}/g," ").replace(/^\s+|\s+$/g,"")}catch(err){}};this.tabs=this.getTabs();this.defaults.active=(this.parseurl(this.defaults.id))?this.parseurl(this.defaults.id):this.defaults.active;if(this.defaults.persist&&this.readCookie(this.defaults.id)){this.defaults.active=this.readCookie(this.defaults.id)}this.activebackup=this.defaults.active;this.show(this.defaults.active);var f=this;for(var i=0;i<this.links.length;i++){this.links[i].customindex=i+1;this.links[i].onclick=function(){if(f.timer1){clearTimeout(f.timer1)}if(f.timer2){clearTimeout(f.timer2)}f.show(this.customindex);if(f.defaults.persist){f.createCookie(f.defaults.id,this.customindex,0)}if(f.defaults.wait){f.timer2=setTimeout(function(){f.rotate(f.defaults.interval)},f.defaults.wait*1000)}return false}}if(this.defaults.interval){this.rotate(this.defaults.interval)}};

		<div id="remember-me-container" class="input-container"><fieldset class="form-group"><div class="form-check"><label for="remember-me" class="form-check-label custom-control custom-checkbox" id="label-remember-me"><input id="remember-me" type="checkbox" aria-labelledby="label-remember-me" aria-required="false" class="custom-control-input" value="false"><span class="custom-control-indicator"></span><span class="custom-control-description">Keep me signed in</span></label></div></fieldset><span id="remember-me-tip"> <span role="button" aria-haspopup="true" class="uxicon uxicon-help" style="cursor: pointer; outline: none;"></span></span></div>
		
	
		allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox
		
		<iframe src="https://www.google.com/recaptcha/" width="304" height="78" role="presentation" name="a-vq1lkivkrwdp" 
		frameborder="0" scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts
		allow-top-navigation allow-modals allow-popups-to-escape-sandbox"></iframe>
		
		
		target="_blank"
		
		 allowfullscreen="" allow="autoplay"  <video title="Advertisement" webkit-playsinline="true" playsinline="true" 
		 style="background-color: rgb(0, 0, 0); position: absolute; width: 100%; height: 100%; left: 0px; top: 0px;" src=""></video>
		 
		 
    window.sso = window.sso || {};
	
	<button data-eid="uxp.hyd.utility_header.market_selector.click" aria-expanded="false" aria-haspopup="true" tabindex="0" class="btn tray-toggle" id="" type="button" aria-label="Content Language Selector. Currently set to United States - English."><span>United States - English</span></button>
	
	<script>
  document.authReady = true;
  //$(document).attr('authReady', true);
  </script>
  
  <input type="hidden" id="recaptcha-token" value="
  
  <script nonce="LP0DwIg9Hr4J/BX6F4TLZpItVwk">'use strict';try{
	  
	  <button disabled="" tabindex="0" class="btn btn-primary disabled submit-button" 
	  id="PasswordRecoveryLandingSubmitButton" type="submit">Submit</button>
	  
	 [3].n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.__proto__.constructor.isFrozen
	 [3].n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.__proto__.constructor.isSealed.__proto__.apply.__proto__.__proto__.__lookupGetter__.__proto__[""set caller""].__proto__[""set arguments""].__proto__[""set arguments""].__proto__.toString[""Symbol(src)_1.x1guws7gwb""]
	 [3].n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.__proto__.constructor.isSealed.__proto__.apply.__proto__.__proto__.__lookupGetter__.__proto__[""set caller""].__proto__[""set arguments""].__proto__[""set arguments""].__proto__.constructor.prototype[""get arguments""].__proto__[""get caller""].__proto__[""Symbol(Symbol.hasInstance)""]
	 [3].n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner.__proto__.constructor.isSealed.__proto__.apply.__proto__.__proto__.__lookupGetter__.__proto__[""set caller""].__proto__[""set arguments""].__proto__[""set arguments""].__proto__.constructor.__proto__[""set caller""].__proto__.toString[""Symbol(src)_1.x1guws7gwb""]
	  [""0""].a._events.resize.__proto__.values[""Symbol(src)_1.x1guws7gwb""]
	  [""0""].a._events.resize.__proto__.concat
	  handler.prototype.__proto__.propertyIsEnumerable
	  handler.prototype.__proto__.isPrototypeOf
	  handler.prototype.__proto__.hasOwnProperty
	  
	  
	  handler.prototype.__proto__.hasOwnProperty
	  
	  
	  
	  
	  
	  
	  
	         window.ssoGlobals = window.ssoGlobals || {};
       window.ssoGlobals.status =  undefined ;
       window.ssoGlobals.plid =  Number('1') ;
       window.ssoGlobals.version = 'v1';
       window.ssoGlobals.market = "en_US";
       window.ssoGlobals.enable_clicktale =  false ;
       window.ssoGlobals.is_china =  false ;
       window.ssoGlobals.url_params = {'app': 'email', 'realm': 'pass'};
       window.ssoGlobals.origin_path = 'v1%2Faccount%2Freset'

	   
	   te; transition: visibility 0s linear 0.3s, opacity 0.3s linear 0s; opacity: 0; visibility: hidden; z-index: 2000000000; left: 0px; top: -10000px;">
	   <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: rgb(255, 255, 255);
	   opacity: 0.05;"></div><div style="border: 11px solid transparent; width: 0px; height: 0px; position: absolute; pointer-events: none; 
	   margin-top: -11px; z-index: 2000000000;"></div><div style="border: 11px solid transparent; width: 0px;
	   height: 0px; position: absolute; pointer-events: none; margin-top: -11px; z-index: 2000000000;"></div><div style="z-index: 2000000000; position: relative; width: 0px; height: 0px;
	   
	  
	  <div class="g-recaptcha" data-sitekey="6LcPGAoUAAAAAMAAlCzGdhSjBYpeIOvdML-GQ8Vi" data-callback="_grecaptcha.data-callback" 
	  data-expired-callback="_grecaptcha.data-expired-callback"><div style="width: 304px; height: 78px;"><div><
	  frame src="" width="304" height="78" role="presentation" name="a-vq1lkivkrwdp" frameborder="0" 
	  scrolling="no" sandbox="allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox">
	  </iframe></div><textarea id="g-recaptcha-response" name="g-recaptcha-response" class="g-recaptcha-response" style="width: 250px; height: 40px; border: 1px solid rgb(193, 193, 193); margin: 10px 25px; padding: 0px; resize: none; display: none;"></textarea></div></div>
	  
	  
<form autocomplete="off" class="pm7SmuKv3bPqJByQSCplh"><div><div data-input-wrapper="true"><div><label for="InputText" class="_1er5djadpjIGg6Q2YAOj7g _2V5rXMmqBwNkdYFDmY1BjK"><span>

<input type="tel" class="MGT5W_n6-oDUstcSv2tot" id="InputText" value="(23 -" placeholder="Phone Number">

	  <a href="https://my.godaddy.com" data-tcc-ignore="true" 
	  data-market="en-MY" data-eid="uxp.hyd.utility_header.market_selector.en_my.click">
	  
	 
	<span data-tcc-ignore="true"><strong data-tcc-ignore="true">Malaysia</strong> - <!-- -->English</span></a>
	
releasePointerCapture
	
	  login-btn-sms-mobile
	  login-btn-sms-desktop
	  @import
	  
	;opacity:1
-webkit-file-upload-button{-webkit-appearance:button;font:inherit}
}@supports (-ms-accelerator:true)
@media (-ms-high-contrast:active),(-ms-high-contrast:none)
:-webkit-search-decoration{-webkit-appearance:none}::-webkit-input-placeholder{color:inherit;opacity:.54}

	 <style type="text/css">@import url(https://fast.fonts.net/;@import url(//hello.myfonts.net/count/31a5f3);/*! normalize.css v4.1.1 | MIT License | github.com/necolas/normalize.css html{font-family:sans-serif;
	 -ms-text-size-adjust:100%;
	 -webkit-text-size-adjust:100%}
	 body{margin:0}
	 article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,
	 summary{display:block}audio,canvas,progress,video{display:inline-block}audio:not([controls]){display:none;height:0}
	 progress{vertical-align:baseline}[hidden],template{display:none}a{background-color:transparent;-webkit-text-decoration-skip:objects}a:active,a:hover{outline-width:0}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:inherit;font-weight:bolder}dfn{font-style:italic}h1{font-size:2em;margin:.67em 0}mark{background-color:#ff0;color:#000}small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}svg:not(:root){overflow:hidden}code,kbd,pre,samp{font-
	  <style type="text/css">@import url(https://fast.fonts.net/t/1.css?apiType=css&projectid=0eaf9271-ea5f-4302-95a2-22f5119793e6);@import url(//hello.myfonts.net/count/31a5f3);/*! normalize.css v4.1.1 | MIT License | github.com/necolas/normalize.css html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}
	 

	 body{margin:0}article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary{display:block}audio,canvas,progress,video{display:inline-block}audio:not([controls]){display:none;height:0}progress{vertical-align:baseline}[hidden],
	  template{display:none}a{background-color:transparent;-webkit-text-decoration-skip:objects}a:active,a:hover{outline-width:0}abbr[title]{border-bottom:none;text-decoration:underline;text-decoration:underline dotted}b,strong{font-weight:inherit;font-weight:bolder}dfn{font-style:italic}h1{font-size:2em;margin:.67em 0}mark{background-color:#ff0;color:#000}
	  small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}sub{bottom:-.25em}
	  sup{top:-.5em}img{border-style:none}svg:not(:root){overflow:hidden}code,kbd,pre,samp{font-
	 <style type="text/css">@import url(https://fast.fonts.net/t/1.css?apiType=css&projectid=0eaf9271-ea5f-4302-95a2-22f5119793e6);@import url(//hello.myfonts.net/count/31a5f3);/*! normalize.css v4.1.1 | MIT License | github.com/necolas/normalize.css 
	 
	 html{font-family:sans-serif;-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}body{margin:0}
	 article,aside,details,figcaption,figure,footer,header,main,menu,nav,section,summary
	 {display:block}audio,canvas,progress,video{display:inline-block}audio:not([controls]){display:none;height:0}
	 progress{vertical-align:baseline}[hidden],template{display:none}
	 a{background-color:transparent;-webkit-text-decoration-skip:objects}
	 a:active,a:hover{outline-width:0}abbr[title]
	 {border-bottom:none;text-decoration:underline;text-decoration:underline dotted}
	 b,strong{font-weight:inherit;font-weight:bolder}dfn{font-style:italic}h1{font-size:2em;margin:.67em 0}
	 mark{background-color:#ff0;color:#000}
	 small{font-size:80%}sub,sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}
	 sub{bottom:-.25em}sup{top:-.5em}img{border-style:none}svg:not(:root){overflow:hidden}code,kbd,pre,samp{font-
width:calc(99.9% * 5/12 - 0.291666666666667rem)}
	 @media (-ms-high-contrast:active),(-ms-high-contrast:none)
	 
	 @font-face{font-family:Mittelschrift;src:url(/dist/eba0c0abe3956dd8b3f3dbb5e1844ca7.eot?#iefix);
	 src:url(/dist/eba0c0abe3956dd8b3f3dbb5e1844ca7.eot?#iefix) 
	 
	 
	 .MGT5W_n6-oDUstcSv2tot{-webkit-appearance:none;
	 
	 @media (min-width:800px)
	 
	 
	 <meta name="theme-color" content="#549c74">
	 	<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
	<link rel="shortcut icon" href="/img/favicon/favicon.ico">
	<link rel="manifest" href="/img/favicon/manifest.json">
	<meta name="msapplication-TileColor" content="#549c74">
	<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
	<meta name="format-detection" content="telephone=no">
	
	window.TOKEN = 
	Window.ID =
	Window.
	window.zEmbed
	js-iframe-async
	</noscript>
	
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<input type="file" class="userphoto-inputfield" id="FileSelectDefault" name="FileSelectDefault" onchange="O365Profile.UserPhoto.ValidateAndPreviewSelectedFile(this);">


	
	//<![CDATA[
(function() {
var _analytics_scr = document.createElement('script');
_analytics_scr.type = 'text/javascript'; _analytics_scr.async = true; _analytics_scr.src = '/_Incapsula_Resource?SWJIYLWA=719d34d31c8e3a6e6fffd425f7e032f3&ns=1&cb=234182848';
var _analytics_elem = document.getElementsByTagName('script')[0]; _analytics_elem.parentNode.insertBefore(_analytics_scr, _analytics_elem);
})();
// ]]>


console.clear();

,ip,ipbits,ipbypass,itag,lmt,mime,mip,mm,mn,ms,mv,pl,ratebypass,requiressl

//  Remove Auto Play from video element:  ,ip,ipbits,ipbypass,itag,lmt,mime,mip,mm,mn,ms,mv,pl,ratebypass,requiressl

<meta name="viewport" content="width=device-width">



hidden-xs
	 a download="The Verve - Bitter Sweet Symphony.mp4"
	 
	 btn-danger
	btn-success
	  aria-expanded="false" aria-controls="moreOptions1"
	  
	   async="async" data-cfasync="false"
	   aria-multiselectable="true"
	  aria-multiselectable="true"
	  
	  collapsed
	  ui-accordion-header-collapsed
	  // cookie ui-accordion-content ui-corner-bottom ui-helper-reset ui-widget-content"
	  
	  ssk-sticky ssk-top ssk-right ssk-sticky-hide-xs
	  ssk-sticky ssk-xs hidden visible-xs
	  data-ssk-ready="true"
	  
	  position: fixed; top: 0px; bottom: 0px; left: 0px; right: 0px; 
	  z-index: 2147483647; background: black; 
	  opacity: 0.01; height: 608px; width: 1366px;
	  position: absolute; left: -99999px;
		*/

		/* Add Title and Tooltip to all elements
	 	 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
		 */
		 
		 	if (!allElements[i].hasAttribute('title')) {
          allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
		console.log('%c  ' + i + ' - Added title to attribute')
    }	
		 
	  if (allElements[i].hasAttribute('aria-hidden')) {
        allElements[i].setAttribute('aria-hidden','false');
			console.log('%c  ' + i + ' - Forced false aria-hidden value!','color: green;font-weight: 500;')
    }
	
	  if (allElements[i].hasAttribute('aria-busy')) {
        allElements[i].setAttribute('aria-busy','false');
			console.log('%c  ' + i + ' - Forced false aria-busy value!','color: green;font-weight: 500;')
    }
	
		  if (allElements[i].hasAttribute('aria-invalid')) {
        allElements[i].setAttribute('aria-invalid','false');
			console.log('%c  ' + i + ' - Forced false aria-invalid value!','color: green;font-weight: 500;')
    }
	
	
		  if (allElements[i].hasAttribute('data-pii')) {
        allElements[i].setAttribute('data-pii','');
			console.log('%c  ' + i + ' - Forced blank data-pii value!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('aria-invalid')) {
          allElements[i].removeAttribute('aria-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-invalid attribute!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('ng-keypress')) {
          allElements[i].removeAttribute('ng-keypress');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-keypress attribute!','color: green;font-weight: 500;')
    }
	
	/*
		if (allElements[i].hasAttribute('shipping-form-focus')) {
          allElements[i].removeAttribute('shipping-form-focus');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed shipping-form-focus attribute!','color: green;font-weight: 500;')
    }
	*/
	
	
	
	
	if (allElements[i].hasAttribute('unless-feature')) {
          allElements[i].removeAttribute('unless-feature');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless-feature attribute!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('unless')) {
          allElements[i].removeAttribute('unless');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('unknown')) {
          allElements[i].removeAttribute('unknown');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed unknown attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('ws-error')) {
          allElements[i].removeAttribute('ws-error');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ws-error attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('data-rule-allowedincontext')) {
          allElements[i].removeAttribute('data-rule-allowedincontext');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-rule-allowedincontext attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('minlength')) {
          allElements[i].removeAttribute('minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed minlength attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('numberonly')) {
          allElements[i].removeAttribute('numberonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - removed numberonly attribute!','color: green;font-weight: 500;')
    }
	
	
	
	   if (allElements[i].hasAttribute('foo')) {
        allElements[i].foo = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced foo attribute to false!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('bar')) {
        allElements[i].bar = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced bar attribute to false!','color: green;font-weight: 500;')
    }
	  if (allElements[i].hasAttribute('lang')) {
        allElements[i].lang = "en";
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced lang attribute to en!','color: green;font-weight: 500;')
    }

	
	  if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed required attribute!','color: green;font-weight: 500;')
    }
	
	  if (allElements[i].hasAttribute('aria-valuemax')) {
          allElements[i].removeAttribute('aria-valuemax');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-valuemax attribute!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('aria-valuemin')) {
          allElements[i].removeAttribute('aria-valuemin');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-valuemi attribute!','color: green;font-weight: 500;')
    }
	
	
		  if (allElements[i].hasAttribute('data-rule-luhn')) {
          allElements[i].removeAttribute('data-rule-luhn');
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Removed data-rule-luhn attribute!','color: green;font-weight: 500;')
    }
		  if (allElements[i].hasAttribute('ng-init')) {
          allElements[i].removeAttribute('ng-init');
        highlightElementOrange(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-init attribute!','color: green;font-weight: 500;')
    }
		 
	   if (allElements[i].getAttribute('id') === "form_agree") {
     
	     allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('checkbox')||allElements[i].type('option')||allElements[i].type('radio')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Checked form_agree box')
    }
	   }
	   
	   	   if (allElements[i].getAttribute('id') === "form_agree") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('text')||allElements[i].type('hidden')) { 
	   allElements[i].setAttribute('value','1');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Triggered true for form_agree input')
    }
	   }
	   	   if (allElements[i].getAttribute('id') === "TermsAndConditions") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('text')||allElements[i].type('hidden')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Triggered true for TermsAndConditions input')
    }
	   }
	      if (allElements[i].getAttribute('id') === "TermsAndConditions") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('checkbox')||allElements[i].type('option')||allElements[i].type('radio')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Checked form_agree box')
    }
	   }
	   
	   
	
	 
	   if (allElements[i].hasAttribute('ng-required')) {
        allElements[i].removeAttribute('ng-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-required attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-empty')) {
        allElements[i].removeAttribute('ng-empty');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-empty attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-invalid-required')) {
        allElements[i].removeAttribute('ng-invalid-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid-required attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('ng-pristine')) {
        allElements[i].removeAttribute('ng-pristine');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-pristine attribute!','color: green;font-weight: 500;')
    }
 if (allElements[i].hasAttribute('ng-untouched')) {
        allElements[i].removeAttribute('ng-untouched');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-untouched attribute!','color: green;font-weight: 500;')
    } 
	

    if (allElements[i].hasAttribute('maxLength')) {
        allElements[i].removeAttribute('maxLength');
        highlightElementGreen(allElements[i]);
				console.log('%c  ' + i + ' - Removed maxLength attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-disabled attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-ng-minlength')) {
        allElements[i].removeAttribute('data-ng-minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-minlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-ng-maxlength')) {
        allElements[i].removeAttribute('data-ng-maxlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-maxlength attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('data-ng-pattern')) {
        allElements[i].removeAttribute('data-ng-pattern');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-pattern attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('my-maxlength')) {
        allElements[i].removeAttribute('my-maxlength');
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Removed my-maxlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-rule-regularexpression')) {
        allElements[i].removeAttribute('data-rule-regularexpression');
					console.log('%c  ' + i + ' - Removed data-rule-regularexpression attribute!','color: green;font-weight: 500;')
        highlightElementGreen(allElements[i]);
    }
    if (allElements[i].hasAttribute('pattern')) {
        allElements[i].removeAttribute('pattern');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed pattern attribute!','color: green;font-weight: 500;')
    }
    if (allElements[i].type === "email") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
    if (allElements[i].type === "url") {
        allElements[i].type = "text";
    highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
	  if (allElements[i].type === "tel") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
		 if (allElements[i].type === "select-one") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
		 if (allElements[i].type === "select") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
		 if (allElements[i].type === "inputbox") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
		  if (allElements[i].type === "password") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
		  if (allElements[i].type === "option") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed element type to text!','color: green;font-weight: 500;')
    }
	 
    }
	
	 }
	  
	 
	


			
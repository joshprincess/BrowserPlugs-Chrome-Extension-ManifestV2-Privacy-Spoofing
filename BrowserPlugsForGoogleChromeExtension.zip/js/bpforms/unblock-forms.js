		var all = true;
		var labels = true;
		var divs = true;
		var buttons = true;
		var input_controls = true;
  
console.log ('Browser Plugs is enabling form elements without restrictions on ' + window.location.hostname);

 
		function highlightElement(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementPink(anElement) {
    anElement.style.border = "thin solid #e83e8c";
}
function highlightElementWhite(anElement) {
    anElement.style.border = "thin solid white";
}
function highlightElementGreenForce(anElement) {
    anElement.style.border = "thin solid #28a745";
}
function highlightElementAuto(anElement) {
   console.log('Element Debug: ' + anElement.type);

if (anElement.type === "hidden") anElement.style.border = "thin solid #dc3545";
if (anElement.type === "hidden") anElement.style.backgroundColor = "orange";

if (anElement.type === "text") anElement.style.boxSizing = "thin solid #dc3545";



}
function highlightElementGreen(anElement) {
 if (anElement.type === 'div') return;
  if (anElement.type === 'Div') return;
if (anElement.type === 'DIV') return;
if (anElement.type === 'span') return;
if (anElement.type === 'hidden') return;
if (anElement.type === 'undefined') return;
if (anElement.type === undefined) return;
if (anElement.type === 'li') return;
if (anElement.type === 'A') return;
if (anElement.type === 'a') return;
if (anElement.type === 'LI') return;
if (anElement.type === 'fieldset') return;

if (anElement.type === '') return;
//console.log ('type green: ' + anElement.type);
 if (anElement.type !== 'div' && anElement.type !== 'span' && anElement.type !== 'link' && anElement.type !== 'td' && anElement.type !== 'a' && anElement.type !== 'form' && anElement.type !== 'i' && anElement.type !== '' && anElement.type !== 'text/javascript'  && anElement.type !== 'submit' && anElement.type !== 'button') anElement.style.border = "thin solid #28a745";
 
 if (anElement.type === 'submit' || anElement.type === 'button') {
	 
 if (!allElements[i].hasAttribute('background-image') && !allElements[i].hasAttribute('background') && !allElements[i].style.backgroundimage) anElement.style.border = "thin solid #28a745";

 }

 // jsname   if (!allElements[i].hasAttribute('background-image') && !allElements[i].hasAttribute('background') && !allElements[i].style.backgroundimage && anElement.type !== 'div' && anElement.type !== 'span' && anElement.type !== 'link' && anElement.type !== 'td' && anElement.type !== 'a' && anElement.type !== 'form' && anElement.type !== 'i' && anElement.type !== '' && anElement.type !== 'text/javascript') anElement.style.border = "thin solid #28a745";


	//if var x = document.getElementById("myP").style.borderTop

 
 // Get the value of a <p> element's top-border  var x = document.getElementById("myP").style.borderTop;

 }
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid #dc3545";

}
function highlightElementRedBG(anElement) {
    anElement.style.border = "thin solid #dc3545";
anElement.style.backgroundColor = "orange";

}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid #ffc107";
}
function highlightElementBlack(anElement) {
    anElement.style.border = "thin solid #343a40";
}
function highlightElementFrame(anElement) {
    anElement.style.frameborder = "thin solid #343a40";
}
function highlightElementPurple(anElement) {
    anElement.style.border = "thin solid #6f42c1";
}
function highlightElementBlue(anElement) {
    anElement.style.border = "thin dotted #007bff";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){
/*
	losTD = document.querySelectorAll('input[type=td]');
		losTR = document.querySelectorAll('input[type=tr]');
		losSpan = document.querySelectorAll('input[type=span]');
		losLabels = document.querySelectorAll('input[type=label]');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
*/		

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('a');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
if (max > 100000) max = 100000;
var paint = "rgb(255,200,200)";

for (var i = 0; i < max; i++) {

if (allElements[i].type !== undefined && allElements[i].type !== 'text/javascript' && allElements[i].type !== '' && allElements[i].type !== 'text/css' && allElements[i].type !== 'image/ico' && allElements[i].type !== 'image/png') console.log('%c ' + i + ' / ' + max + ' | id: ' + allElements[i].getAttribute("id") + ' | async: ' + allElements[i].async + ' | title: ' + allElements[i].getAttribute("title") + ' | alt : ' + allElements[i].getAttribute("alt") + ' | type: ' + allElements[i].type + ' ','color: blue;font-weight: 500;');

 
// Development
/*
          allElements[i].removeAttribute('style');
          allElements[i].removeAttribute('ng-class');
          allElements[i].removeAttribute('class');
          allElements[i].removeAttribute('ng-click');
          allElements[i].removeAttribute('ng-keypress');
          allElements[i].removeAttribute('on-clicks');
          allElements[i].removeAttribute('ng-hide');
          allElements[i].removeAttribute('content');
          allElements[i].removeAttribute('src');
		  allElements[i].removeAttribute('data-aui-build-date');
		  data-a-class
		  data-p13n-global
		  data-p13n-feature-metadata
		  data-a-transition-strategy
		  data-a-carousel-options
		  data-p13n-feature-metadata
		  data-p13n-feature-name
		  
		  
*/
// ff0404 red to green || id _page_warning
// For ALL elements (including undefined), Targeted


														
allElements[i].classList.remove('ng-isolate-scope');
										allElements[i].classList.remove('error-modal-btn');
										allElements[i].classList.remove('u-dis-b');
										allElements[i].classList.remove('ng-invalid');
 										allElements[i].classList.remove('error');

												allElements[i].classList.remove('modal-content');
					allElements[i].classList.remove('error-modal');
					allElements[i].classList.remove('modal-backdrop');
					allElements[i].classList.remove('need-help');	
						allElements[i].classList.remove('need-help');	
					allElements[i].classList.remove('disabledBtn');
					 	allElements[i].classList.remove('disabledButton');
allElements[i].classList.remove('btnDisabled');
 if (allElements[i].getAttribute("id") === "error") allElements[i].setAttribute("id","success")
	  if (allElements[i].getAttribute("id") === "checkout_device_fingerprint") allElements[i].value = "no-js"
   if (allElements[i].getAttribute("id") === ".form-control[disabled]") allElements[i].setAttribute("id",".form-control")
   if (allElements[i].getAttribute("id") === "form-control[disabled]") allElements[i].setAttribute("id","form-control")

		 if (allElements[i].hasAttribute('async')) {
        allElements[i].removeAttribute('async');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: orange;font-weight: 500;')
    }
	
 if (allElements[i].getAttribute('id') === "updated_spinner") {
         allElements[i].setAttribute('id','');
}
 
 
if (allElements[i].getAttribute("id") === "denied") allElements[i].setAttribute("id","approved")
	 if (allElements[i].getAttribute("id") === "errorJavascript") allElements[i].setAttribute("id","success")

	if (allElements[i].hasAttribute('ws-disabled')) {
          allElements[i].removeAttribute('ws-disabled');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Removed ws-disabled attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('focusable')) {
          allElements[i].setAttribute('focusable','TRUE');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Set focusable attribute to true!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - removed required attribute!','color: green;font-weight: 500;')
    }
	 		
  if (allElements[i].classList.contains('uxicon-locked')) {
	 allElements[i].removeAttribute('hidden');
	allElements[i].removeAttribute('disabled');
		allElements[i].classList.remove('uxicon-locked');
				allElements[i].classList.add('uxicon-unlocked');
				

			console.log('%c  ' + i + ' - Changed uxicon-locked class to uxicon-unlocked!','color: green;font-weight: 500;')

}
   if (allElements[i].classList.contains('form-control-danger' || 'form-error')) {
		allElements[i].classList.remove('form-control-danger');
		allElements[i].classList.remove('form-error');
				allElements[i].classList.add('form-control');
				
				

			console.log('%c  ' + i + ' - Removed form-control-danger or form-error class!','color: green;font-weight: 500;')

}


 
 		 if (allElements[i].hasAttribute('ng-hide')) {
        allElements[i].removeAttribute('ng-hide');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-hide attribute!','color: orange;font-weight: 500;')
    }
			  
 
	 if (allElements[i].hasAttribute('disable')) {
        highlightElementGreenForce(allElements[i]);
	  allElements[i].removeAttribute('disable');
					console.log('%c  ' + i + ' - Removed disable attribute!','color: orange;font-weight: 500;')
    }
			  
			 if (allElements[i].hasAttribute('unselectable')) {
        allElements[i].removeAttribute('unselectable');
        highlightElementGreenForce(allElements[i]);
					console.log('%c  ' + i + ' - Removed unselectable attribute!','color: orange;font-weight: 500;')
    }
			  
			  
			  		
			 if (allElements[i].hasAttribute('invalidvaluemessage')) {
        allElements[i].removeAttribute('invalidvaluemessage');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed invalidvaluemessage attribute!','color: green;font-weight: 500;')
    }
	
			
			 if (allElements[i].hasAttribute('cssfocusnegative')) {
        allElements[i].removeAttribute('cssfocusnegative');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed cssfocusnegative attribute!','color: green;font-weight: 500;')
    }
	
		 if (allElements[i].hasAttribute('validempty')) {
        allElements[i].removeAttribute('validempty');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed validempty attribute!','color: green;font-weight: 500;')
    }
	
	
		 if (allElements[i].hasAttribute('minimumvalue')) {
        allElements[i].removeAttribute('minimumvalue');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed minimumvalue attribute!','color: green;font-weight: 500;')
    }
	
			 if (allElements[i].hasAttribute('data-parsley-minword')) {
        allElements[i].removeAttribute('data-parsley-minword');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-parsley-minword attribute!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('data-parsley-maxwords')) {
        allElements[i].removeAttribute('data-parsley-maxwords');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-parsley-maxwords attribute!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('data-parsley-words')) {
        allElements[i].removeAttribute('data-parsley-words');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-parsley-words attribute!','color: green;font-weight: 500;')
    }
	
			 if (allElements[i].hasAttribute('validationexpression')) {
        allElements[i].removeAttribute('validationexpression');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed validationexpression attribute!','color: green;font-weight: 500;')
    }
		 if (allElements[i].hasAttribute('clientvalidationfunction')) {
        allElements[i].removeAttribute('clientvalidationfunction');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed clientvalidationfunction attribute!','color: green;font-weight: 500;')
    }
	 if (allElements[i].hasAttribute('ismaskededit')) {
        allElements[i].removeAttribute('ismaskededit');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ismaskededit attribute!','color: green;font-weight: 500;')
    }
		 if (allElements[i].hasAttribute('parentcontrol')) {
        allElements[i].removeAttribute('parentcontrol');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed parentcontrol attribute!','color: green;font-weight: 500;')
    }
	
		 if (allElements[i].hasAttribute('parentcontrol')) {
        allElements[i].removeAttribute('parentcontrol');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed parentcontrol attribute!','color: green;font-weight: 500;')
    }
	
	
/*	if (allElements[i].hasAttribute('ng-click')) {
          allElements[i].removeAttribute('ng-click');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-click attribute!','color: green;font-weight: 500;')
    }
	*/
	
	if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }

	if (allElements[i].hasAttribute('onerror')) {
          allElements[i].removeAttribute('onerror');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onerror attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('onerrorupdate')) {
          allElements[i].removeAttribute('onerrorupdate');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onerrorupdate attribute!','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].hasAttribute('contenteditable')) {
          allElements[i].setAttribute('contenteditable','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced contenteditable true!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
	  
	if (allElements[i].hasAttribute('data-alert')) {
          allElements[i].removeAttribute('data-alert');
        highlightElementGreenForce(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-alert attribute!','color: green;font-weight: 500;')
    }
	  
	

if (allElements[i].classList.contains('fa-exclamation-circle')) {

		console.log('%c  ' + i + ' - Coverted fa-exclamation-circle to fa-check!','color: green;font-weight: 500;')
				allElements[i].classList.remove('fa-exclamation-circle');

				allElements[i].classList.add('fa-check');

}

if (allElements[i].classList.contains('fa-ban')) {

		console.log('%c  ' + i + ' - Coverted fa-ban to fa-check!','color: green;font-weight: 500;')
				allElements[i].classList.remove('fa-ban');

				allElements[i].classList.add('fa-check');

}
if (allElements[i].classList.contains('ec-label-icon-bad')) {

		console.log('%c  ' + i + ' - Coverted ec-label-icon-bad to good!','color: green;font-weight: 500;')
				allElements[i].classList.remove('ec-label-icon-bad');

				allElements[i].classList.add('ec-label-icon-good');

}


	 allElements[i].classList.remove('short_balance');
							  allElements[i].classList.remove('alert-box');
							  
							  allElements[i].classList.remove('alertbox');


if (allElements[i].classList.contains('unselected')) {

		console.log('%c  ' + i + ' - Coverted unselected to selected!','color: green;font-weight: 500;')
				allElements[i].classList.remove('unselected');

				allElements[i].classList.add('selected');

}
if (allElements[i].classList.contains('no-toggle')) {

		console.log('%c  ' + i + ' - Removed no-toggle class!','color: green;font-weight: 500;')
				allElements[i].classList.remove('no-toggle');

				allElements[i].classList.add('can-toggle');

}

if (allElements[i].classList.contains('failure')) {

		console.log('%c  ' + i + ' - Coverted failure to success!','color: green;font-weight: 500;')
				allElements[i].classList.remove('failure');

				allElements[i].classList.add('success');
				allElements[i].classList.add('successful');
				allElements[i].classList.add('nofail');
								allElements[i].classList.add('notfailed');
allElements[i].classList.add('hassuccess');
				allElements[i].classList.add('approved');

}

if (allElements[i].classList.contains('hidden-xs')) {

		console.log('%c  ' + i + ' - Coverted hidden-xs to visible-xs!','color: green;font-weight: 500;')
				allElements[i].classList.remove('hidden-xs');

				allElements[i].classList.add('visible-xs');

}
if (allElements[i].classList.contains('MaskedEditError')) {

		console.log('%c  ' + i + ' - Removed MaskedEditError class!','color: green;font-weight: 500;')
				allElements[i].classList.remove('MaskedEditError');


}


if (allElements[i].classList.contains('myx-button-disabled')) {

		console.log('%c  ' + i + ' - Coverted myx-button-disableds to myx-button!','color: green;font-weight: 500;')
				allElements[i].classList.remove('myx-button-disabled');

				allElements[i].classList.add('myx-button');
				        highlightElementGreenForce(allElements[i]);


}
				allElements[i].classList.remove('myx-button-disabled');



if (allElements[i].classList.contains('hidden-sm')) {

		console.log('%c  ' + i + ' - Coverted hidden-sm to visible-sm!','color: green;font-weight: 500;')
				allElements[i].classList.remove('hidden-sm');

				allElements[i].classList.add('visible-sm');

}
if (allElements[i].classList.contains('.myx-button-primary.myx-button-disabled')) {

		console.log('%c  ' + i + ' - Removed .myx-button-primary.myx-button-disabled class!','color: green;font-weight: 500;')
				allElements[i].classList.remove('.myx-button-primary.myx-button-disabled');

				allElements[i].classList.add('.myx-button-primary.myx-button-disabled');
				        highlightElementGreenForce(allElements[i]);

}
			

if (allElements[i].classList.contains('.myx-button-disabled' || 'myx-button-disabled' )) {

		console.log('%c  ' + i + ' - Removed .myx-button-disabled class!','color: green;font-weight: 500;')
				allElements[i].classList.remove('.myx-button-disabled');

				allElements[i].classList.add('.myx-button-disabled');
				        highlightElementGreenForce(allElements[i]);


}
if (allElements[i].classList.contains('ux-tabs-wiz-step-incomplete' || 'ux-tabs-wiz-step-incomplete')) {

		console.log('%c  ' + i + ' - Changed ux-tabs-wiz-step-incomplete class from incomplete to complete!','color: green;font-weight: 500;')
				allElements[i].classList.remove('.ux-tabs-wiz-step-incomplete');
				allElements[i].classList.remove('ux-tabs-wiz-step-incomplete');

				allElements[i].classList.add('.ux-tabs-wiz-step-complete');
				allElements[i].classList.add('ux-tabs-wiz-step-complete');
				        highlightElementGreenForce(allElements[i]);


}

	
	if (allElements[i].classList.contains('input-validation-error')||allElements[i].classList.contains('form-validation-error') && !allElements[i].classList.contains('input-validation-error')) {

		console.log('%c  ' + i + ' - Removed input-validation-error class!','color: green;font-weight: 500;')
		console.log('%c  ' + i + ' - added valid class!','color: green;font-weight: 500;')

		allElements[i].classList.remove('input-validation-error');
		allElements[i].classList.remove('form-validation-error');
			allElements[i].classList.remove('input-validation-error');
		
				allElements[i].classList.add('valid');

}

	if (allElements[i].classList.contains('input-check')) {

		console.log('%c  ' + i + ' - Added input-check-success class!','color: green;font-weight: 500;')

				allElements[i].classList.add('input-check-success');

}
	
	
	if (allElements[i].classList.contains('ui-dialog')||allElements[i].classList.contains('ui-widget-corner-all') && !allElements[i].classList.contains('ui-draggable')) {

		console.log('%c  ' + i + ' - Added ui-draggable class!','color: green;font-weight: 500;')

		allElements[i].classList.remove('ui-widget-draggable');
				allElements[i].classList.add('ui-draggable');

}
	if (allElements[i].classList.contains('aspNetHidden')||allElements[i].classList.contains('ui-widget-corner-all') && !allElements[i].classList.contains('ui-draggable')) {
//Input Name: __VIEWSTATEGENERATOR
		console.log('%c  ' + i + ' - Removed aspNetHidden class!','color: green;font-weight: 500;')

		allElements[i].classList.remove('aspNetHidden');
				allElements[i].classList.add('aspNet');

}
if (allElements[i].classList.contains('a-alert-error')||allElements[i].classList.contains('a-alert-fail')||allElements[i].classList.contains('a-alert-failed')) {

		console.log('%c  ' + i + ' - Changed classList of a-alert-error to a-alert-success','color: green;font-weight: 500;')

		allElements[i].classList.remove('a-alert-error');
				allElements[i].classList.remove('a-alert-fail');
	allElements[i].classList.remove('a-alert-failed');
				allElements[i].classList.add('a-alert-success');

}



	
 if (allElements[i].hasAttribute('ng-disabled')) {
        allElements[i].removeAttribute("ng-disabled");
            highlightElementGreenForce(allElements[i]);

		console.log('%c  ' + i + ' - Removed ng-disabled attribiute.')
    }
 if (allElements[i].getAttribute('ng-show') === "!customer.completeThroughPayPal"||allElements[i].getAttribute('ng-click') === "po.placeOrder()") {
        allElements[i].setAttribute("ng-class","{ 'enabled': po.enabled }");
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Modified ng-class without restrictions for a specialized ng-show or ng-click attribute.','color: green;font-weight: 500;')
    }
	 if (allElements[i].getAttribute('ng-class') === "!disabledBtn"||allElements[i].getAttribute('ng-class') === "disabledBtn") {
        allElements[i].setAttribute("ng-class","{ 'nextBtn': enabled }");
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Enabled button without restrictions for a specialized ng-class attribute.','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].getAttribute('ng-change') === "pm.validateExpiration()"||allElements[i].getAttribute('ng-change') === "validateExpiration()"||allElements[i].getAttribute('ng-change') === "Validate()") {
        allElements[i].setAttribute('ng-change','');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Modified ng-class without restrictions for a specialized ng-show or ng-click attribute.','color: green;font-weight: 500;')
    }

if (allElements[i].classList.contains('transition')||allElements[i].classList.contains('param')||allElements[i].classList.contains('sr-only')) {

console.log('transition');


}




if (allElements[i].classList.contains('opacity')||allElements[i].classList.contains('transition')||allElements[i].classList.contains('sr-only')) {

        highlightElementGreen(allElements[i]);
console.log('remove opacity');

allElements[i].classList.remove('opacity');

}

// Additional




	
	// For ALL defined elements, Targeted
	
if (allElements[i].type !== undefined) {
	
	
if (allElements[i].hasAttribute('ngReadonly')) {
          allElements[i].removeAttribute('ngReadonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ngReadonly attribute!','color: green;font-weight: 500;')
    }
	

	
	
								if (allElements[i].hasAttribute('validate-submit')) {
          allElements[i].removeAttribute('validate-submit');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed validate-submit attribute!','color: green;font-weight: 500;')
    }				 
					 

	
	if (allElements[i].hasAttribute('read-only')) {
          allElements[i].removeAttribute('read-only');
            highlightElementGreenForce(allElements[i]);

		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	
		
	if (allElements[i].hasAttribute('readonly')) {
          allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
			
	if (allElements[i].hasAttribute('data-loggerapiurl')) {
          allElements[i].removeAttribute('data-loggerapiurl');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-loggerapiurl attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('data-signedinurl')) {
       // highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Contains data-signedinurl attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ng-invalid')) {
          allElements[i].removeAttribute('ng-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid attribute!','color: green;font-weight: 500;')
    }

	
		if (allElements[i].hasAttribute('show')) {
          allElements[i].removeAttribute('show');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed show attribute!','color: green;font-weight: 500;')
    }

	
	
		if (allElements[i].hasAttribute('masked')) {
          allElements[i].removeAttribute('masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed masked attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('ui-disabled')) {
          allElements[i].removeAttribute('ui-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ui-disabled attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ng-invalid')) {
          allElements[i].removeAttribute('ng-invalid');
                highlightElementGreenForce(allElements[i]);

		console.log('%c  ' + i + ' - Removed ng-invalid attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('unavailable')) {
          allElements[i].removeAttribute('unavailable');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed unavailable attribute!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].getAttribute('id') === 'isCaptchaEnabled') {
          allElements[i].value === 'false';
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Set isCaptchaEnabled to false!','color: green;font-weight: 500;')
    }
	
	
		
		if (allElements[i].hasAttribute('ghskeypressintercept')) {
          allElements[i].removeAttribute('ghskeypressintercept');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ghskeypressintercept attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('keypressintercept')) {
          allElements[i].removeAttribute('keypressintercept');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed keypressintercept attribute!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('min')) {
          allElements[i].removeAttribute('min');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed min attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('maxlength')) {
          allElements[i].removeAttribute('maxlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed maxlength attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('hidden')) {
          allElements[i].removeAttribute('hidden');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed hidden attribute!','color: green;font-weight: 500;')
    }
	
	    if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
		console.log(i);
        highlightElement(allElements[i]);
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElement(allElements[i]);
		console.log(i);
    }
	   
		
	if (allElements[i].hasAttribute('max')) {
          allElements[i].setAttribute('max',1000000000);
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Increased max attribute to billions!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('data-exit-row')) {
          allElements[i].setAttribute('data-exit-row','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-exit-row value set to false!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-disclaimer')) {
          allElements[i].setAttribute('data-disclaimer','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-disclaimer value set to false!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-useragent')) {
          allElements[i].setAttribute('data-useragent','no-js');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-useragent value set to no-js!','color: purple;font-weight: 500;')
    }
	
	
			if (allElements[i].hasAttribute('data-validate-maxlength')) {
          allElements[i].setAttribute('data-validate-maxlength',100000000);
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Increased data-validate-maxlength to billions!','color: green;font-weight: 500;')
    }
	
				if (allElements[i].hasAttribute('data-validate-maxlength')) {
          allElements[i].setAttribute('data-validate-maxlength',100000000);
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Increased data-validate-maxlength to billions!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('data-showed')) {
          allElements[i].setAttribute('data-showed','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' data-showed set to true!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('data-seat-available')) {
          allElements[i].setAttribute('data-seat-available','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-seat-available value set to availableSeat_mapSeat!','color: green;font-weight: 500;')
    }

		if (allElements[i].hasAttribute('data-log-error')) {
          allElements[i].setAttribute('data-log-error','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-log-error value on ' + allElements[i].type + ' has been set to false!','color: green;font-weight: 500;')
    }

	if (allElements[i].hasAttribute('data-disabled')) {
          allElements[i].setAttribute('data-disabled',false);
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-log-error value set to false','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-disabled')) {
          allElements[i].removeAttribute('data-disabled');
		  console.log('%c  ' + i + ' - Removed data-disabled attribute!','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('defer')) {
          allElements[i].removeAttribute('defer');
		  console.log('%c  ' + i + ' - Removed defer attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].setAttribute('unselectable','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - unselectable value set to false','color: green;font-weight: 500;')
    }	

	if (allElements[i].hasAttribute('data-show-first-option')) {
          allElements[i].setAttribute('data-show-first-option','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - data-show-first-option value set to true','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-validator-ga')) {
          allElements[i].removeAttribute('data-validator-ga');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed data-validator-ga attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-enabled-b2c')) {
			          allElements[i].setAttribute('data-enabled-b2c',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-enabled-b2c value to true!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-enabled-b2b')) {
			          allElements[i].setAttribute('data-enabled-b2b',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-enabled-b2b value to true!','color: green;font-weight: 500;')
    }
	
	
	
			if (allElements[i].hasAttribute('data-prepay-available')) {
			          allElements[i].setAttribute('data-prepay-available',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-prepay-available value to true!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('data-prepay-b2b-enabled')) {
			          allElements[i].setAttribute('data-prepay-b2b-enabled',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-prepay-b2b-enabled-available value to true!','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('data-tb-dyn')) {
			          allElements[i].setAttribute('data-tb-dyn',false);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-tb-dyn value to false!','color: green;font-weight: 500;')
    }
	
	
	
		if (allElements[i].hasAttribute('parsley-error-message')) {
			          allElements[i].removeAttribute('parsley-error-message');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed parsley-error-message attribute','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('parsley-type')) {
			          allElements[i].removeAttribute('parsley-type');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed parsley-type attribute','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('parsley-rangelength')) {
			          allElements[i].removeAttribute('parsley-rangelength');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed parsley-rangelength attribute','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('parsley-trigger')) {
			          allElements[i].removeAttribute('parsley-trigger');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed parsley-trigger attribute','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('data-qa-error')) {
			          allElements[i].removeAttribute('data-qa-error');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-qa-error value to true!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-validator-id')) {
			          allElements[i].removeAttribute('data-validator-id');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-validator-id value to true!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('data-mask-patterns')) {
			          allElements[i].removeAttribute('data-mask-patterns');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-mask-patterns value to true!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-partial-patterns')) {
			          allElements[i].removeAttribute('data-partial-patterns');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-partial-patterns value to true!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('data-google-allowed')) {
			          allElements[i].setAttribute('data-google-allowed',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-google-allowed value to true!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-apple-allowed')) {
			          allElements[i].setAttribute('data-apple-allowed',true);
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Set data-apple-allowed value to true!','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('data-requirecontext')) {
			          allElements[i].removeAttribute('data-requirecontext');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed data-requirecontext attribiute!','color: green;font-weight: 500;')
    }
				if (allElements[i].hasAttribute('data-restrictions')) {
			          allElements[i].removeAttribute('data-restrictions');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed data-restrictions attribiute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].getAttribute('id') === 'error') {
			          allElements[i].setAttribute('id','success');
        highlightElementGreen(allElements[i]);
		  console.log('%c  ' + i + ' - Removed data-restrictions attribiute!','color: green;font-weight: 500;')
    }
	
	/*
	if (allElements[i].hasAttribute('data-radium')) {
          allElements[i].removeAttribute('data-radium');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-radium attribute','color: green;font-weight: 500;')
    }
	
	*/



	if (allElements[i].disabled) allElements[i].disabled = false;
							allElements[i].enabled = true;
											 		   allElements[i].classList.remove('ec-label-icon-bad');
											 		   allElements[i].classList.remove('ec-required');

							 		   allElements[i].classList.remove('ng-invalid');
							    allElements[i].classList.remove('ng-invalid-card');
								 allElements[i].classList.remove('ng-invalid-parse');
				 allElements[i].classList.remove('ng-invalid-valdr-expiration-validator');
	allElements[i].classList.remove('ng-invalid-valdr');
	
	
							allElements[i].classList.remove('progress-');
							 allElements[i].classList.remove('ACA_Message_Error');
allElements[i].classList.remove('parsleyParse');
allElements[i].classList.remove('progress-disabled');
allElements[i].classList.remove('.ACA_Message_Error');
allElements[i].classList.remove('.message_error_contact');
allElements[i].classList.remove('form-error-message');
allElements[i].classList.remove('form-error-message-container');
allElements[i].classList.remove('message_error_contact');
allElements[i].classList.remove('form-control-with-icon--error');
allElements[i].classList.remove('--error');
allElements[i].classList.remove('error');
allElements[i].classList.remove('expiration-date-chooser.error');
allElements[i].classList.remove('.form-control-with-icon--error');
allElements[i].classList.remove('.expiration-date-chooser.error');
allElements[i].classList.remove('no-close');
allElements[i].classList.remove('nodisplay');
allElements[i].classList.remove('display');
allElements[i].classList.remove('hidden-xs');
allElements[i].classList.remove('hidden-sm');
allElements[i].classList.remove('ACA_Error_Indicator');
allElements[i].classList.remove('ACA_LgButtonDisable');
allElements[i].classList.remove('ACA_LgButtonDisable_FontSize');

allElements[i].classList.remove('cta-disabled-message');
 
					allElements[i].classList.remove('disableCtrl');
allElements[i].classList.remove('disabledlink');
allElements[i].classList.remove('validation-summary-errors');
		 
allElements[i].classList.remove('form-control-with-icon--error');
allElements[i].classList.remove('validation-marker-error');
allElements[i].classList.remove('validation-marker');

allElements[i].classList.remove('error-label');
allElements[i].classList.remove('hide-content');
	allElements[i].classList.remove('general-alert-errors');
	
	allElements[i].classList.remove('failed');
	allElements[i].classList.remove('failure');


		allElements[i].classList.remove('id_btnadddisabledn');
	allElements[i].classList.remove('promoCode_hidden');

	allElements[i].classList.remove('promoCode_hidden');
	allElements[i].classList.remove('undefined');
	allElements[i].classList.remove('BigButton_disabled___28Ssj');
	allElements[i].classList.remove('BigButton_disabled');
allElements[i].classList.remove('hidden-xs');
allElements[i].classList.remove('hidden-sm');
	allElements[i].classList.remove('myx-button-disabled');
		allElements[i].classList.remove('overlay__social');
allElements[i].classList.remove('is-invalid');

    allElements[i].removeAttribute("data-parsley-gte");
	    allElements[i].removeAttribute("data-parsley-lt");
		    allElements[i].removeAttribute("data-parsley-gt");
		    allElements[i].removeAttribute("data-parsley-lte");
			

// EXTRA TARGETED

/* Restricted Content */


 if (allElements[i].getAttribute("id") === "js-session-status") {
    allElements[i].setAttribute("value","authenticated");
    }
	
 if (allElements[i].getAttribute("id") === "fncls") {
    allElements[i].setAttribute("id","BP_trustedwaveSealImage");
    }
  if (allElements[i].getAttribute("id") === "trustwaveSealImage") {
    allElements[i].setAttribute("id","BP_trustedwaveSealImage");
    }
	  if (allElements[i].getAttribute("id") === "_hj_survey_invite_container") {
    allElements[i].removeAttribute("style");
	   allElements[i].removeAttribute("class");
	   	   allElements[i].removeAttribute("visibility");
		   	   allElements[i].removeAttribute("id");


    }
	
	
  if (allElements[i].hasAttribute("data-julie")) {
    allElements[i].removeAttribute("data-julie");
	        highlightElementPurple(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-julie attribiute','color: green;font-weight: 500;')

    }
  if (allElements[i].hasAttribute("data-parsley")) {
    allElements[i].removeAttribute("data-parsley");
	        highlightElementPurple(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-parsley attribiute','color: green;font-weight: 500;')

    }
  if (allElements[i].hasAttribute("data-parsley-required")) {
    allElements[i].removeAttribute("data-parsley-required");
	        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-parsley-required attribiute','color: green;font-weight: 500;')

    }
  if (allElements[i].hasAttribute("data-parsley-no-focus")) {
    allElements[i].removeAttribute("data-parsley-no-focus");
		console.log('%c  ' + i + ' - Removed data-parsley-no-focus attribiute','color: green;font-weight: 500;')

    }
	
	
	if (allElements[i].hasAttribute("data-parsley-trigger-after-failure")) {
    allElements[i].removeAttribute("data-parsley-trigger-after-failure");
		console.log('%c  ' + i + ' - Removed data-parsley-trigger-after-failure attribiute','color: green;font-weight: 500;')

    }
		if (allElements[i].hasAttribute("data-parsley-gt")) {
    allElements[i].removeAttribute("data-parsley-gte");
	    allElements[i].removeAttribute("data-parsley-lt");
		    allElements[i].removeAttribute("data-parsley-gt");
		    allElements[i].removeAttribute("data-parsley-lte");

		console.log('%c  ' + i + ' - Removed data-parsley-gt and data-parsley-gte attribiute','color: green;font-weight: 500;')

    }
		if (allElements[i].hasAttribute("data-parsley-validation-threshold")) {
    allElements[i].removeAttribute("data-parsley-validation-threshold");
		console.log('%c  ' + i + ' - Removed data-parsley-validation-threshold attribiute','color: green;font-weight: 500;')

    }
			if (allElements[i].hasAttribute("data-parsley-errors-container")) {
    allElements[i].removeAttribute("data-parsley-errors-container");

		console.log('%c  ' + i + ' - Removed data-parsley-errors-container attribiute','color: green;font-weight: 500;')
    }



	
/* cardPaymentBlocked */

if (allElements[i].getAttribute('id') === "head_SamsungPay") {
         allElements[i].setAttribute('style','');
		
			allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								allElements[i].removeAttribute('styles');
								allElements[i].removeAttribute('left');
									allElements[i].removeAttribute('hidden');
											allElements[i].removeAttribute('top');
								  allElements[i].removeAttribute('border');
							
								     allElements[i].removeAttribute('protected');
									
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
						
	
        highlightElementPurple(allElements[i]);
		console.log('%c  ' + i + ' - Removed styles for id: head_SamsungPay','color: green;font-weight: 500;')
		
		allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 
    }
	   

   if (allElements[i].getAttribute('id') === "head_ApplePay") {
         allElements[i].setAttribute('style','');
		 
		 allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		
		
        highlightElementPurple(allElements[i]);
		console.log('%c  ' + i + ' - Removed styles for id: head_ApplePay')
    }
	
	 if (allElements[i].hasAttribute('aria-disabled')) {
          allElements[i].removeAttribute('aria-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('aria-required')) {
          allElements[i].removeAttribute('aria-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-disabled attribute!','color: green;font-weight: 500;')
    }

	  if (allElements[i].hasAttribute('required')) {
        allElements[i].required = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced required value to false!','color: green;font-weight: 500;')
    }
	
    if (allElements[i].hasAttribute('readonly')) {
        allElements[i].removeAttribute('readonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed readonly attribute!','color: green;font-weight: 500;')
    }
		
    if (allElements[i].hasAttribute('read-only')) {
        allElements[i].removeAttribute('read-only');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed read-only attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('ng-hide')) {
        allElements[i].removeAttribute('ng-hide');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-hide attribute!','color: green;font-weight: 500;')
    }
		    if (allElements[i].hasAttribute('once-class')) {
        allElements[i].removeAttribute('once-class');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed once-class attribute!','color: green;font-weight: 500;')
    }
			    if (allElements[i].hasAttribute('once-show')) {
        allElements[i].removeAttribute('once-show');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed once-show attribute!','color: green;font-weight: 500;')
    }
			    if (allElements[i].hasAttribute('data-a-state')) {
        allElements[i].removeAttribute('data-a-state');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-a-state attribute!','color: green;font-weight: 500;')
    }
			    if (allElements[i].hasAttribute('ng-controller')) {
        allElements[i].removeAttribute('ng-controller');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-controller attribute!','color: green;font-weight: 500;')
    }
		    if (allElements[i].hasAttribute('ng-switch')) {
        allElements[i].removeAttribute('ng-switch');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-switch attribute!','color: green;font-weight: 500;')
    }
		    if (allElements[i].hasAttribute('ng-switch-when')) {
        allElements[i].removeAttribute('ng-switch-when');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-switch-when attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('ui-view')) {
        allElements[i].removeAttribute('ui-view');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ui-view attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('ng-repeat')) {
        allElements[i].removeAttribute('ng-repeat');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-repeat attribute!','color: green;font-weight: 500;')
    }
	
	
	
	    if (allElements[i].hasAttribute('cel_widget_id')) {
        allElements[i].removeAttribute('cel_widget_id');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed cel_widget_id attribute!','color: green;font-weight: 500;')
    }
	
	
	   allElements[i].setAttribute('is-optional','true');
	    allElements[i].removeAttribute('dr_hiddenCartBorder');
		
	  

if (allElements[i].classList.contains('button--disabled')) {
	 allElements[i].removeAttribute('hidden');
	allElements[i].removeAttribute('disabled');
		allElements[i].classList.remove('button--disabled');
				allElements[i].classList.add('button--enabled');

			console.log('%c  ' + i + ' - Removed buton--disabled attribute!','color: green;font-weight: 500;')
			console.log('%c  ' + i + ' - Added button--enabled attribute!','color: green;font-weight: 500;')

}

if (allElements[i].classList.contains('not-logged-in')) {
	 allElements[i].removeAttribute('hidden');
	allElements[i].removeAttribute('disabled');
		allElements[i].classList.remove('not-logged-in');
				allElements[i].classList.add('logged-in');
				allElements[i].classList.add('admin-logged-in');
				allElements[i].classList.add('user-logged-in');
				allElements[i].classList.add('is-logged-in');

			console.log('%c  ' + i + ' - Removed not-logged-in class!','color: green;font-weight: 500;')
			console.log('%c  ' + i + ' - Added various logged in attributes and classes!','color: green;font-weight: 500;')

}

	

if (allElements[i].classList.contains('maskedfields')) {
	 allElements[i].removeAttribute('hidden');
	allElements[i].removeAttribute('disabled');
		allElements[i].classList.remove('maskedfields');
				allElements[i].classList.add('unmasked');
				allElements[i].classList.add('unmaskedfields');

			console.log('%c  ' + i + ' - Removed maskedfields class!','color: green;font-weight: 500;')

}
if (allElements[i].classList.contains('aspNetHidden')) {
	 allElements[i].removeAttribute('hidden');
	allElements[i].removeAttribute('disabled');
		allElements[i].classList.remove('aspNetHidden');

			console.log('%c  ' + i + ' - Removed aspNetHidden class!','color: green;font-weight: 500;')

}


if (allElements[i].classList.contains('HiddenButton')) {
	 allElements[i].removeAttribute('style');
	allElements[i].removeAttribute('styles');
				allElements[i].classList.remove('HiddenButton');
				allElements[i].classList.add('Button');

			console.log('%c  ' + i + ' - Removed HiddenButton class!','color: green;font-weight: 500;')

}



if (allElements[i].classList.contains('availabilityMessage')||allElements[i].classList.contains('occupiedNameContainer')||allElements[i].classList.contains('sr-only')) {
  allElements[i].removeAttribute('hidden');
	
	allElements[i].removeAttribute('disabled');
		allElements[i].removeAttribute('Disabled');
	allElements[i].removeAttribute('DISABLED');

	  			allElements[i].classList.remove('hidden');
				allElements[i].classList.remove('disabled');
	 				allElements[i].classList.remove('unavailable');
				allElements[i].classList.remove('unauthorized');
					allElements[i].classList.remove('unallowed');
						allElements[i].classList.remove('disallow');
						allElements[i].classList.remove('disable');
						allElements[i].classList.remove('notallowed');
	allElements[i].classList.remove('disable');
		
					
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Found elements matching classlist to display!','color: green;font-weight: 500;')


}




if (allElements[i].classList.contains('seatmap-status-TAKEN')||allElements[i].hasAttribute('data-occupation')||allElements[i].hasAttribute('data-seat-available')||allElements[i].hasAttribute('data-seat-number')||allElements[i].hasAttribute('data-seat-details-info-url')) {
 
     highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Found elements matching classlist to display!','color: green;font-weight: 500;')

		
		     highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Found elements matching classlist to display!','color: green;font-weight: 500;')


 allElements[i].removeAttribute('hidden');
	  allElements[i].removeAttribute('disabled');
	 				allElements[i].classList.remove('unavailable');
				allElements[i].classList.remove('unauthorized');
					allElements[i].classList.remove('unallowed');
						allElements[i].classList.remove('disallow');
						allElements[i].classList.remove('disable');
						allElements[i].classList.remove('notallowed');
							allElements[i].classList.remove('occupiedNameContainer');
						
	  allElements[i].classList.remove('seatmap-status-TAKEN');
						allElements[i].classList.add('seatmap-status-AVAILABLE');
						
						  allElements[i].setAttribute('data-list-characteristic','|FREE|');
	  allElements[i].setAttribute('data-occupation','F');
	    allElements[i].setAttribute('data-status','AVAILABLE');
		 allElements[i].setAttribute('aria-disabled','false');
						
						allElements[i].classList.remove('seatmap-occupation-Z');
	  	  allElements[i].classList.add('seatmap-occupation-F');

		    allElements[i].classList.add('seat-cell');
		   allElements[i].classList.add('seatmap-seat');
		   
		     allElements[i].removeAttribute('hidden');
	  allElements[i].removeAttribute('disabled');
		      
		     allElements[i].removeAttribute('parsley-trigger');
	  allElements[i].removeAttribute('parsley-type');
		     allElements[i].removeAttribute('pattern');
			  allElements[i].removeAttribute('disabled');
			 allElements[i].removeAttribute('parsley-rangelength');
	   		
				allElements[i].classList.remove('chargeable-seat-no-change-note');
allElements[i].classList.remove('hidden');
				allElements[i].classList.add('js-seat-tooltip');
							allElements[i].classList.add('seat--available');	
						allElements[i].classList.add('js-seat-paid')
						

		
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Found elements matching classlist to display!','color: green;font-weight: 500;')
}


 }
	 

// For ALL elements, Global *


 		allElements[i].classList.remove('ng-invalid-valdr-cvv-validator');
 		allElements[i].classList.remove('ng-invalid-valdr');
allElements[i].classList.remove('ng-invalid');
allElements[i].removeAttribute('ng-transclude');
 		allElements[i].classList.remove('inline-error');
		allElements[i].classList.remove('custom-error-message');
				
 		allElements[i].classList.remove('.inline-error');


		allElements[i].classList.remove('lazyload');
				allElements[i].classList.remove('parsley-error-list');

						allElements[i].classList.remove('error-list');
						allElements[i].classList.remove('parsley-error');


		allElements[i].classList.remove('progress-disabled');
allElements[i].removeAttribute('progress-disabled');
	allElements[i].classList.remove('fsrModalBackdrop');
					allElements[i].classList.remove('overviewModalBackdrop');
	allElements[i].classList.remove('hidden-spoken');
				
	 	allElements[i].classList.remove('ng-hide');
allElements[i].removeAttribute('disabled');
allElements[i].removeAttribute('disabled');

		allElements[i].removeAttribute('Disabled');
	allElements[i].removeAttribute('DISABLED');
allElements[i].removeAttribute('undefined');
allElements[i].removeAttribute('ng-include');


allElements[i].removeAttribute('bindonce');


allElements[i].classList.remove('undefined');
allElements[i].classList.remove('NoDisplay');
allElements[i].classList.remove('visuallyhidden');
allElements[i].classList.remove('validationSummary');

allElements[i].classList.remove('blueButton2AutoHid');
allElements[i].classList.remove('AVAST_PAM_nonloginform');
allElements[i].classList.remove('AVAST_PAM_iconstyle');


allElements[i].classList.remove('has-danger');
allElements[i].classList.remove('limited');
allElements[i].classList.remove('addFeatureDummyButtonClass');
					allElements[i].classList.remove('xs-disabled');
			allElements[i].classList.remove('ws-disabled');
		 allElements[i].classList.remove('disabled');
		 	 allElements[i].classList.remove('required');
		 allElements[i].classList.remove('page-locker');
		 	 allElements[i].classList.remove('js_page_locker');
		
		 allElements[i].removeAttribute('read-only');
		 	 allElements[i].classList.remove('read-only');	
			 	 allElements[i].classList.remove('ui-disabled');	
		 			allElements[i].classList.remove('disableTextSelection');
	allElements[i].classList.remove('disableSelection');
	allElements[i].classList.remove('restricted');
					allElements[i].classList.remove('removeFocusOutline');
					allElements[i].classList.remove('mktoRequired');
			 	 	 allElements[i].classList.remove('ui-disabled');		
  allElements[i].classList.remove('required-text');
        allElements[i].classList.remove('masked');
		allElements[i].classList.remove('hide-focus');
    allElements[i].classList.remove('ng-invalid');
 allElements[i].classList.remove('unavailable');
   allElements[i].classList.remove('notready');
  allElements[i].classList.remove('invalid');
  allElements[i].classList.remove('disallow');
					allElements[i].classList.remove('mask');
						allElements[i].classList.remove('untouched');
						allElements[i].classList.remove('pristine');
				allElements[i].classList.remove('locked');
						allElements[i].classList.remove('nc-required-js-1');
						allElements[i].classList.remove('nc-required-js-2');
						allElements[i].classList.remove('nc-required-js-3');
							allElements[i].classList.remove('required-js-1');
  allElements[i].classList.remove('void');

  allElements[i].classList.remove('nicescroll-rails-vr');
  allElements[i].classList.remove('nicescroll-rails');
 allElements[i].classList.remove('nicescroll-cursors');
  allElements[i].classList.remove('required-instruction');


		allElements[i].classList.remove('validation-group');
    allElements[i].classList.remove('problem');
 allElements[i].classList.remove('unauthorized');
  allElements[i].classList.remove('failed');
 
		  allElements[i].classList.remove('has-error');
 allElements[i].classList.remove('form-control--error');
  allElements[i].classList.remove('error');
   allElements[i].classList.remove('error-label');
    allElements[i].classList.remove('form-ada-error-text');
  allElements[i].classList.remove('icon-exclamation-circle');
   allElements[i].classList.remove('form-ada-error-message');
   

							
   allElements[i].classList.remove('alert');
      allElements[i].classList.remove('alert-danger');
   allElements[i].classList.remove('NotEnoughLoyaltyPointsException');
  allElements[i].classList.remove('NotEnough');
  allElements[i].classList.remove('NoPoints');
  allElements[i].classList.remove('exception');
  allElements[i].classList.remove('warning');
   allElements[i].classList.remove('incomplete');
   allElements[i].classList.remove('incompleted');
 allElements[i].classList.remove('incompleted');
  allElements[i].classList.remove('incompleted');
  
   allElements[i].classList.remove('blocked');
   allElements[i].classList.remove('notfound');
	  					allElements[i].classList.remove('hasErrorTooltipRuleSpecific');
				allElements[i].classList.remove('hasErrorTooltipRequired');
											allElements[i].classList.remove('errloading');
										allElements[i].classList.remove('icon_warn');
				allElements[i].classList.remove('hidden-form');
				
				allElements[i].classList.remove('disableCtrl');
				allElements[i].classList.remove('disablectrl');
						
				allElements[i].classList.remove('invisible-apps');
				
				allElements[i].classList.remove('data-std-maxlength');
		allElements[i].classList.remove('data-relaxed-maxlength');
		allElements[i].classList.remove('data-cs-mask');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
		allElements[i].classList.remove('gift-card-check-response-text-error-wrapper');
		allElements[i].classList.remove('rc-anchor-error-msg-container');
		
			
		
		
		// Class AVAST_PAM_nonloginform
		
		
			if (allElements[i].hasAttribute('directionality')) {
          allElements[i].setAttribute('directionality','ltr');
		console.log('%c  ' + i + ' - Forced directionality attribute ltr!','color: green;font-weight: 500;')
    }	

	
			
	
		if (allElements[i].hasAttribute('ng-if')) {
          allElements[i].removeAttribute('ng-if');
		console.log('%c  ' + i + ' - Removed ng-if attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-ng-if')) {
          allElements[i].removeAttribute('data-ng-if');
		console.log('%c  ' + i + ' - Removed data-ng-if attribute!','color: green;font-weight: 500;')
    }	
	

		allElements[i].classList.remove('icon-error');
				allElements[i].classList.remove('has-danger');

						allElements[i].classList.remove('icon-error');

								allElements[i].classList.remove('ctHidden');

								
						allElements[i].classList.remove('unknown');
						allElements[i].classList.remove('form-error');
						allElements[i].classList.remove('.form-error');
												allElements[i].classList.remove('.req');

						allElements[i].classList.remove('req');
						
						


						allElements[i].classList.remove('ws-error');
						
// FOR VIDEO elements

 if (allElements[i].type === "video"||allElements[i].type === "audio") {
			
			 if (allElements[i].hasAttribute('autoplay')) {
        allElements[i].removeAttribute('autoplay');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed autoplay attribute!','color: green;font-weight: 500;')
    }
			 if (allElements[i].hasAttribute('webkit-playsinline')) {
        allElements[i].setAttribute('webkit-playsinline','false');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Forced webkit-playsinline false!','color: green;font-weight: 500;')
    }
		 if (allElements[i].hasAttribute('playsinline')) {
        allElements[i].setAttribute('playsinline','false');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Forced playsinline false!','color: green;font-weight: 500;')
    }

				 if (!allElements[i].hasAttribute('controls')) {
        allElements[i].setAttribute('controls');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Added controls attribute!','color: green;font-weight: 500;')
    }
	
	
 }
	

	
	
	// ONLY FORM elements

 if (allElements[i].type === "form") {
		
	  if (!allElements[i].hasAttribute('novalidate')) {
        allElements[i].setAttribute('novalidate', 'novalidate');
        highlightElementGreenForce(allElements[i]);
					console.log('%c  ' + i + ' - Added novalidate attribute to form!','color: green;font-weight: 500;')
   
	
 }}
	
		 if (allElements[i].hasAttribute('blockedimagesrc')) {
        allElements[i].removeAttribute('blockedimagesrc');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed blockedimagesrc attribute from image!','color: green;font-weight: 500;')
    }
	
	

	
	// FOR IMAGE elements
	
	

 if (allElements[i].type === "img"||allElements[i].type === "image") {
		
	 if (allElements[i].hasAttribute('data-imagetype')) {
        allElements[i].removeAttribute('data-imagetype');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-image attribute from image!','color: green;font-weight: 500;')
    }
	
		 if (allElements[i].hasAttribute('blockedimagesrc')) {
        allElements[i].removeAttribute('blockedimagesrc');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed blockedimagesrc attribute from image!','color: green;font-weight: 500;')
    }
	
	
 }
	
				 
// FOR A and LINK elements

	 if (allElements[i].type === "link"||allElements[i].type === "a") {
			
			if (allElements[i].hasAttribute('rel')) {
          allElements[i].removeAttribute('rel');
		  
		  
     //   highlightElementBlue(allElements[i]);
		console.log('%c  ' + i + ' - Removed rel attribute from link!','color: green;font-weight: 500;')
    }
	 }	
	// FOR META ONLY
/*
	 if (allElements[i].type === "meta") {
			
			if (allElements[i].hasAttribute('rel')) {
          allElements[i].removeAttribute('rel');
     //   highlightElementBlue(allElements[i]);
		console.log('%c  ' + i + ' - Removed rel attribute from meta!','color: green;font-weight: 500;')
    }
	 }	
	 */
	//  data-react-helmet
	 
// FOR META and HTML
	 		// js applicationcache geolocation history postmessage websockets localstorage sessionstorage websqldatabase webworkers hashchange audio canvas canvastext video webgl cssgradients multiplebgs opacity rgba inlinesvg hsla supports svgclippaths smil no-touchevents fontface generatedcontent textshadow cssanimations backgroundsize borderimage borderradius boxshadow flexbox cssreflections csstransforms csstransforms3d csstransitions js_active  vc_desktop  vc_transform  vc_transform no-skrollr" lang="en-US"		 

	 if (allElements[i].type === "body"||allElements[i].type === "header"||allElements[i].type === "html") {
allElements[i].classList.remove('not-logged-in');			
			allElements[i].classList.add('supports');
			 allElements[i].setAttribute('supports');
		  allElements[i].classList.remove('webgl');
		 allElements[i].classList.remove('geolocation');
		  allElements[i].classList.remove('webgl');
		  allElements[i].classList.remove('audio');
		    allElements[i].classList.remove('webworkers');
			 allElements[i].classList.remove('svgclippaths');
			  allElements[i].classList.remove('postmessage');
			  	allElements[i].classList.remove('applicationcache');
			allElements[i].classList.remove('history');
			 allElements[i].classList.remove('websqldatabase');
			  allElements[i].classList.remove('svg');
			  			  allElements[i].classList.remove('no-history');
						  			allElements[i].classList.remove('history');
			     aallElements[i].classList.remove('firefox');
				 
			   allElements[i].removeAttribute('data-amplitude-id');
			    allElements[i].classList.remove('hsla');
			 allElements[i].removeAttribute('history');
			 allElements[i].classList.remove('fontface');
			allElements[i].classList.remove('hashchange');
			    allElements[i].removeAttribute('localstorage');
				 allElements[i].removeAttribute('localstorage');
						allElements[i].classList.remove('postmessage');
			 allElements[i].removeAttribute('inlinesvg');
			
			  allElements[i].removeAttribute('smil');
			
	
		   allElements[i].classList.remove('sp🚧');
		
		allElements[i].classList.remove('firefox');
		allElements[i].classList.remove('disableTextSelection');
			allElements[i].classList.remove('removeFocusOutline');
				allElements[i].classList.remove('hideOnPrint');
					allElements[i].classList.remove('ms-Fabric--isFocusVisible');
										allElements[i].classList.remove('ec-required');
									allElements[i].classList.add('ec-optional');
									allElements[i].classList.add('ec-success');

		
    }
		
	 
	// FOR Scripts

	 
	 if  ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "text/javascript"||allElements[i].type === "script"||allElements[i].type === "application/ld+json"||allElements[i].type === "application/ld"||allElements[i].type === "frameElement"||allElements[i].type === "frames"||allElements[i].type === "objects"||allElements[i].type === "object"||allElements[i].type === "prefetch")) {
			
			 if (allElements[i].hasAttribute('async')) {
        allElements[i].removeAttribute('async');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: orange;font-weight: 500;')
    }
	
	
	
			 if (allElements[i].hasAttribute('data-cfasync')) {
        allElements[i].removeAttribute('data-cfasync');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed async attribute from script!','color: green;font-weight: 500;')
    }
	
				 if (allElements[i].hasAttribute('_hjRemoteVarsFrame')) {
        allElements[i].removeAttribute('_hjRemoteVarsFrame');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed _hjRemoteVarsFrame attribute from script!','color: orange;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('style')) {
        allElements[i].removeAttribute('style');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed style attribute from script!','color: green;font-weight: 500;')
    }
	
	
			 if (allElements[i].hasAttribute('data-ssk-ready')) {
        allElements[i].removeAttribute('data-ssk-ready');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-ssk-ready attribute to script!','color: green;font-weight: 500;')
    }
	
		 if (allElements[i].hasAttribute('data-session-timeout')) {
        allElements[i].setAttribute('data-session-timeout',infinity);
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Set data-session-timeout attribute to infinity!','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].hasAttribute('data-redemption')) {
        allElements[i].setAttribute('data-redemption',true);
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Set data-redemption attribute to true!','color: green;font-weight: 500;')
    }
	
	
	 }
	 
	 // META
	 
	 if  (allElements[i].type === "meta") {
			
		/*  Meta */
		        allElements[i].removeAttribute('content');

	
	 }
	
// FOR IFRAME

	if (allElements[i].type === "iframe"||allElements[i].type === "frameElement"||allElements[i].type === "frames"||allElements[i].type === "embeds") {
		console.log('%c ' + i + ' / ' + max + ' | id: ' + allElements[i].getAttribute("id") + ' | async: [' + allElements[i].getAttribute("async") + '] title: [' + allElements[i].getAttribute("title") + '] | sandbox : [' + allElements[i].getAttribute("sandbox") + '] width: [' + allElements[i].getAttribute("width") + '] height: [' + allElements[i].getAttribute("height") + '] type: [' + allElements[i].type + '] src: ' + allElements[i].getAttribute("src")  + ' ','color: orange;font-weight: 700;');
			  allElements[i].setAttribute('allowtransparency','false');
		       allElements[i].removeAttribute('allowtransparency');
		
			 if (allElements[i].hasAttribute('scrolling')) {
        allElements[i].setAttribute('scrolling','yes');
        highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Forced iframe scrolling attribute to yes')
    }
				 if (allElements[i].hasAttribute('sandbox')) {
       //allElements[i].setAttribute('sandbox','allow-forms allow-popups allow-same-origin allow-scripts allow-top-navigation allow-modals allow-popups-to-escape-sandbox');
         allElements[i].removeAttribute('sandbox');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed certain iframe sandbox restrictions')
    }
	
	 //  allElements[i].setAttribute('allow','encrypted-media');

	
		 if (allElements[i].hasAttribute('allowtransparency')) {
         allElements[i].setAttribute('allowtransparency','false');
		       allElements[i].removeAttribute('allowtransparency');
		
		highlightElementFrame(allElements[i]);
					console.log('%c  ' + i + ' - Removed iframe allowtransparency attribute')
    }
		 if (allElements[i].hasAttribute('allowfullscreen')) {
         allElements[i].setAttribute('allowfullscreen','false');
		       allElements[i].removeAttribute('allowfullscreen');
					console.log('%c  ' + i + ' - Removed iframe allowfullscreen attribute')
	}
			 if (allElements[i].hasAttribute('tabindex')) {
         allElements[i].removeAttribute('tabindex');
		console.log('%c  ' + i + ' - Removed iframe tabindex attribute')
	
	}
	
	
	 if (allElements[i].hasAttribute('aria-hidden')) {
         allElements[i].removeAttribute('aria-hidden');
		console.log('%c  ' + i + ' - Removed iframe aria-hidden attribute')
	
	}
      if (allElements[i].getAttribute('width' === '0') || allElements[i].getAttribute('width' === 0) || allElements[i].getAttribute('width' === 1) || allElements[i].getAttribute('width' === 1) || allElements[i].getAttribute('width' === '1') || allElements[i].getAttribute('width' === 10) || allElements[i].getAttribute('width' === '10')) {
		
		
			allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								allElements[i].removeAttribute('styles');
								allElements[i].removeAttribute('left');
									allElements[i].removeAttribute('hidden');
											allElements[i].removeAttribute('top');
								  allElements[i].removeAttribute('border');
								  allElements[i].setAttribute('frameborder','3');
								     allElements[i].removeAttribute('protected');
									  allElements[i].removeAttribute('std-maxlength');
									   allElements[i].removeAttribute('anchor');
										allElements[i].removeAttribute('anchors');
										allElements[i].removeAttribute('dialogWidth');
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													 allElements[i].removeAttribute('overflow');
													  allElements[i].removeAttribute('margins');
													 allElements[i].removeAttribute('marginBottom');
													 	 allElements[i].removeAttribute('marginLeft');
														  allElements[i].removeAttribute('marginTop');
														  	  allElements[i].removeAttribute('override-ltr');
															  		
		highlightElementFrame(allElements[i]);
	   }
	 
       
    }
	
	
	//width="1" height="1" src="https://bid.g.doubleclick.net/xbbe/pixel?d=KAE" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" style="display:none" scrolling="no"

	
	/*
	
	application/opensearchdescription+xml
	application/ld+json
	
	
	*/ 

// FOR ALL IMAGES
/*
		 if  (allElements[i].type === "image"||allElements[i].type === "image/x-icon"||allElements[i].type === "image/png"||allElements[i].type === "img"||allElements[i].type === "") {


if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
	
	
if (allElements[i].hasAttribute('rel')) {
          allElements[i].removeAttribute('rel');
     //   highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed rel attribute!','color: green;font-weight: 500;')
    }
	

	
	if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed required attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('ondrag')) {
          allElements[i].removeAttribute('ondrag');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ondrag attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('onpaste')) {
          allElements[i].removeAttribute('onpaste');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onpaste attribute!','color: green;font-weight: 500;')
    }
			
		if (allElements[i].hasAttribute('onselectstart')) {
          allElements[i].removeAttribute('onselectstart');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onselectstart attribute!','color: green;font-weight: 500;')
    }
	
	}
	
	*/
	
	// For certain modern or custom elements

	if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === 'logger'||allElements[i].type === 'link')) {
		
		if (allElements[i].hasAttribute('ng-show')) {
        allElements[i].removeAttribute('ng-show');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-show attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('ng-scope')) {
        allElements[i].removeAttribute('ng-scope');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-scope attribute!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('class')) {
        allElements[i].removeAttribute('class');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed class attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('style')) {
        allElements[i].removeAttribute('style');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed style attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('ref')) {
        allElements[i].removeAttribute('ref');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ref attribute!','color: green;font-weight: 500;')
    }
	
	
	
	
	}
		
		
	
	
// FOR ALL DIV, P and INPUT Elements, Span , most visual objects
if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === 'a'||allElements[i].type === 'aside'||allElements[i].type === 'nav'||allElements[i].type === 'tbody'||allElements[i].type === 'table'||allElements[i].type === 'td'||allElements[i].type === 'button'||allElements[i].type === 'form'||allElements[i].type === 'label'||allElements[i].type === 'i'||allElements[i].type === 'select-one'||allElements[i].type === 'strong'||allElements[i].type === 'i'||allElements[i].type === 'p'||allElements[i].type === 'hidden'||allElements[i].type === 'ul'||allElements[i].type === 'li'||allElements[i].type === 'table'||allElements[i].type === 'selection'||allElements[i].type === 'legend'||allElements[i].type === 'form'||allElements[i].type === 'div'||allElements[i].type === 'pre'||allElements[i].type === 'p'||allElements[i].type === 'span'||allElements[i].type === 'h1'||allElements[i].type === 'h2'||allElements[i].type === 'h3'||allElements[i].type === 'h4'||allElements[i].type === 'h5'||allElements[i].type === 'h6'||allElements[i].type === 'em'||allElements[i].type === 'sup'||allElements[i].type === 'main'||allElements[i].type === 'text'||allElements[i].type === 'input'||allElements[i].type === 'select'||allElements[i].type === 'option'||allElements[i].type === 'form'||allElements[i].type === 'inputbox'||allElements[i].type === 'password'||allElements[i].type === 'hidden'||allElements[i].type === 'email'||allElements[i].type === 'url'||allElements[i].type === 'tel'||allElements[i].type === 'tel'||allElements[i].type === 'textarea'||allElements[i].type === 'radio'||allElements[i].type === 'checkbox'||allElements[i].type === 'fieldset'||allElements[i].type === 'button'||allElements[i].type === 'submit'||allElements[i].type === 'reset'||allElements[i].type === 'input[type=td]'||allElements[i].type === 'input[type=tr]'||allElements[i].type === 'input[type=span]'||allElements[i].type === 'input[type=label]'||allElements[i].type === 'hr'||allElements[i].type === '')) {
	allElements[i].classList.add('.ACA_Message_Success');

	 allElements[i].classList.add('is-valid');
	 	 allElements[i].classList.add('is-valid');
		 
				allElements[i].classList.add('success');
				allElements[i].classList.add('successful');
				allElements[i].classList.add('nofail');
allElements[i].classList.add('form-verified');			
			allElements[i].classList.add('paid');		
						allElements[i].classList.add('paid');		
						allElements[i].classList.add('found');		
						allElements[i].classList.add('logged-in');		
						allElements[i].classList.add('loggedin');		

								allElements[i].classList.add('notfailed');
allElements[i].classList.add('hassuccess');
				allElements[i].classList.add('approved');
					allElements[i].classList.add('approve');
					allElements[i].classList.add('authorized');
					allElements[i].classList.add('isapproved');
		 	 	 allElements[i].classList.add('parsley-success');
// allElements[i].classList.remove('display: none');



   allElements[i].setAttribute('is-optional','true');
	
	
	if (!allElements[i].hasAttribute('pattern')) {
        allElements[i].removeAttribute('pattern');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed pattern attribute!','color: green;font-weight: 500;')
    }
	
	if (!allElements[i].hasAttribute('inputmode')) {
        allElements[i].removeAttribute('inputmode');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed inputmode attribute!','color: green;font-weight: 500;')
    }
		if (!allElements[i].hasAttribute('data-automation-id')) {
        allElements[i].removeAttribute('data-automation-id');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed data-automation-id attribute!','color: green;font-weight: 500;')
    }
	
	
			if (!allElements[i].hasAttribute('ng-non-bindable')) {
        allElements[i].removeAttribute('ng-non-bindable');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-non-bindable attribute!','color: green;font-weight: 500;')
    }
			 if (!allElements[i].hasAttribute('ng-cloak')) {
        allElements[i].removeAttribute('ng-cloak');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed ng-cloak attribute!','color: green;font-weight: 500;')
    }
		 if (allElements[i].hasAttribute('form-control-danger')) {
        allElements[i].removeAttribute('form-control-danger');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed form-control-danger attribute!','color: green;font-weight: 500;')
    }
	 if (!allElements[i].hasAttribute('no-mouseflow')) {
        allElements[i].removeAttribute('no-mouseflow');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed no-mouseflow attribute!','color: green;font-weight: 500;')
    }
	
	 
	

if (allElements[i].hasAttribute('disabled')) {
          allElements[i].removeAttribute('disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed disabled attribute!','color: green;font-weight: 500;')
    }
			allElements[i].classList.add('data-ng-enabled');


			allElements[i].classList.add('ng-valid');
allElements[i].classList.add('ng-valid-maxlength');

allElements[i].classList.remove('visuallyhidden');
allElements[i].classList.remove('progress-disabled');
	allElements[i].classList.remove('ajax-processed');
	
	allElements[i].classList.add('progress-enabled');
		allElements[i].classList.add('adjustUl');
		allElements[i].classList.add('edit');

	 
	allElements[i].classList.add('optional');
		allElements[i].classList.add('ng-valid-required');
		allElements[i].classList.add('valid');
		allElements[i].classList.add('allowed');
		allElements[i].classList.add('unlocked');
		allElements[i].classList.add('not-void');
		allElements[i].classList.add('ng-valid');
				allElements[i].classList.add('ng-not-empty');
					allElements[i].classList.add('ng-valid-parse');				
					allElements[i].classList.add('ng-valid-luhn');
							allElements[i].classList.add('ng-valid-pattern');
							allElements[i].classList.add('ng-valid-maxlength');
							allElements[i].classList.add('ng-valid-len');
							allElements[i].classList.add('ng-valid-validator');
							allElements[i].classList.add('ng-valid-prod-type');
							allElements[i].classList.add('aamIframeLoaded');
					 allElements[i].classList.add('loaded');
			allElements[i].classList.add('unmasked');
			allElements[i].classList.add('ng-dirty');
			allElements[i].classList.add('acceptable');
		allElements[i].classList.add('ng-enabled');
			allElements[i].classList.add('canuse');
			allElements[i].classList.add('can-use');
			allElements[i].classList.add('available');
			allElements[i].classList.add('usable');
			allElements[i].classList.add('allow');
			allElements[i].classList.add('allowedincontext');
			allElements[i].classList.add('editable');
			allElements[i].classList.add('validated');
		allElements[i].classList.add('novalidate');
		allElements[i].classList.add('ng-touched');
		allElements[i].classList.add('enough');
		allElements[i].classList.add('clickable');
				allElements[i].classList.add('enableTextSelection');
										allElements[i].classList.add('j-text-editable');

						allElements[i].classList.add('allowTextSelection');
					
					
				allElements[i].classList.add('identified');
								allElements[i].classList.add('state-recognized');
				allElements[i].classList.add('state-initialized');
					allElements[i].classList.add('gc-enabled');	
	allElements[i].classList.add('md-input-has-value');	
	allElements[i].classList.add('ng-valid-maxlength');	
	
	
	
		allElements[i].classList.remove('inactive');	
		
		
				
		//zone-off wsite-theme-clean wsite-theme-light logo-scroll-off show-mega-panel-off  has-bm
		//skip-link skip-main skip-bm     style:is_customized: 1;
		
						allElements[i].classList.add('logo-scroll-off');	
	allElements[i].classList.add('show-mega-panel-off');	
				allElements[i].classList.add('has-bm');	
	allElements[i].classList.remove('zone-off');	
allElements[i].classList.add('toggle-edit');	
	allElements[i].classList.add('app-zone');
	allElements[i].classList.add('.edit-form');
	allElements[i].classList.add('edit-form');
		allElements[i].classList.add('ng-active');
	allElements[i].classList.add('active');
			allElements[i].classList.remove('data-hj-masked');		
					
					
					if (allElements[i].hasAttribute('inactive')) {
          allElements[i].removeAttribute('inactive');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed inactive attribute!','color: green;font-weight: 500;')
    }
	

				if (allElements[i].hasAttribute('aria-keyshortcuts')) {
          allElements[i].removeAttribute('aria-keyshortcuts');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-keyshortcuts attribute!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('ng-invalid-validatorname')) {
          allElements[i].removeAttribute('ng-invalid-validatorname');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid-validatorname attribute!','color: green;font-weight: 500;')
    }
	
					
					
						 if (allElements[i].hasAttribute('data-hj-masked')) {
          allElements[i].removeAttribute('data-hj-masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-hj-masked attribute!','color: green;font-weight: 500;')
    
	}
		 if (allElements[i].hasAttribute('data-masked')) {
          allElements[i].removeAttribute('data-masked');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-hj-masked attribute!','color: green;font-weight: 500;')
    }
	
	 if (allElements[i].hasAttribute('inputmode')) {
          allElements[i].removeAttribute('inputmode');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed inputmode attribute!','color: green;font-weight: 500;')
    }
	
	 
	    if (allElements[i].hasAttribute('override-pattern-js')) {
        allElements[i].removeAttribute('override-pattern-js');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed override-pattern-js attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('data-dismiss')) {
        allElements[i].removeAttribute('data-dismiss');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-dismiss attribute!','color: green;font-weight: 500;')
    }

	 
	   if (allElements[i].getAttribute('id') === "disable_restrictions") {
        allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced disable_restrictions true')
    }
	
	   if (allElements[i].getAttribute('id') === "simulated") {
        allElements[i].setAttribute('value','false');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced simulated false')
    }
	
	allElements[i].classList.remove('has-failure');
				allElements[i].classList.remove('has-fail');
				allElements[i].classList.remove('has-error');
				allElements[i].classList.remove('has-failed');
				allElements[i].classList.remove('has-errors');
						
				if (allElements[i].hasAttribute('ws-modify-Unavbl')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log('%c  ' + i + ' - Removed ws-modify-Unavbl attribute!','color: green;font-weight: 500;')
    }	
				if (allElements[i].hasAttribute('ws-modify-Unavalable')) {
          allElements[i].removeAttribute('ws-modify-Unavbl');
		console.log('%c  ' + i + ' - Removed ws-modify-Unavbl attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-std-maxlength')) {
          allElements[i].removeAttribute('data-std-maxlength');
		console.log('%c  ' + i + ' - Removed data-std-maxlength attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('unselectable')) {
          allElements[i].removeAttribute('unselectable');
		console.log('%c  ' + i + ' - Removed unselectable attribute!','color: green;font-weight: 500;')
    }	
	
						if (allElements[i].hasAttribute('data-cs-mask')) {
          allElements[i].removeAttribute('data-cs-mask');
		console.log('%c  ' + i + ' - Removed data-cs-mask attribute!','color: green;font-weight: 500;')
    }	
	
		if (allElements[i].hasAttribute('data-relaxed-maxlength')) {
          allElements[i].removeAttribute('data-relaxed-maxlength');
		console.log('%c  ' + i + ' - Removed data-relaxed-maxlength attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('data-mask-credit-card')) {
          allElements[i].removeAttribute('data-mask-credit-card');
		console.log('%c  ' + i + ' - Removed data-mask-credit-card attribute!','color: green;font-weight: 500;')
    }	
	
	if (allElements[i].hasAttribute('zip-error-key')) {
          allElements[i].removeAttribute('zip-error-key');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed zip-error-key attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('zip-required')) {
          allElements[i].removeAttribute('zip-required');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed zip-required attribute!','color: green;font-weight: 500;')
    }			
					if (allElements[i].hasAttribute('data-error-key')) {
          allElements[i].removeAttribute('data-error-key');
		console.log('%c  ' + i + ' - Removed data-error-key attribute!','color: green;font-weight: 500;')
    }	
				if (allElements[i].hasAttribute('xo-error-tooltip')) {
          allElements[i].removeAttribute('xo-error-tooltip');
		console.log('%c  ' + i + ' - Removed xo-error-tooltip attribute!','color: green;font-weight: 500;')
    }	
	
			if (allElements[i].hasAttribute('autocapitalize')) {
          allElements[i].setAttribute('autocapitalize','on');
		// console.log('%c  ' + i + ' - Forced autocapitalize on attribute!','color: green;font-weight: 500;')
    }	
	if (allElements[i].hasAttribute('autocorrect')) {
          allElements[i].setAttribute('autocorrect','on');
		// console.log('%c  ' + i + ' - Forced autocorrect on attribute!','color: green;font-weight: 500;')
    }	
		if (allElements[i].hasAttribute('oncontextmenu')) {
          allElements[i].removeAttribute('oncontextmenu');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed oncontextmenu attribute!','color: green;font-weight: 500;')
    }
}


// BUTTONS ONLY


if (allElements[i].type === "submit"||allElements[i].type === "button") {

allElements[i].style.cursor === "pointer"


}
// JUST BASIC TEXT INPUTS AND BUTTONS AND FILE

if (allElements[i].type === "text"||allElements[i].type === "button"||allElements[i].type === "select"||allElements[i].type === "hidden"||allElements[i].type === "submit"||allElements[i].type === "checkbox"||allElements[i].type === "submit"||allElements[i].type === "radio"||allElements[i].type === "file"||allElements[i].type === "file-upload-button"||allElements[i].type === "input[text]"||allElements[i].type === "input[false]"||allElements[i].type === "input[radio]"||allElements[i].type === "select-one") {




  if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElementRed(allElements[i]);
		
		if (allElements[i].type === "text" || allElements[i].type === "hidden")   highlightElementRedBG(allElements[i]);
// Set Placeholder, Title, and Tooltips
			 				var namename5 = allElements[i].getAttribute("name");

			 	var namenamearia = allElements[i].getAttribute("aria-label");
				var namename5 = allElements[i].getAttribute("name");
				var namenameid = allElements[i].getAttribute("id");
				var namenametype = allElements[i].type;
				if (namenameid === null||namenameid === undefined||namenameid === '') namenameid = " ";
					if (namename5 === null || namename5 === '' || namename5 === 'null' || namename5 === 'undefined' || namename5 === undefined) namename5 = " ";
										if (namenamearia === null || namenamearia === '' || namenamearia === 'null' || namenamearia === 'undefined' || namenamearia === undefined) namenamearia = " ";

			var namename6 = " " + namenamearia + " " + namename5 + " " + namenameid + namenametype;
			

	 	 allElements[i].setAttribute('alt',namename6);
	 	 allElements[i].setAttribute('tooltip',namename6);
		 	 	 if (!allElements[i].hasAttribute("placeholder")) allElements[i].setAttribute('placeholder',namename6);
		 	 	 if (!allElements[i].hasAttribute("title")) allElements[i].setAttribute('title',namename6);
// END Set Placeholder, Title, and Tooltips
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElementRed(allElements[i]);
		if (allElements[i].type === "text" || allElements[i].type === "hidden")   highlightElementRedBG(allElements[i]);
	
				 
// Set Placeholder, Title, and Tooltips
			 				var namename5 = allElements[i].getAttribute("name");

			 	var namenamearia = allElements[i].getAttribute("aria-label");
				var namename5 = allElements[i].getAttribute("name");
				var namenameid = allElements[i].getAttribute("id");
				var namenametype = allElements[i].type;
				if (namenameid === null||namenameid === undefined||namenameid === '') namenameid = " ";
					if (namename5 === null || namename5 === '' || namename5 === 'null' || namename5 === 'undefined' || namename5 === undefined) namename5 = " ";
										if (namenamearia === null || namenamearia === '' || namenamearia === 'null' || namenamearia === 'undefined' || namenamearia === undefined) namenamearia = " ";

			var namename6 = " " + namenamearia + " " + namename5 + " " + namenameid + " " + namenametype;
			

	 	 allElements[i].setAttribute('alt',namename6);
	 	 allElements[i].setAttribute('tooltip',namename6);
		 	 	 if (!allElements[i].hasAttribute("placeholder")) allElements[i].setAttribute('placeholder',namename6);
		 	 	 if (!allElements[i].hasAttribute("title")) allElements[i].setAttribute('title',namename6);
// END Set Placeholder, Title, and Tooltips
	
	    if (allElements[i].style.opacity === "0"||allElements[i].style.opacity === "0.0"||allElements[i].style.opacity === "0.1"||allElements[i].style.opacity === "0.2"||allElements[i].style.opacity === "0.3"||allElements[i].style.opacity === "0.10") {
        allElements[i].style.opacity = "1";
        highlightElementRed(allElements[i]);
		if (allElements[i].type === "text" || allElements[i].type === "hidden")   highlightElementRedBG(allElements[i]);
	
    }
	
	
				allElements[i].classList.add('parsley-validated');
					allElements[i].classList.add('parsley-success');
							allElements[i].classList.add('ws-enabled');
							
							
			
				allElements[i].classList.add('zeroCostItem');
		 
	
	
	
}
}
// ALL INPUTS AND FORM ELEMENTS ONLY

if ((allElements[i].type !== undefined && allElements[i].type !== '') && (allElements[i].type === "ul"||allElements[i].type === "li"||allElements[i].type === "hidden"||allElements[i].type === "text"||allElements[i].type === "input"||allElements[i].type === "select"||allElements[i].type === "option"||allElements[i].type === "form"||allElements[i].type === "inputbox"||allElements[i].type === "password"||allElements[i].type === "hidden"||allElements[i].type === "email"||allElements[i].type === "url"||allElements[i].type === "tel"||allElements[i].type === "tel"||allElements[i].type === "textarea"||allElements[i].type === "radio"||allElements[i].type === "checkbox"||allElements[i].type === "fieldset"||allElements[i].type === "button"||allElements[i].type === "submit"||allElements[i].type === "reset"||allElements[i].type === "input[type=td]"||allElements[i].type === "input[type=tr]"||allElements[i].type === "input[type=span]"||allElements[i].type === "input[type=label]")) {

	
	
	
	
	if (allElements[i].type === "hidden") {
			

// Set Placeholder, Title, and Tooltips
			 				var namename5 = allElements[i].getAttribute("name");

			 	var namenamearia = allElements[i].getAttribute("aria-label");
				var namename5 = allElements[i].getAttribute("name");
				var namenameid = allElements[i].getAttribute("id");
				var namenametype = allElements[i].type;
				if (namenameid === null||namenameid === undefined||namenameid === '') namenameid = " ";
					if (namename5 === null || namename5 === '' || namename5 === 'null' || namename5 === 'undefined' || namename5 === undefined) namename5 = " ";
										if (namenamearia === null || namenamearia === '' || namenamearia === 'null' || namenamearia === 'undefined' || namenamearia === undefined) namenamearia = " ";

			var namename6 = " " + namenamearia + " " + namename5 + " " + namenameid + " " + namenametype;
			

	 	 allElements[i].setAttribute('alt',namename6);
	 	 allElements[i].setAttribute('tooltip',namename6);
		 	 	 if (!allElements[i].hasAttribute("placeholder")) allElements[i].setAttribute('placeholder',namename6);
		 	 	 if (!allElements[i].hasAttribute("title")) allElements[i].setAttribute('title',namename6);
// END Set Placeholder, Title, and Tooltips

			allElements[i].removeAttribute('disabled');
			   allElements[i].removeAttribute('hidden');
		 allElements[i].removeAttribute('visibility');
		 allElements[i].removeAttribute('left');
		 allElements[i].removeAttribute('style');
		  allElements[i].removeAttribute('display');
		   allElements[i].removeAttribute('top');
			allElements[i].removeAttribute('frameborder');
			 allElements[i].removeAttribute('width');
			  	 allElements[i].removeAttribute('height');
				  	 allElements[i].removeAttribute('aria-hidden');
					    	 allElements[i].removeAttribute('position');
							 allElements[i].removeAttribute('align');
							 allElements[i].removeAttribute('locked');
							  allElements[i].removeAttribute('disabled');
							    allElements[i].removeAttribute('class');
								  allElements[i].removeAttribute('border');
								     allElements[i].removeAttribute('protected');
									  allElements[i].removeAttribute('std-maxlength');
									   allElements[i].removeAttribute('anchor');
										allElements[i].removeAttribute('anchors');
										allElements[i].removeAttribute('dialogWidth');
										      allElements[i].removeAttribute('readonly');
											        allElements[i].removeAttribute('read-only');
													 allElements[i].removeAttribute('overflow');
													  allElements[i].removeAttribute('margins');
													 allElements[i].removeAttribute('marginBottom');
													 	 allElements[i].removeAttribute('marginLeft');
														  allElements[i].removeAttribute('marginTop');
														  	  allElements[i].removeAttribute('override-ltr');
															  
															  	  	  allElements[i].removeAttribute('z-Index');
																	  
															    allElements[i].removeAttribute('zIndex');
																	    allElements[i].removeAttribute('invalid');
																	
																	  
																	  
															  
															   
	          highlightElementRedBG(allElements[i]);

			console.log('%c  ' + i + ' - Changed hidden input to unrestricted textbox!','color: green;font-weight: 500;')
			
				 allElements[i].removeAttribute('zIndex');
	
		 allElements[i].removeAttribute('z-Index');
			
			  allElements[i].type = "text";
			
    }
	
	
	
/* en_US countryUS USD src_ en st_ Smartv2 Desktop Chrome

// Visible Span if Matches Other Elements

availabilityMessage sr-only hidden
<span class="occupiedNameContainer hidden sr-only"> 

*/

							 

							
					
						
							allElements[i].disabled = false;
							allElements[i].enabled = true;
						
						// The global added styles
						
					
					
		
									allElements[i].classList.remove('element-invisible');

							allElements[i].classList.remove('hidden-lg-down');
					allElements[i].classList.remove('IPE_hidden');
					allElements[i].classList.add('is-complete');

		
			/*
			

				*/
				

	allElements[i].classList.remove('hidden_elem');
			allElements[i].classList.remove('hidden-print');
			
			
 
						
	if (allElements[i].hasAttribute('onblur')) {
          allElements[i].removeAttribute('onblur');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed blur attribute!','color: green;font-weight: 500;')
    }	
		if (allElements[i].hasAttribute('keypress')) {
          allElements[i].removeAttribute('keypress');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed keypress attribute!','color: green;font-weight: 500;')
    }			
				if (allElements[i].hasAttribute('keydown')) {
          allElements[i].removeAttribute('keydown');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed keydown attribute!','color: green;font-weight: 500;')
    }					
		if (allElements[i].hasAttribute('keypressintercept')) {
          allElements[i].removeAttribute('keypressintercept');
        highlightElementRed(allElements[i]);
		console.log('%c  ' + i + ' - Removed keypressintercept attribute!','color: green;font-weight: 500;')
    }							
	 // ADD Placeholder to all elements
	
		if (!allElements[i].hasAttribute('placeholder')) {
					 var namename5 = "";
					  var namename4 = "";
			 	var namename4 = allElements[i].getAttribute("aria-label");
				if (allElements[i].getAttribute("name") !== null) namename5 = allElements[i].getAttribute("name");
				if (allElements[i].getAttribute("aria-label") !== null) namename4 = allElements[i].getAttribute("aria-label");

			var namename6 = " " + namename4 + " " + namename5;
				if (!namename4 && !namename5||namename4 === null && namename5 === null) namename6 = "";



	 	 allElements[i].setAttribute('placeholder',allElements[i].getAttribute("id") + namename6);

		// console.log('%c  ' + i + ' - Added placeholder attribute!','color: green;font-weight: 500;')
    }	


allElements[i].setAttribute('data-ux-jq-mouseenter','true');
allElements[i].setAttribute('data-ng-enabled','true');
allElements[i].setAttribute('primary','true');
allElements[i].setAttribute('data-hj-whitelist','true');
			 	 allElements[i].setAttribute('novalidate','novalidate');
	 allElements[i].setAttribute('autocomplete','on');
	 	 allElements[i].setAttribute('aria-autocomplete','both');
		  allElements[i].setAttribute('data-form-verified',true);
	allElements[i].setAttribute('data-form-checked',true);
allElements[i].setAttribute('data-profile-complete',true);
	 allElements[i].setAttribute('data-profile-complete',true);
	
	   allElements[i].removeAttribute('aria-invalid');
	   allElements[i].removeAttribute('ng-readonly');
	 	 allElements[i].removeAttribute('disable-copy-paste');
		 allElements[i].removeAttribute('numbers-only');
		 allElements[i].removeAttribute('data-a11y-validation');
	
		  if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElementRed(allElements[i]);
		 allElements[i].setAttribute('tooltip',allElements[i].getAttribute("id"));
	 	 allElements[i].setAttribute('alt',allElements[i].getAttribute("id"));
		 	 	 allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
    }

	


		 	if (!allElements[i].hasAttribute('title')) {
          allElements[i].setAttribute('title',allElements[i].getAttribute("id"));
		
    }	
		 
	  if (allElements[i].hasAttribute('aria-hidden')) {
        allElements[i].setAttribute('aria-hidden','false');
			console.log('%c  ' + i + ' - Forced false aria-hidden value!','color: green;font-weight: 500;')
    }
		  if (allElements[i].hasAttribute('is-optional')) {
        allElements[i].setAttribute('is-optional','true');
			console.log('%c  ' + i + ' - Forced is-optional true value!','color: green;font-weight: 500;')
    }
	  if (allElements[i].hasAttribute('aria-busy')) {
        allElements[i].setAttribute('aria-busy','false');
			console.log('%c  ' + i + ' - Forced false aria-busy value!','color: green;font-weight: 500;')
    }
	
		  if (allElements[i].hasAttribute('aria-invalid')) {
        allElements[i].setAttribute('aria-invalid','false');
			console.log('%c  ' + i + ' - Forced false aria-invalid value!','color: green;font-weight: 500;')
    }
	
	
		  if (allElements[i].hasAttribute('data-pii')) {
        allElements[i].setAttribute('data-pii','');
			console.log('%c  ' + i + ' - Forced blank data-pii value!','color: green;font-weight: 500;')
    }
	
	
		if (allElements[i].hasAttribute('aria-invalid')) {
          allElements[i].removeAttribute('aria-invalid');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-invalid attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('data-profile-complete')) {
          allElements[i].setAttribute('data-profile-complete','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Set Data-profile-complete attribute to true','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('data-percent')) {
          allElements[i].setAttribute('data-percent','100');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Set data-percent attribute to true','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('data-form-verified')) {
          allElements[i].setAttribute('data-form-verified','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Set data-form-verified attribute to true','color: green;font-weight: 500;')
    }
	
	
	
			if (allElements[i].hasAttribute('ng-keypress')) {
          allElements[i].removeAttribute('ng-keypress');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-keypress attribute!','color: green;font-weight: 500;')
    }
	
	
	
	
	
	if (allElements[i].hasAttribute('unless-feature')) {
          allElements[i].removeAttribute('unless-feature');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless-feature attribute!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('unless')) {
          allElements[i].removeAttribute('unless');
        highlightElement(allElements[i]);
		console.log('%c  ' + i + ' - Removed unless attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('unknown')) {
          allElements[i].removeAttribute('unknown');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed unknown attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('ws-error')) {
          allElements[i].removeAttribute('ws-error');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ws-error attribute!','color: green;font-weight: 500;')
    }
	
	if (allElements[i].hasAttribute('data-rule-allowedincontext')) {
          allElements[i].removeAttribute('data-rule-allowedincontext');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-rule-allowedincontext attribute!','color: green;font-weight: 500;')
    }
	
		if (allElements[i].hasAttribute('minlength')) {
          allElements[i].removeAttribute('minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed minlength attribute!','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('numberonly')) {
          allElements[i].removeAttribute('numberonly');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - removed numberonly attribute!','color: green;font-weight: 500;')
    }
	
	
	
	   if (allElements[i].hasAttribute('foo')) {
        allElements[i].foo = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced foo attribute to false!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('bar')) {
        allElements[i].bar = false;
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced bar attribute to false!','color: green;font-weight: 500;')
    }
	  if (allElements[i].hasAttribute('lang')) {
        allElements[i].lang = "en";
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Forced lang attribute to en!','color: green;font-weight: 500;')
    }

	
	  if (allElements[i].hasAttribute('required')) {
          allElements[i].removeAttribute('required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed required attribute!','color: green;font-weight: 500;')
    }
	
	  if (allElements[i].hasAttribute('aria-valuemax')) {
          allElements[i].removeAttribute('aria-valuemax');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-valuemax attribute!','color: green;font-weight: 500;')
    }
	
	
	if (allElements[i].hasAttribute('aria-valuemin')) {
          allElements[i].removeAttribute('aria-valuemin');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed aria-valuemi attribute!','color: green;font-weight: 500;')
    }
	
	
		  if (allElements[i].hasAttribute('data-rule-luhn')) {
          allElements[i].removeAttribute('data-rule-luhn');
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Removed data-rule-luhn attribute!','color: green;font-weight: 500;')
    }
		  if (allElements[i].hasAttribute('ng-init')) {
          allElements[i].removeAttribute('ng-init');
        highlightElementOrange(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-init attribute!','color: green;font-weight: 500;')
    }
		 
	   if (allElements[i].getAttribute('id') === "form_agree") {
     
	     allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('checkbox')||allElements[i].type('option')||allElements[i].type('radio')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Checked form_agree box')
    }
	   }
	   
	   	   if (allElements[i].getAttribute('id') === "form_agree") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('text')||allElements[i].type('hidden')) { 
	   allElements[i].setAttribute('value','1');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Triggered true for form_agree input')
    }
	   }
	   	   if (allElements[i].getAttribute('id') === "TermsAndConditions") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('text')||allElements[i].type('hidden')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Triggered true for TermsAndConditions input')
    }
	   }
	      if (allElements[i].getAttribute('id') === "TermsAndConditions") {
         allElements[i].setAttribute('data-val','true');
	   if (allElements[i].type('checkbox')||allElements[i].type('option')||allElements[i].type('radio')) { 
	   allElements[i].setAttribute('value','true');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Checked form_agree box')
    }
	   }
	   
	   
	
	 
	   if (allElements[i].hasAttribute('ng-required')) {
        allElements[i].removeAttribute('ng-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-required attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-empty')) {
        allElements[i].removeAttribute('ng-empty');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-empty attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('ng-invalid-required')) {
        allElements[i].removeAttribute('ng-invalid-required');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-invalid-required attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('ng-pristine')) {
        allElements[i].removeAttribute('ng-pristine');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-pristine attribute!','color: green;font-weight: 500;')
    }
 if (allElements[i].hasAttribute('ng-untouched')) {
        allElements[i].removeAttribute('ng-untouched');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-untouched attribute!','color: green;font-weight: 500;')
    } 
	

    if (allElements[i].hasAttribute('maxLength')) {
        allElements[i].removeAttribute('maxLength');
        highlightElementGreen(allElements[i]);
				console.log('%c  ' + i + ' - Removed maxLength attribute!','color: green;font-weight: 500;')
    }
	    if (allElements[i].hasAttribute('data-ng-disabled')) {
        allElements[i].removeAttribute('data-ng-disabled');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-disabled attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-ng-minlength')) {
        allElements[i].removeAttribute('data-ng-minlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-minlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-ng-maxlength')) {
        allElements[i].removeAttribute('data-ng-maxlength');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-maxlength attribute!','color: green;font-weight: 500;')
    }
		   if (allElements[i].hasAttribute('data-ng-pattern')) {
        allElements[i].removeAttribute('data-ng-pattern');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-ng-pattern attribute!','color: green;font-weight: 500;')
    }
	
			   if (allElements[i].hasAttribute('ng-pattern')) {
        allElements[i].removeAttribute('ng-pattern');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-pattern attribute!','color: green;font-weight: 500;')
    }
	
	   if (allElements[i].hasAttribute('my-maxlength')) {
        allElements[i].removeAttribute('my-maxlength');
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Removed my-maxlength attribute!','color: green;font-weight: 500;')
    }
	   if (allElements[i].hasAttribute('data-rule-regularexpression')) {
        allElements[i].removeAttribute('data-rule-regularexpression');
					console.log('%c  ' + i + ' - Removed data-rule-regularexpression attribute!','color: green;font-weight: 500;')
        highlightElementGreen(allElements[i]);
    }
    if (allElements[i].hasAttribute('pattern')) {
        allElements[i].removeAttribute('pattern');
        highlightElementGreen(allElements[i]);
					console.log('%c  ' + i + ' - Removed pattern attribute!','color: green;font-weight: 500;')
    }
    if (allElements[i].type === "email") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed email type into text!','color: green;font-weight: 500;')
    }
    if (allElements[i].type === "url") {
        allElements[i].type = "text";
    highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed url type into text!','color: green;font-weight: 500;')
    }
	  if (allElements[i].type === "tel") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed tel type into text!','color: green;font-weight: 500;')
    }
		  if (allElements[i].type === "inputbox") {
        allElements[i].type = "text";
        highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed inputbox type into text!','color: green;font-weight: 500;')
    }
		  if (allElements[i].type === "password") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed password type into text!','color: green;font-weight: 500;')
    }
		  if (allElements[i].type === "option") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed option type into text!','color: green;font-weight: 500;')
    }
	  if (allElements[i].type === "input[type=tel][disabled]"||allElements[i].type === "input[disabled]"||allElements[i].type === "[disabled]"||allElements[i].type === "input[type=hidden]||input[type=hidden][disabled]") {
        allElements[i].type = "text";
       highlightElementGreen(allElements[i]);
			console.log('%c  ' + i + ' - Changed [disabled] type into text!','color: green;font-weight: 500;')
    }
	
	
	
	if ((allElements[i].getAttribute("tooltip")) === "null" || allElements[i].getAttribute("tooltip") === null)  allElements[i].setAttribute('tooltip',allElements[i].type + ' ' + allElements[i].getAttribute('name'));

		if ((allElements[i].getAttribute("alt")) === "null" || allElements[i].getAttribute("alt") === null)  allElements[i].setAttribute('alt',allElements[i].type + ' ' + allElements[i].getAttribute('name'));

			if ((allElements[i].getAttribute("placeholder")) === "null" || allElements[i].getAttribute("placeholder") === null) {
				
				
			
				
if (allElements[i].type === "text" || allElements[i].type === "input" || allElements[i].type === "button" || allElements[i].type === "textarea" || allElements[i].type === "input[button]")	{
	
	
	
			allElements[i].setAttribute('placeholder',allElements[i].type);
			}
			
			}
			
			

			}	 
	  //  input[type=time][disabled] input[type=url][disabled]
   
   
   // Last actions before ending array loop
   
   							allElements[i].classList.remove('form-error-message-container');
							allElements[i].classList.remove('form-error-message');
							allElements[i].classList.remove('backdrop');
														allElements[i].classList.remove('error');
							allElements[i].classList.remove('errorData');
							allElements[i].classList.remove('errorBody');
							allElements[i].classList.remove('errorBox');
							allElements[i].classList.remove('required');
							allElements[i].classList.remove('dwfrm_billing_paymentMethods_creditCard_number_d0ygjkojooib-error');
							allElements[i].classList.remove('invalid');
allElements[i].classList.remove('locked');
allElements[i].classList.remove('errorSpan');
allElements[i].classList.remove('validator_errorMsg');
allElements[i].classList.remove('readonly');
allElements[i].classList.remove('orderErrors');
allElements[i].classList.remove('woocommerce-error');
allElements[i].classList.remove('ng-animate-shim');
allElements[i].classList.remove('ngCloak');
allElements[i].classList.remove('loading');
allElements[i].classList.remove('main-frame-error');
allElements[i].classList.remove('sub-frame-error');
allElements[i].classList.remove('neterror');
allElements[i].classList.remove('main-frame-error');
allElements[i].classList.remove('ui-state-disabled');



							
   }
	
	
	
	 
	  
	  
	  
	  
	  if(typeof utag_data=="undefined"){
utag_data = {}
}

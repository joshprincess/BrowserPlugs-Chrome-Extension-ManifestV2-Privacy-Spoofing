/* // aspNetHidden

is-hidden
attribute: ng-hide

<input type="checkbox" id="terms-check" data-qa="confirm_shopCart" name="paymentRequest.agreePersonalDataProcessing" data-validator-id="confirmAgree" data-validator-ga="TERMS" required="" value="true">

		*/
		
		var all = false;
		var labels = true;
		var divs = true;
		var buttons = true;
		var input_controls = true;
		
function highlightElement(anElement) {
    anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
    anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
    anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
    anElement.style.border = "thin solid orange";
}
losInputs = [];
losButtons = [];
losDivs = [];
losLabels = [];
losAll = [];
col1 = [];
col2 = [];
col3 = [];

if(all){losAll = document.getElementsByTagName("*");
}
else{
	if(input_controls){
		losRadio = document.querySelectorAll('select');
		losTextboxes = document.querySelectorAll('button');
		losPassword = document.querySelectorAll('form');
		losCheckboxes = document.querySelectorAll('input');
		combo1 = [].concat(Array.prototype.slice.call(losRadio), Array.prototype.slice.call(losTextboxes));
		combo2 = [].concat(Array.prototype.slice.call(losPassword), Array.prototype.slice.call(losCheckboxes));
		losInputs = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losInputs = []; }
	if(buttons){
		losSubmit = document.querySelectorAll('selection');
		losBotones = document.querySelectorAll('legend');
		losButtons = [].concat(Array.prototype.slice.call(losSubmit), Array.prototype.slice.call(losBotones));
	} else { losButtons = []; }
	if(divs){
	//	losDivs = 
		
		losDivs = document.querySelectorAll('option');
	
	} else { losDivs = []; }
	if(labels){
/*
	losTD = document.querySelectorAll('input[type=td]');
		losTR = document.querySelectorAll('input[type=tr]');
		losSpan = document.querySelectorAll('input[type=span]');
		losLabels = document.querySelectorAll('input[type=label]');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
*/		

	losTD = document.querySelectorAll('fieldset');
		losTR = document.getElementsByTagName("iframe");
		losSpan = document.getElementsByTagName("div");
		losLabels = document.querySelectorAll('a');
		combo3 = [].concat(Array.prototype.slice.call(losTD), Array.prototype.slice.call(losTR));
		combo4 = [].concat(Array.prototype.slice.call(losSpan), Array.prototype.slice.call(losLabels));
		losLabels = [].concat(Array.prototype.slice.call(combo1), Array.prototype.slice.call(combo2));
	} else { losLabels = []; }
}

		col1 = [].concat(Array.prototype.slice.call(losInputs), Array.prototype.slice.call(losButtons));
		col2 = [].concat(Array.prototype.slice.call(losDivs), Array.prototype.slice.call(losLabels));
		col3 = [].concat(Array.prototype.slice.call(col1), Array.prototype.slice.call(col2));
		allElements = [].concat(Array.prototype.slice.call(losAll), Array.prototype.slice.call(col3));

var max = allElements.length;
var paint = "rgb(255,200,200)";

for (var i = 0; i < max; i++) {

//if (allElements[i].type !== undefined && allElements[i].type !== '') console.log('Element: ' + i + ' / ' + max + ' | For: ' + allElements[1].getAttribute("for") + ' | id: ' + allElements[i].getAttribute("id") + ' | Type: ' + allElements[i].type);

for (var i = 0; i < max; i++) {
    if (allElements[i].style.visibility === "hidden") {
        allElements[i].style.visibility = "visible";
        highlightElement(allElements[i]);
    }
    if (allElements[i].style.display === "none") {
        allElements[i].style.display = "block";
        highlightElement(allElements[i]);
    }
	    if (allElements[i].style.hidden_elem === "none") {
        allElements[i].style.display = "block";
        highlightElement(allElements[i]);
    }
	
    if (allElements[i].type === "hidden") {
        allElements[i].type = "text";
        highlightElement(allElements[i]);
    }
}
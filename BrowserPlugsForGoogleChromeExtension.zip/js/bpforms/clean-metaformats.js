<meta name="format-detection" content="telephone=no">

// al:ios:app_store_id
// <meta data-react-helmet="true" name="twitt//er:app:url:googleplay" content="ihr://play/live/4257">
// <meta data-react-helmet="true" name="twitter:app:url:ipad" content="ihr://play/live/4257">
// <meta data-react-helmet="true" content="audio/vnd.facebook.bridge" property="og:audio:type">
// <link data-react-helmet="true" href="/manifest.6a2f10c7f194b2a76747f18937e42951.json" rel="manifest">
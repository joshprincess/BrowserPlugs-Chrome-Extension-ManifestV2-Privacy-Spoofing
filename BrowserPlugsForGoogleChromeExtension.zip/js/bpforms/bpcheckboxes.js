function myFunction() {
// Get the checkbox
var checkBox = document.getElementByTag("checkbox");
// Get the output text
// var text = document.getElementById("*");
// If the checkbox is checked, display the output text
  if (checkBox.checked == true){
    checkBox.checked == false;
  } else {
   checkBox.checked == true;
  }
}


/* class:   passenger-card__gender-item passenger-card__gender-item--active

data-gender-value="1" aria-label="Мужской" role="button" aria-pressed="false"


 */
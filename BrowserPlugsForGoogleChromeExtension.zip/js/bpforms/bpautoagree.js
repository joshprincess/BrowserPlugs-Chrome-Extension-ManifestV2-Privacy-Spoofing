/* 

<input name="finalCheckBox" type="checkbox" style="position: relative; left: 280px;">

<input type="checkbox" id="terms-check" data-qa="confirm_shopCart" 
name="paymentRequest.agreePersonalDataProcessing" data-validator-id="confirmAgree" 
data-validator-ga="TERMS" required="" value="true">

V152_C0_pa_PolicyAckCheckBox
V152_C0_pa_PolicyAckCheckBox
<input id="V152_C0_pa_PrivacyPolicyAckCheckBox" type="checkbox" name="V152$C0$pa$PrivacyPolicyAckCheckBox">
<label for="V152_C0_pa_PolicyAckCheckBox" id="V152_C0_pa_PolicyAckLabel">Please acknowledge that you have read and accept our</label>

// False:

<input type="checkbox" id="submit_to_trip_advisor" name="submit_to_trip_advisor" value="yes">

<input id="acceptTerms" name="acceptTerms" class="checkbox" type="checkbox" value="true">


<input type="checkbox" title="Remember Me" name="remember" id="auth-n-logon-remember-1664b9e64ff8fd1b"

<div class="payment-content js_payment_tab_content js-card-form active" data-enabled-b2c="true" data-enabled-b2b="true" data-payment-type="paycard" data-qa="bankCardPax_block">
                                    
                                    
<input type="checkbox" id="passangersTermsAndConditions" class="input__checkbox" value="on">

passangersTermsAndConditions

    <input type="hidden" id="available-card-types" value="[VI, CA, MA, MI]
	
	// Dupe EmailConfirm:
// <input id="tpl3_widget-input-travellerList-contactInformation-EmailConfirm" name="EmailConfirm" aria-describedby="tpl3_error-message-travellerList-contactInformation-EmailConfirm" placeholder="Please Confirm your E-Mail" autocomplete="on" class="form-control" atdelegate="d122" type="TEXT">

termsAgreement
*/
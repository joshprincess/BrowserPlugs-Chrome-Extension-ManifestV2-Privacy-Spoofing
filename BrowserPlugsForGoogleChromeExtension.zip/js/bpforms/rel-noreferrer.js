// get the domains to be excluded from noref. have to pass message to the background for this
// since here we're at the page context and localstorage isn't that of the extension.
chrome.extension.sendRequest({code: 1}, function(response) {
  if (response.a!=null) {
    var url= location.href.toLowerCase();
    // clean up the records and then splits on newlines to get an array of records to check
    var exdomains = response.a.replace(/^\s+|\r|\s+$/g,"").split("\n");
    for (i=0;i<exdomains.length;i++) {
      // if the expression is in the url, user wants the page unmolested, so back out.
      if (url.indexOf(exdomains[i].toLowerCase())>=0) {
        return;
      }
    }
  }
  // add rel="noreferrer" to all <a> tags. html5 respects this attribute and browser doesn't send http_referer to the landing page.
  var links = document.body.getElementsByTagName("a");
  for (i = 0; i < links.length; i++) {
    links[i].setAttribute("rel","noreferrer");
  }
  
});

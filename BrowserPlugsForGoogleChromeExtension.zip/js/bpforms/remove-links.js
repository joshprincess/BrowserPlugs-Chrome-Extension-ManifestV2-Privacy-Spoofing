console.log('Removing Links with Browser Plugs');
(function() { 

var anchorsall = document.querySelectorAll("*");
console.log('Number of elements found by query: ' + anchorsall.length);
var max = anchorsall.length;
for ( var i=0; i < max; i++ ) {
   	   console.log('Element: ' + anchorsall[i].type + ' ' + anchorsall[i].value);

   if (anchorsall[i].type !== 'HEAD' && anchorsall[i].type !== 'A') {
	   console.log('Non HEAD or A element: ' + anchorsall[i].type + ' ' + anchorsall[i].value);

		 anchorsall[i].type == "P";
		 
    }
}
})

(function() { 

var anchorsall = document.getElementsByTagName("*");
console.log('Number of elements found by tag name: ' + anchorsall.length);
for ( var i=0; i < anchorsall.length; i++ ) {
   
   if (!anchorsall[i].type === 'HEAD' && !anchorsall[i].type === 'A') {
		 anchorsall[i].type == "P";
    }
}
})



/*



(function() { 

var anchorsall = document.getElementsByTagName("*");

for ( var i=0; i < anchorsall.length; i++ ) {
   
   if ( anchorsall[i].hasAttribute('href') ) {
		 anchorsall[i].setAttribute('href','#');
    }
}
})




var anchors = document.getElementsByTagName("A");

for ( var i=0; i < anchors.length; i++ ) {
    var span = document.createElement("SPAN");
    if ( anchors[i].className ) {
        span.className = anchors[i].className;
    }
  

    if ( anchors[i].id ) {
        span.id = anchors[i].id;
    }
   if ( anchors[i].href ) {
		 anchors[i].setAttribute('href','#');
    }

    span.innerHTML = anchors[i].innerHTML;

    anchors[i].parentNode.replaceChild(span, anchors[i]);
}

	}());
	
	


try {
   document.removeEventListener('click', function(event) {
    event.stopPropagation();
  }, true);
     document.removeEventListener('click', function(event) {
    event.stopPropagation();
}, true);
}
catch {
	
}

try {
     document.removeEventListener('click', function(event) {
    event.stopPropagation();
  }, true);
}
catch { }
try {
     document.addEventListener('click', function(event) {
    event.stopPropagation();
  }, true);
}
catch { }


var ancors3 = document.getElementsByTagName("A");

for ( var i=0; i < ancors3.length; i++ ) {
//change href attribute to #  
  var span = document.createElement("SPAN");
    if ( ancors3[i].className ) {
        span.className = ancors3[i].className;
    }

    if ( ancors3[i].id ) {
        span.id = ancors3[i].id;
    }

    span.innerHTML = ancors3[i].innerHTML;

    ancors3[i].parentNode.replaceChild(span, ancors3[i]);
}


var anchors = document.getElementsByTagName("A");

for ( var i=0; i < anchors.length; i++ ) {
    var span = document.createElement("SPAN");
    if ( anchors[i].className ) {
        span.className = anchors[i].className;
    }

    if ( anchors[i].id ) {
        span.id = anchors[i].id;
    }

    span.innerHTML = anchors[i].innerHTML;

    anchors[i].parentNode.replaceChild(span, anchors[i]);
}


var ancors2 = document.getElementsByTagName("LINK");

for ( var i=0; i < ancors2.length; i++ ) {
    var span = document.createElement("SPAN");
    if ( ancors2[i].className ) {
        span.className = ancors2[i].className;
    }

    if ( ancors2[i].id ) {
        span.id = ancors2[i].id;
    }

    span.innerHTML = ancors2[i].innerHTML;

    ancors2[i].parentNode.replaceChild(span, ancors2[i]);
}




function highlightElement(anElement) {
  //  anElement.style.border = "thin solid hotpink";
}
function highlightElementGreen(anElement) {
  // anElement.style.border = "thin solid green";
}
function highlightElementRed(anElement) {
  //  anElement.style.border = "thin solid red";
}
function highlightElementOrange(anElement) {
   // anElement.style.border = "thin solid orange";
}
losAll = [];
col1 = [];
col2 = [];
col3 = [];



var allElements = document.getElementsByTagName("*");

var max = allElements.length;
var paint = "rgb(255,200,200)";


for (var i = 0; i < max; i++) {
 	if (allElements[i].hasAttribute('href')) {
          allElements[i].setAttribute('href','#');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Changed href to #','color: green;font-weight: 500;')
    }
	if (allElements[i].hasAttribute('oncontextmenu')) {
          allElements[i].removeAttribute('oncontextmenu');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed oncontextmenu attribute!','color: green;font-weight: 500;')
    }
  
  	if (allElements[i].hasAttribute('onclick')) {
          allElements[i].removeAttribute('onclick');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onclick attribute!','color: green;font-weight: 500;')
    }
    	if (allElements[i].hasAttribute('ondoubleclick')) {
          allElements[i].removeAttribute('ondoubleclick');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ondoubleclick attribute!','color: green;font-weight: 500;')
    }
	    	if (allElements[i].hasAttribute('onmousedown')) {
          allElements[i].removeAttribute('onmousedown');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed onmousedown attribute!','color: green;font-weight: 500;')
    }
     	if (allElements[i].hasAttribute('oncontrolselect')) {
          allElements[i].removeAttribute('oncontrolselect');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed oncontrolselect attribute!','color: green;font-weight: 500;')
    }
 
   	if (allElements[i].hasAttribute('click')) {
          allElements[i].removeAttribute('click');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed click attribute!','color: green;font-weight: 500;')
    }
    	if (allElements[i].hasAttribute('ng-keypress')) {
          allElements[i].removeAttribute('ng-keypress');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed ng-keypress attribute!','color: green;font-weight: 500;')
    }
		if (allElements[i].hasAttribute('on-clicks')) {
          allElements[i].removeAttribute('on-clicks');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed on-clicks attribute!','color: green;font-weight: 500;')
    }
	
			if (allElements[i].hasAttribute('onclick')) {
          allElements[i].removeAttribute('onclick');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed on-clicks attribute!','color: green;font-weight: 500;')
    }
			if (allElements[i].hasAttribute('data-modal-click')) {
          allElements[i].removeAttribute('data-modal-click');
        highlightElementGreen(allElements[i]);
		console.log('%c  ' + i + ' - Removed data-modal-click attribute!','color: green;font-weight: 500;')
    }
	

         if (allElements[i].type === "submit") {
        allElements[i].type = "button";
        highlightElement(allElements[i]);
    }
	
	
	
	
	
		try {  document.addEventListener('click', function(event) {
    event.stopPropagation();
  }, true);
	} catch { }
	try {  document.removeEventListener('click')  
	} catch { }
		
	try {  document.removeEventListener('onclick') 
	} catch { }
 	

}
*/

var whitelist2 = false;

	function bp2Run(BrowserPlugsRTM) {
		
 chrome.runtime.sendMessage(BrowserPlugsRTM, function(response) {
 // console.log(`message from background JSON: ${JSON.stringify(response)}`);
   // console.log(response);
	if (response == "ongooglelist") return;
			if (response == "onrestrictedlist") return;
			if (response == "onchromelist") return;
				if (response == "ontrustedlist") return;
//if (response == "notonwhitelist") console.log("[2] Background process did not find url in white list. Continuing to run Browser Plugs protection modules");

if (response == "notonwhitelist") run2();

//if (response == "onwhitelist") console.log("[2] Background process found url on white list");
//if (response == "onwhitelist")  console.log('%c ' + window.location.hostname + ' [2] was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');
//if (response == "onchromelist") console.log("[2] Background process found url on white list");
//if (response == "onwhitelist")  console.log('%c ' + window.location.hostname + ' [2] was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');



//if (response !== "onwhitelist" && response !== "notonwhitelist") console.log("[2] The background process did not return an expected response during a white list check, continuing to run Bowser Plugs protection modules...");
//if (response !== "notonwhitelist") run2();


});

};

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockcanvas) return;
  if (settings.cleanurlz) console.log("| Canvas blocking appended if not whitelisted )              |");

  bp2Run("checkifwhitelist");

 // BPAppendScript("js/bpblock/block-canvas.js");
// bpSendMessage("blockcanvas")


});


function run2(){


var bpInjectCanvas = function () {
  
const toBlob = HTMLCanvasElement.prototype.toBlob;
  const toDataURL = HTMLCanvasElement.prototype.toDataURL;
  const getImageData = CanvasRenderingContext2D.prototype.getImageData;
  //
  var noisify = function (canvas, context) {
    const shift = {
      'r': Math.floor(Math.random() * 10) - 5,
      'g': Math.floor(Math.random() * 10) - 5,
      'b': Math.floor(Math.random() * 10) - 5,
      'a': Math.floor(Math.random() * 10) - 5
    };
    //
    const width = canvas.width, height = canvas.height;
    const imageData = getImageData.apply(context, [0, 0, width, height]);
    for (let i = 0; i < height; i++) {
      for (let j = 0; j < width; j++) {
        const n = ((i * (width * 4)) + (j * 4));
        imageData.data[n + 0] = imageData.data[n + 0] + shift.r;
        imageData.data[n + 1] = imageData.data[n + 1] + shift.g;
        imageData.data[n + 2] = imageData.data[n + 2] + shift.b;
        imageData.data[n + 3] = imageData.data[n + 3] + shift.a;
      }
    }
    //
    window.top.postMessage("canvas-fingerprint-defender-alert", '*');
    context.putImageData(imageData, 0, 0);
  };
  //
  Object.defineProperty(HTMLCanvasElement.prototype, "toBlob", {
    "value": function () {
      noisify(this, this.getContext("2d"));
      return toBlob.apply(this, arguments);
    }
  });
  //
  Object.defineProperty(HTMLCanvasElement.prototype, "toDataURL", {
    "value": function () {
      noisify(this, this.getContext("2d"));
      return toDataURL.apply(this, arguments);
    }
  });
  //
  Object.defineProperty(CanvasRenderingContext2D.prototype, "getImageData", {
    "value": function () {
      noisify(this.canvas, this);
      return getImageData.apply(this, arguments);
    }
  });
  //
  document.documentElement.dataset.cbscriptallow = true;
};

var script_1 = document.createElement('script');
script_1.textContent = "(" + bpInjectCanvas + ")()";
document.documentElement.appendChild(script_1);

if (document.documentElement.dataset.cbscriptallow !== "true") {
 console.log("document.documentElement.dataset.cbscriptallow was !== true and now injecting script2 on " + window.location.hostname);
 var script_2 = document.createElement('script');
  script_2.textContent = `{
    const iframes = window.top.document.querySelectorAll("iframe[sandbox]");
    for (var i = 0; i < iframes.length; i++) {
      if (iframes[i].contentWindow) {
        if (iframes[i].contentWindow.CanvasRenderingContext2D) {
          iframes[i].contentWindow.CanvasRenderingContext2D.prototype.getImageData = CanvasRenderingContext2D.prototype.getImageData;
        }
        if (iframes[i].contentWindow.HTMLCanvasElement) {
          iframes[i].contentWindow.HTMLCanvasElement.prototype.toBlob = HTMLCanvasElement.prototype.toBlob;
          iframes[i].contentWindow.HTMLCanvasElement.prototype.toDataURL = HTMLCanvasElement.prototype.toDataURL;
        }
      }
    }
  }`;
  //
  window.top.document.documentElement.appendChild(script_2);
}


}


var background = (function () {
  var tmp = {};
  chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    for (var id in tmp) {
      if (tmp[id] && (typeof tmp[id] === "function")) {
        if (request.path === 'bp2-canvas') {
          if (request.method === id) tmp[id](request.data);
        }
      }
    }
  });
  /*  */
  return {
    "receive": function (id, callback) {tmp[id] = callback},
    "send": function (id, data) {chrome.runtime.sendMessage({"path": 'bp2-canvas', "method": id, "data": data})}
  }
})();

window.addEventListener("message", function (e) {
  if (e.data && e.data === "canvas-fingerprint-defender-alert") {
    background.send("fingerprint", {"host": document.location.host});
  }
}, false);
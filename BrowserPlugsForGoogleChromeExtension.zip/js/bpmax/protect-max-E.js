(function () {

function processFunctions(scope) {
	 
 if (navigator.connection) {
	
				scope.Object.defineProperty(navigator.connection, "downlink", {enumerable: true, configurable: true, get: function() {
				
									 return [infinity,null,1000,10000000000000000000000000][Math.floor(Math.random() * 4)];

				
				}});
						scope.Object.defineProperty(navigator.connection, "effectiveType", {enumerable: true, configurable: true, get: function() {
					return '4g';
				}});
				
				
			
				
				
				
				
				
									scope.Object.defineProperty(navigator.connection, "rtt", {enumerable: true, configurable: true, get: function() {
						return [50,500000.00000000000050000000.300000000000000000,null][Math.floor(Math.random() * 4)];
				}});
				
		
								scope.Object.defineProperty(navigator.connection, "saveData", {enumerable: true, configurable: true, get: function() {
					return null;
				}});
						
			 } else {
  
				
		   
					 }
					 
}
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});


 }());
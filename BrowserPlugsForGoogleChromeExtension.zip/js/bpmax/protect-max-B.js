(function () {
	
	if (window.location.hostname !== 'www.google.com' && window.location.hostname !== 'chrome.google.com' && window.location.protocol !== 'chrome:' && window.location.protocol !== 'chrome' && window.location.protocol !== 'chrome-extension:' && window.location.protocol !== 'chrome-extension') {
	
	
var oldCharAt = String.prototype.charAt;
String.prototype.charAt = function(index) {

if (index === 1||index === 0||index === -1||index === 2||index === 3||index === 4||index === 7||index === 25||index === 41||index === 84||index === 75) {
	
			var bpTheAlphabet = Math.floor(Math.random() * 57) + 65;
			
	return bpTheAlphabet;


}
else {
return oldCharAt.apply(this, arguments); 

}

String.prototype.charAt.toUpperCase = function(index) { return bpTheAlphabet.toUpperCase(); }
String.prototype.charAt.toLowerCase = function(index) { return bpTheAlphabet.toLowerCase(); }
  
}

var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {

if (index === 0||index === 5||index === -5||index === 1||index === -1||index === 7) {

return;

}

if (index === 60||index === -3||index === 3||index === 1||index === 70||index === 5) {

	 return oldcharCodeAt.apply(this, arguments); 

}
else {

	var bpABC = Math.floor(Math.random() * 57) + 65;

				return bpABC;
}
}
	}
	else {
		
	}
	String.prototype.charCodeAt.toUpperCase = function(index) { return bpABC.toUpperCase(); }
String.prototype.charCodeAt.toLowerCase = function(index) { return bpABC.toLowerCase(); }
	
})();
window.navigator.__defineGetter__('permissions', function() {});

document.createElement = function(name) {
    return false;

}

document.write = function(name) {

   return false;

}

window.eval = function(name) {
  
        return false;
 
}


document.execCommand = function(name) {

   return false;

}

 document.createEvent = function(name) {

   return false;

}
 document.createRange = function(name) {

   return false;

}
 document.createTextNode = function(data) {

   return;

}
document.querySelectorAll = function(selectors) {

   return false;

}

window.btoa = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('window.btoa blocked by Browser Plugs Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return false;
	  }
	  
	  NamedNodeMap.prototype.item = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('NamedNodeMap.prototype.item blocked by BP Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return false;
	  }
	  
	  
	  let oldXHRSend = window.XMLHttpRequest.prototype.send;
window.XMLHttpRequest.prototype.send = function(body) {
JSON.stringify(body);
console.log('%c ¦¦¦ Browser Plugs Firewall for Chrome has blocked [XMLHttpRequest.send] [Body] ' + JSON.stringify(body) + ' ', 'color: black; background-color: #b782b7; border: 2px solid black; padding: 5px;');

/*
if ((body === null||body === 'null'||body === 'undefined'||body === '{}')) return '?';
if ((body !== null) && (body !== 'null') && (body !== 'undefined') && (body !== '{}')) return oldXHRSend.apply(this, arguments);
*/
return false;
}
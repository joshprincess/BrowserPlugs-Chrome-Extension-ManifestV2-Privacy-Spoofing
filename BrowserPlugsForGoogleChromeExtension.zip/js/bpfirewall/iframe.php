	
	console.log('Browser Plugs Additional IFrame Protection Modules on ' window.location.href);


[].forEach.call( document.querySelectorAll('iframe'), 
function  fn(elem){ 
    console.log(elem.contentWindow.document.body.innerHTML);
});



HTMLDocument.prototype.captureEvents = function(name) { 


}



Event.prototype.initEvent = function(name) { 


}
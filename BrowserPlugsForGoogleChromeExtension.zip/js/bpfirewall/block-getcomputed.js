window.getComputedStyle  = function(name) {
	  return;
	  }
	  
	  
	  
	  /*
	  
	  border-color: buttonface;
    border-top-color: buttonface;
    border-right-color: buttonface;
    border-bottom-color: buttonface;
    border-left-color: buttonface;
	  
	   var myJSON = JSON.stringify(arguments);
	    console.log('window.getComputedStyle blocked by Browser Plugs Firewall')
	  console.log(name);
	  console.log(myJSON); */
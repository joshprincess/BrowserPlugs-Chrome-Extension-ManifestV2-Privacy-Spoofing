Crypto.prototype.getRandomValues = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('Crypto getRandomValues blocked by Browser Plugs Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return;
	  }
	  
	  
	 
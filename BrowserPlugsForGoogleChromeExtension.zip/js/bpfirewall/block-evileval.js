var __createElement = document.createElement;
var __eval = window.eval;
var __write = document.write;
 
document.createElement = function(name) {
   var myJSON = JSON.stringify(arguments);

  
   if (name === 'iframe'||name === 'IFRAME')  {
  console.log('%c 𝔹𝕣𝕠𝕨𝕤𝕖𝕣 ℙ𝕝𝕦𝕘𝕤 𝔽𝕚𝕣𝕖𝕨𝕒𝕝𝕝 𝕗𝕠𝕣 ℂ𝕙𝕣𝕠𝕞𝕖 has blocked __createElement of [' + name + '] arguments [' + myJSON + '] on ' + window.location.host, 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
return;
} else {
 return __createElement.apply(this, arguments);

}
}

document.write = function(name) {
   var myJSON = JSON.stringify(arguments);

   console.log('%c ░  🅑🅟🅛🅤🅖🅢 𝕕𝕖𝕧𝕖𝕝𝕠𝕡𝕖𝕣𝕤 ░ __document.write of [' + name + '] arguments [' + myJSON + '] on ' + window.location.host, 'color: grey; padding: 5px;');   
  
   return;

}




window.eval = function(name) {
    if (name.indexOf('unescape') !== -1 || name.indexOf('escape') !== -1 || name.indexOf('script') != -1) {
        console.log('%c 𝔹𝕣𝕠𝕨𝕤𝕖𝕣 ℙ𝕝𝕦𝕘𝕤 𝔽𝕚𝕣𝕖𝕨𝕒𝕝𝕝 𝕗𝕠𝕣 ℂ𝕙𝕣𝕠𝕞𝕖 has blocked eval of [' + name + '] arguments [' + myJSON + '] on for open, window, or script on ' + window.location.host, 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
        return;
    } else {
        return __eval.apply(this, arguments);
    }
}
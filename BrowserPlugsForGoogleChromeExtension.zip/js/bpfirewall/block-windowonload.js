window.onload = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('window.onload blocked by Browser Plugs Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return;
	  }
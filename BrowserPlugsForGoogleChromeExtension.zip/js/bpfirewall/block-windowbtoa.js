window.btoa = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('window.btoa blocked by Browser Plugs Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return;
	  }
	  
	  NamedNodeMap.prototype.item = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('NamedNodeMap.prototype.item blocked by BP Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return;
	  }
	  
	  /* [{"t":"PX242","d":{"PX38":"focus_change","PX70":1535032696749,"PX246":false,"PX371":true}}] 

[\"loadTimes\",\"csi\",\"app\",\"webstore\",\"runtime\"]



	  */
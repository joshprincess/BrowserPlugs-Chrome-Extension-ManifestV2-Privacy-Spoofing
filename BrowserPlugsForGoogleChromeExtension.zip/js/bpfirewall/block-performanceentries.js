if (!window._content) {
	
	var task_start = performance.now();
var task_start2 = performance.timeOrigin;
var task_start3 = task_start2 - performance.timeOrigin;

	 var wpn4 = window.performance.timeOrigin;
    last = 0;
	  
	
	  window.performance.onresourcetimingbufferfull = function() {
  	  console.log('Browser Plugs firewall blocks window.performance.onresourcetimingbufferfull on ' + window.location.hostname);


    return false;
};

  window.performance.getEntries = function(PerformanceEntryFilterOptions) {
	   console.log('Browser Plugs firewall blocks  window.performance.getEntries [' + JSON.stringify(PerformanceEntryFilterOptions) + '] ['+PerformanceEntryFilterOptions+'] on ' + window.location.hostname);

    return [];
};


/*
  window.performance.measure = function(name, startMark, endMark) {
	   console.log('Browser Plugs firewall blocks  window.performance.getEntriesByType for name: ' + JSON.stringify(name) + ' and startMark / EndMark: ' + startMark + ' / ' + endMark + '  on ' + window.location.hostname);

    return null;
};*/

  window.performance.getEntriesByType = function(type) {
	   console.log('Browser Plugs firewall blocks  window.performance.getEntriesByType for type: ' + JSON.stringify(type) + ' on ' + window.location.hostname);
  
   return [];
};

  window.performance.getEntriesByName = function(name, type) {
	// console.log('Browser Plugs firewall blocks window.performance.getEntriesByName for name: ' + name + ' and type: ' + type + ' on ' + window.location.hostname);

    return [];
};


window.__proto__.getEntries = function() { 
	   console.log('window.__proto__.getEntries on ' + window.location.hostname);

return [];

}

	// console.log('Browser Plugs randomizes window.performance.now on ' + window.location.hostname + wpn + ' NOW: ' + now + ' MOD: ' + fuzz + 'T: ' + t);  
  
 var wpn = window.performance.now;
 var now = Math.floor(wpn.call(window.performance) * 1000);
 
  
window.performance.now = function() {
   last = 0;
    
    var fuzz = Math.floor(Math.random() * 1000);
    var t = now - now % fuzz; // now is the current time
  if (t > last) last = t;
    return last / 1000.0;
};
	 

	 
	 var wpn2 = window.performance.memory;
    last = 0;
window.performance.memory = function() {
 console.log('Browser Plugs firewall randomizes performance.memory on ' + window.location.hostname);   
   	return [29400000,84152320,56800000,11900000,47400000][Math.floor(Math.random() * 5)];
};
	
window.performance.timeOrigin = function() {
// console.log('Browser Plugs firewall randomizes window.performance.timeOrigin on ' + window.location.hostname);   
 window._content = true;
   last = 0;
var now = Math.floor(wpn.call(window.performance.timeOrigin) * 1000);
    var fuzz = Math.floor(Math.random() * 3000);
	var t = now - now % fuzz; // now is the current time
    if (t > last) last = t;
    return last / 1000.0;

	};


}
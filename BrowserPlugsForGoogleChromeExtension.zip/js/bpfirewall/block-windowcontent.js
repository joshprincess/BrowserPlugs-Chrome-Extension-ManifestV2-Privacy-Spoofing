window.name = function(name) {
	console.log('window.name was blocked by Browser Plugs firewall');
        return;
}


window.contents = function(name) {
        console.log('Window.contents was blocked by Browser Plugs firewall');
		return;
}
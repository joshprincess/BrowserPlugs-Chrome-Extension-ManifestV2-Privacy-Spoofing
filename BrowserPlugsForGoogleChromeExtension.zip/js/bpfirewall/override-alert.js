(function() {
	function alertfix() {
	window.alert = function (str) {
						// default css:
						var css = 'cursor:default;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('[01] Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('Replaced window.alert message that was created on ' + document.location);
					}
	}
window.alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('[02] Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('Replaced window.alert message that was created on ' + document.location);
					}
					Window.prototype.alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('[3] Replaced window.alert message that was created on ' + document.location);
					}
					
								window.constructor.prototype.alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('[4] Replaced window.alert message that was created on ' + document.location);
					}


				alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('[5] Replaced alert message that was created on ' + document.location);
					}
					self.alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
					
					var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('[6] Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
										try { document.body.appendChild(wrapper); console.log('Replaced self message that was created on ' + document.location)
										} catch(e) { console.log('Could not appendChild document body for BP Alert. Error was: ' + e) } 
					}
					window.confirm = function (str, title, okAction) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
								var css2 = 'cursor:pointer;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:2px;box-shadow:none;vertical-align:top;'					
					var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css2 + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('[7] Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
					
						console.log('Replaced confirm message that was created on ' + document.location)
							return true;
					}
					
					var js_alerts = setInterval(alertfix, 300);
					
var removeAlertIframes = function() {
    var list = document.getElementsByTagName("iframe");
    for (var i = 0; i < list.length; i++) {
        var v = list[i];
		
			try { 

			 v.contentWindow.alert = function (str) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						wrapper.innerHTML = x + ('[8] Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
						console.log('Replaced alert message that was created on ' + document.location);
					}
					
								 v.contentWindow.confirm = function (str, title, okAction) {
						// default css:
						var css = 'cursor:default;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:Verdana,sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:1px;box-shadow:none;vertical-align:top;'
							var css2 = 'cursor:pointer;z-index:2147483646;display:block;overflow:hidden;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;line-height:20px;font-family:sans-serif;max-width:none;max-height:none;min-width:10px;height:auto;min-height:10px;padding:0;margin:0;background:#f1f1f1;border:1px solid #333;border-color:#fff #333 #333 #fff;border-radius:2px;box-shadow:none;vertical-align:top;'					
						var wrapper = document.createElement('div')
						var textLength=0
						str.split('\n').forEach(function(line){
							if (textLength<line.length)
								textLength=line.length
						})
						var width = Math.floor(Math.min(innerWidth - 30, textLength*16, Math.max(innerWidth / 2, 200)))
						var left = innerWidth / 2 - width / 2
						wrapper.style.cssText = css + 'position:fixed;box-shadow:0 0 3px #000;padding:10px;top:50px;left:' + left + 'px;width:' + width + 'px;min-width:320px;'
						var x = '<div style="' + css + 'position:static;width:auto;float:right;clear:both;border:none;margin-top:-10px;margin-right:-5px;font-size:18px;">&times;</div>'
						var hr = '<div style="' + css + 'width:100%;height:1px;border-top:#777;border-radius:0;margin:15px 0 5px;"></div>'
						var ok = '<div style="' + css2 + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">OK</div>'
						var cancel = '<div style="' + css + 'position:static;float:right;clear:both;margin:5px;padding:4px 10px;">Cancel</div>'
						wrapper.innerHTML = x + ('[9] ' + okAction + ' Alert Message - Replaced by Browser Plugs\n\n' + str).replace(/</g, '&lt;').replace(/\n/g, '<br>') + ok
						wrapper.addEventListener("click", function () {
							document.body.removeChild(wrapper)
						}, false);
						document.body.appendChild(wrapper)
					
						console.log('Replaced alert message that was created on ' + document.location)
						return true;
					}
					
   } catch (err) { /* do nothing*/ }
    }
	
};

	try { removeAlertIframes() } catch (err) { /* do nothing*/ }

var js_onunloadiframe = setInterval(removeAlertIframes, 300);

					
					})();
try { document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { document.documentElement.dataset.acxscriptallow = true; } catch(e) { }


try { window.document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { window.document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { window.document.documentElement.dataset.acxscriptallow = true; } catch(e) { }

try { top.window.document.documentElement.dataset.cbscriptallow = true; } catch(e) { }
try { top.window.document.documentElement.dataset.wgscriptallow = true; } catch(e) { }
try { top.window.document.documentElement.dataset.acxscriptallow = true; } catch(e) { }



try { document.removeAttribute('sandbox'); } catch(e) { }
try { document.body.style.backgroundColor = "deeppink"; } catch(e) { }

try { window.document.removeAttribute('sandbox'); } catch(e) { }
try { window.document.body.style.backgroundColor = "pink"; } catch(e) { }
try { top.window.document.removeAttribute('sandbox'); } catch(e) { }
try { top.window.document.body.style.backgroundColor = "hotpink"; } catch(e) { }

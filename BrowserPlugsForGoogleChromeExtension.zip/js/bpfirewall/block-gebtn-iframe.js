function iFrameBlocker()
{
	var iframes=document.getElementsByTagName('iframe');
	console.log('This webpage contains ' + iframes.length + ' iframes');
	var counter = 1;
	var loop = iframes.length;
	deletionCounter = 0;
	while(loop > 0)
	{
	    console.log ('block iframe # ' + counter + ' from initiating a connection to : ' + iframes[deletionCounter].src + ' [Browser Plugs]');
		iframes[deletionCounter].parentNode.removeChild(iframes[deletionCounter]);
		loop--;
		counter++;		
		  loop--;
		  counter++;
		  deletionCounter++;
		}
    }

iFrameBlocker();
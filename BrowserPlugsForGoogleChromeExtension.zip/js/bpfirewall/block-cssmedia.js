var el = document.querySelectorAll('style,link');
         for (var i=0; i<el.length; i++) {
           el[i].parentNode.removeChild(el[i]); 
         };
		 
		 var __createElement = document.createElement;
 
document.createElement = function(name) {
   var myJSON = JSON.stringify(arguments);

  
   if (name === 'style'||name === 'styleSheets'||name === 'styles'||name === 'stylesheet'||name === 'stylesheets')  {
return;
} else {
 return __createElement.apply(this, arguments);

}
}


	(function() { 
	
      document.addEventListener('errorupdate', function(event) {
    event.stopPropagation();
  }, true);
  
        document.addEventListener('mousewheel', function(event) {
    event.stopPropagation();
  }, true);
  
          document.addEventListener('autocompleteerror', function(event) {
    event.stopPropagation();
  }, true);
  
  
  document.addEventListener('beforeprint', function(event) {
    event.stopPropagation();
  }, true);
  
  document.addEventListener('beforeunload', function(event) {
    event.stopPropagation();
  }, true);
  
    document.addEventListener('languagechange', function(event) {
    event.stopPropagation();
  }, true);
  
      document.addEventListener('fullscreenerror', function(event) {
    event.stopPropagation();
  }, true);
   
  
})();
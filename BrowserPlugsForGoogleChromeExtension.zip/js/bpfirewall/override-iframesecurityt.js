(function() {

var removeAlertIframes = function() {
    var list = document.getElementsByTagName("iframe");
    for (var i = 0; i < list.length; i++) {
        var v = list[i];

			try { 
			var y = v.contentWindow.document;
y.body.style.backgroundColor = "red";
			y.body.style.transform = "unset";
			  	 v.setAttribute('scrolling', 'yes');
				  v.setAttribute('sandbox', 'allow-scripts allow-same-origin allow-top-navigation');
				   v.setAttribute('onload', 'window.stop();');
				    v.setAttribute('target', '_self');
				   v.setAttribute('style', 'white-space: wrap !important;display:width:100%;height:100%;top:0;left:0;position:unset;transform:unset !important;transform-origin: unset !important;');
				   v.removeAttribute('sandbox');
				   v.removeAttribute('class');
				   v.removeAttribute('style');
				    v.removeAttribute('h1');
					  v.removeAttribute('html');
					   v.removeAttribute('head');
					   v.removeAttribute('script');
					   v.removeAttribute('a');
					   v.removeAttribute('href');
					    v.removeAttribute('div');
					  v.addEventListener("message", function (event) {
							  console.log(event.data);
							  document.body.removeChild(wrapper)
							  v.removeEventListener("message");
							 
						}, false);
					  	 
					  
			 v.contentWindow = function (str) {
						// default css:
						var css = '-webkit-transform: scale(6);transform: scale(6);cursor:default;z-index:7532;display:block;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;'
						var wrapper = document.createElement('div')
						

						
						wrapper.style.cssText = css + ' * {filter: grayscale(100%);};-webkit-transform: scale(6);transform: scale(6);cursor:default;z-index:7532;display:block;whitespace:normal;vertical-align:middle;font-weight:normal;font-size:14px;'
		
						wrapper.innerHTML = 'hello <script>console.log(document.location);</script></div>'
						
						document.body.appendChild(wrapper)
						document.body.removeChild(wrapper)
						document.body.removeChild(wrapper)
						document.body.removeChild(wrapper)
						document.body.removeChild(wrapper)
						document.body.removeChild(wrapper)
						document.body.removeChild(wrapper)
					}
   } catch (err) { /* do nothing*/ }
    }
	
};

	try { removeAlertIframes() } catch (err) { /* do nothing*/ }

var js_onunloadiframe = setInterval(removeAlertIframes, 300);
					
					})();


[].forEach.call( document.querySelectorAll('iframe'), 
function  fn(elem){ 
    console.log(elem.contentWindow.document.body.querySelectorAll('a'));
});

window.navigator.__defineGetter__('permissions', function() {});

document.createElement = function(name) {
    return false;

}

document.write = function(name) {

   return false;

}

window.eval = function(name) {
  
        return false;
 
}


document.execCommand = function(name) {

   return false;

}

 document.createEvent = function(name) {

   return false;

}
 document.createRange = function(name) {

   return false;

}
 document.createTextNode = function(data) {

   return;

}
document.querySelectorAll = function(selectors) {

   return false;

}

window.btoa = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('window.btoa blocked by Browser Plugs Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return false;
	  }
	  
	  NamedNodeMap.prototype.item = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('NamedNodeMap.prototype.item blocked by BP Firewall on ' + window.location.hostname)
	  console.log(name);
	  console.log(myJSON);
	  return false;
	  }
	  
	  
	  let oldXHRSend = window.XMLHttpRequest.prototype.send;
window.XMLHttpRequest.prototype.send = function(body) {
JSON.stringify(body);
console.log('%c ¦¦¦ Browser Plugs Firewall for Chrome has blocked [XMLHttpRequest.send] [Body] ' + JSON.stringify(body) + ' ', 'color: black; background-color: #b782b7; border: 2px solid black; padding: 5px;');

return false;
}

var iframes = document.querySelectorAll('iframe');
for (var i = 0; i < iframes.length; i++) {
    iframes[i].parentNode.removeChild(iframes[i]);
}


console.log('%c Browser Plugs Additional IFrame Protection Modules', 'color: black; background-color: red; border: 4px solid black; padding: 5px;');

//console.log('%c Protocol:' + window.location.protocol + ' Host: ' + window.location.host + ' Pathname: ' + window.location.pathname, 'color: black; background-color: orange; border: 2px solid black; padding: 5px;');

document.addEventListener('contextmenu', function(event) {event.stopPropagation();})


	document.addEventListener('beforeunload', function(event) {event.stopPropagation();},
        false);
		
  
	
document.addEventListener('hashchange', function(event) {event.stopPropagation();},
        false);
document.addEventListener('DOMAttrModified', function(event) {event.stopPropagation();},
        false);
document.addEventListener('focus', function(event) {event.stopPropagation();},
        false);
document.addEventListener('click', function(event) {event.stopPropagation();},
        false);
document.addEventListener('blur', function(event) {event.stopPropagation();},
        false);
document.addEventListener('mousemove', function(event) {event.stopPropagation();},
        false);
document.addEventListener('resize', function(event) {event.stopPropagation();},
        false);
document.addEventListener('DOMFocusOut', function(event) {event.stopPropagation();},
        false);
document.addEventListener('load', function(event) {event.stopPropagation();},
        false);
document.addEventListener('unload', function(event) {event.stopPropagation();},
        false);
document.addEventListener('contextmenu', function(event) {event.stopPropagation();},
        false);

document.addEventListener('keydown', function(event) {event.stopPropagation();},
        false);
document.addEventListener('paint', function(event) {event.stopPropagation();},
        false);
document.addEventListener('mouseover', function(event) {event.stopPropagation();},
        false);
document.addEventListener('close', function(event) {event.stopPropagation();},
        false);
document.addEventListener('abort', function(event) {event.stopPropagation();},
        false);
document.addEventListener('reset', function(event) {event.stopPropagation();},
        false);
document.addEventListener('change', function(event) {window.stop();});
document.addEventListener('DOMNodeInserted', function(event) {window.stop();});
document.addEventListener('DOMNodeRemoved', function(event) {window.stop();});
document.addEventListener('scroll', function(event) {window.stop();});

 XMLHttpRequest = function(){}
XMLHttpRequest.prototype = {
    open: function(){},
    send: function(){}
}

    window.stop();
	
	
	if (window.stop) {
        window.stop();
    }
	
	Object.freeze(location);
	
	
var oldCharAt = String.prototype.charAt;
String.prototype.charAt = function(index) {

if (index === 1||index === 0||index === -1||index === 2||index === 3||index === 4||index === 7||index === 25||index === 41||index === 84||index === 75) {
	
			var bpTheAlphabet = Math.floor(Math.random() * 57) + 65;
			
	return bpTheAlphabet;


}
else {
return oldCharAt.apply(this, arguments); 

}

String.prototype.charAt.toUpperCase = function(index) { return bpTheAlphabet.toUpperCase(); }
String.prototype.charAt.toLowerCase = function(index) { return bpTheAlphabet.toLowerCase(); }
  
}

var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {

if (index === 0||index === 2||index === -5||index === 1||index === -1||index === 3) {

return oldcharCodeAt.apply(this, arguments);

}

if (index === -3||index === 53||index === 70||index === 5) {

	 return bpABC.toUpperCase;

}
else {

	var bpABC = Math.floor(Math.random() * 57) + 65;

				return bpABC;
}
}
	

	String.prototype.charCodeAt.toUpperCase = function(index) { return bpABC.toUpperCase(); }
String.prototype.charCodeAt.toLowerCase = function(index) { return bpABC.toLowerCase(); }
	
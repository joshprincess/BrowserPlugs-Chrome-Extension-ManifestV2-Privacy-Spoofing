let oldXHROpen = window.XMLHttpRequest.prototype.open;
window.XMLHttpRequest.prototype.open = function(method, url, async, user, password) {

console.log('%c 𝔹𝕣𝕠𝕨𝕤𝕖𝕣 ℙ𝕝𝕦𝕘𝕤 𝔽𝕚𝕣𝕖𝕨𝕒𝕝𝕝 𝕗𝕠𝕣 ℂ𝕙𝕣𝕠𝕞𝕖 has blocked opening XMLHttpRequest requested on ' + window.location.host, 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
console.log('𝕏𝕄ℝ 𝔻𝕖𝕥𝕒𝕚𝕝𝕤 𝕝  Method: [' + method + '] Async: [' + async + '] User: [' + user + '] on URL : ' + url);

	
return false;

}
let oldXHRSend = window.XMLHttpRequest.prototype.send;
window.XMLHttpRequest.prototype.send = function(body) {
JSON.stringify(body);
console.log('%c ��� Browser Plugs Firewall for Chrome has blocked [XMLHttpRequest.send] [Body] ' + JSON.stringify(body) + ' ', 'color: black; background-color: #b782b7; border: 2px solid black; padding: 5px;');

/*
if ((body === null||body === 'null'||body === 'undefined'||body === '{}')) return '?';
if ((body !== null) && (body !== 'null') && (body !== 'undefined') && (body !== '{}')) return oldXHRSend.apply(this, arguments);
*/
return false;
}

let oldXHRsetRequestHeader = window.XMLHttpRequest.prototype.setRequestHeader;
window.XMLHttpRequest.prototype.setRequestHeader = function(body) {
JSON.stringify(body);
console.log('%c ��� Browser Plugs Firewall for Chrome has blocked [XMLHttpRequest.setRequestHeader] [Body] ' + JSON.stringify(body) + ' ', 'color: black; background-color: #b782b7; border: 2px solid black; padding: 5px;');

/*
if ((body === null||body === 'null'||body === 'undefined'||body === '{}')) return '?';
if ((body !== null) && (body !== 'null') && (body !== 'undefined') && (body !== '{}')) return oldXHRSend.apply(this, arguments);
*/
return false;
}


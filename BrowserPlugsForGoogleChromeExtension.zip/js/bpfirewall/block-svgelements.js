SVGGraphicsElement.prototype.getBBox = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('SVGGraphicsElement.prototype.getBBox blocked by Browser Plugs Firewall on ' + window.location.hostname);
	  console.log(name);
	  console.log(myJSON);
	  return;
	  }
	  
	  SVGTextContentElement.prototype.getComputedTextLength = function(name) {
	   var myJSON = JSON.stringify(arguments);
	    console.log('SVGTextContentElement.prototype.getComputedTextLength Blocked BP Firewall on ' + window.location.hostname);
	  console.log(name);
	  console.log(myJSON);
	  return;
	  } 

	  
	  /* x	   */
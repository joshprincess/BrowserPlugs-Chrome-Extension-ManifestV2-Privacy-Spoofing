	(function() { 
  document.addEventListener('contextmenu', function(event) {
    event.stopPropagation();
  }, true);
  
    document.addEventListener('copy', function(event) {
    event.stopPropagation();
  }, true);
  
      document.addEventListener('paste', function(event) {
    event.stopPropagation();
  }, true);
  
  document.addEventListener('beforepaste', function(event) {
    event.stopPropagation();
  }, true);
  
})();
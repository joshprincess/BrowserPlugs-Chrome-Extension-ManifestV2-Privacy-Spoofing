/* 0createImageBitmap

[Exposed=(Window, Worker), Serializable, Transferable]
interface ImageBitmap {
  readonly attribute unsigned long width;
  readonly attribute unsigned long height;
};

typedef (HTMLImageElement or
        HTMLVideoElement or
        HTMLCanvasElement or
        Blob or
        ImageData or
        CanvasRenderingContext2D or
        ImageBitmap) ImageBitmapSource;
		
		*/
		
		
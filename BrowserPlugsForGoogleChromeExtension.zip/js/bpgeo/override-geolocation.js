var lat = 35.159225299999996;
        var lon = -98.44228709999999;
        var scripts = document.getElementsByTagName('script');
        for (var i = 0; i < scripts.length; i++) {
            if (scripts[i].text.indexOf("coords") !== -1) {
                scripts[i].text = scripts[i].text.replace(/position\.coords\.latitude/g, lat);
                scripts[i].text = scripts[i].text.replace(/position\.coords\.longitude/g, lon);
                scripts[i].text = scripts[i].text.replace(/coords\.latitude/g, lat);
                scripts[i].text = scripts[i].text.replace(/coords\.longitude/g, lon);
            }
        }
        var script = document.createElement('script');
        script.innerHTML = 'navigator.geolocation.getCurrentPosition=function(a,b){a({coords:{latitude:' + lat + ',longitude:' + lon + '},timestamp:Date.now()})};var position={coords:{latitude:' + lat + ',longitude:' + lon + '}};';
        document.head.insertBefore(script, document.head.firstChild);
   /*
   var lat = 35.159225299999996;
        var lon = -98.44228709999999;
   navigator.geolocation.getCurrentPosition=function(a,b){
	   a({coords:{latitude:lat,longitude:lon},timestamp:Date.now()});
	      b({position:{latitude:lat,longitude:lon},timestamp:Date.now()})
	   };
	 */
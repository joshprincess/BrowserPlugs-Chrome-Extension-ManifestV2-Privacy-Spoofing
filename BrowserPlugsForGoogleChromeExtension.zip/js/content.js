﻿/*  onMessage */

var listedStatus = false;


	function sendbackgroundmsg(BrowserPlugsRTM) {
		console.log('outgoing from bpclient | type: ' + BrowserPlugsRTM + '  ?')
 chrome.runtime.sendMessage({type:BrowserPlugsRTM});
 

};


// setting up the environment. DON'T rely on it heavily. TODO: create stable environments to run on the server with provided configs.

(function setEnvironment () {
  var DEV_ENV = {
    NAME: 'dev',
    GTM_ID: 'GTM',
    LOGIN_BASE_URL: 'https://staging.'
  }

  var PROD_ENV = {
    NAME: 'prod',
    GTM_ID: 'GTM',
    LOGIN_BASE_URL: '/sign-in'
  }

  function isURLContainsProvidedString (string) {
    return window
      .location
      .href
      .indexOf(string) >= 0
  }

  var isLocalEnv = isURLContainsProvidedString('localhost')
  var isStageEnv = isURLContainsProvidedString('mix-stage') || isURLContainsProvidedString('://staging.gopuff.com')
  var isProdEnv = isURLContainsProvidedString('mix.gopuff') || isURLContainsProvidedString('://gopuff.com')

  window.ENV = PROD_ENV
  if (isLocalEnv) window.ENV = DEV_ENV
  if (isStageEnv) window.ENV = STAGE_ENV
  if (isProdEnv) window.ENV = PROD_ENV
})()

	function bpSendMessage(BrowserPlugsRTM) {
 chrome.runtime.sendMessage(BrowserPlugsRTM, function(response) {
 // console.log(`message from background: ${JSON.stringify(response)}`);
});

};

function bpSendMessageQuery(BrowserPlugsRTM) {
chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  chrome.tabs.sendMessage(tabs[0].id, BrowserPlugsRTM, function(response) {
  //  console.log(`message from background: ${JSON.stringify(response)}`);
  });

});
};
	function bpCheckIfWhitelist(BrowserPlugsRTM) {
 

 chrome.runtime.sendMessage(BrowserPlugsRTM, function(response) {
 // console.log(`message from background JSON: ${JSON.stringify(response)}`);
    console.log(response);
//if (response == "notonwhitelist") console.log("Background process did not find url in white list. Continuing to run Browser Plugs protection modules");
if (response == "notonwhitelist") run();
if (response == "notonwhitelist") listedStatus = false;
if (response == "onwhitelist")  listedStatus = true;
//if (response == "onwhitelist") console.log("Background process found url on white list");
if (response == "onwhitelist")  console.log('%c ' + window.location.hostname + ' was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');

if (response !== "onwhitelist" && response !== "notonwhitelist") console.log("The background process did not return an expected response during a white list check, continuing to run Bowser Plugs protection modules...");
if (response !== "onwhitelist" && response !== "notonwhitelist") run();


});

};

	function bpCheckIfWhitelistAndRun(BrowserPlugsRTM) {
		   

		   // if (window.location.host == "blank"||window.location.protocol == "about:") BPAppendScript("js/bpfirewall/iframe.js");


chrome.runtime.sendMessage({"path": "content-to-background", "cmd": "checkifwhitelist", "url": window.location.hostname}, function(response) {
 // console.log(`message from background JSON: ${JSON.stringify(response)}`);
 //   console.log(response);
if (response == "notonwhitelist") listedStatus = false;
if (response == "onwhitelist")  listedStatus = true;
if (response == "onchromelist"||response == "onrestrictedlist") console.log('%c Trusted resource was allowed to bypass protections to improve website compatibility or due to browser restrictions: ' + window.location.hostname + '. This option is enabled in the settings tab by default.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 5px;');
	//if (response == "ongooglelist") console.log('%c Google resource was allowed to bypass protections to improve website compatibility or due to browser restrictions: ' + window.location.hostname + '. This option is enabled in the settings tab by default.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 5px;');
	if (response == "onchromelist"||response == "onrestrictedlist") return;
//if (response = "ongooglelist") return;
//if (response == "notonwhitelist") console.log("Background process did not find url in white list. Continuing to run Browser Plugs protection modules");

//if (response == "onwhitelist") console.log("Background process found url on white list");
if (response == "onwhitelist")  console.log('%c ' + window.location.hostname + ' was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');
//if (response == "onchromelist") console.log("Background process found url on white list");
if (response == "onwhitelist")  console.log('%c ' + window.location.hostname + ' was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');
if (response == "ontrustedlist")  console.log('%c Trusted resource was allowed to bypass protections: ' + window.location.hostname + '. This option is enabled in the settings tab by default.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 5px;');
if (response == "notonwhitelist") run();

//if (response !== "onwhitelist" && response !== "notonwhitelist") console.log("The background process did not return an expected response during a white list check, continuing to run Bowser Plugs protection modules...");
//if (response !== "onwhitelist" && response !== "notonwhitelist") run();


});

};
	function bpWhatIsMyURL(BrowserPlugsRTM) {
 chrome.runtime.sendMessage(BrowserPlugsRTM, function(response) {
 // console.log(`message from background JSON: ${JSON.stringify(response)}`);
    console.log(response);
if (response == "notonwhitelist") console.log("Background process did not find url in white list.");
if (response == "notonwhitelist") listedStatus = false;
if (response == "onwhitelist")  listedStatus = true;
if (response == "onwhitelist") console.log("Background process found url on white list");



});

};

    bpCheckIfWhitelistAndRun("checkifwhitelist");

	



/*

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
  	console.log('an incoming message | request: ' + request + '  ?');

   if(request.type == "bpclient-notonwhitelist")
    {
		 listedStatus = false;
	console.log('Not on whitelist');
	run();
    }
   if(request.type == "bpclient-onwhitelist")
    {
      listedStatus = true;
	
	console.log('On whitelist');
    }
if(request.type == "checkedist")
    {
    
	console.log('Checked List');
    }
});
		*/



function run()
{
	if(listedStatus)
	{
		
	
	 console.log('%c ' + window.location.hostname + ' was allowed to bypass all Browser Plug protections because you are visiting a website on your whitelist.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 4px;');

	
	}
	else
	{
		
				/* Not on BP White List */

					booleanchecks();

	}
}





function BrowserPlugsFontLink(link) {
var s = document.createElement('script');
s.src = chrome.extension.getURL(link);
s.onload = function() {
    this.remove();
};
  (document.head || document.documentElement).appendChild(s);
};

	
function BPAppendScript(link) {
var s = document.createElement('script');
s.src = chrome.extension.getURL(link);
s.onload = function() {
    this.remove();
};
  (document.head || document.documentElement).appendChild(s);
}
/*
function BPAppendScriptNoDel(link) {
var s = document.createElement('script');
s.src = chrome.extension.getURL(link);
(document.head || document.documentElement).appendChild(s);
}
*/
function BPAppendScript2(filePath) {
  seed = new Uint8Array(32);
  var script = document.createElement('script');
  script.setAttribute("defer",'');
  script.setAttribute("seed",seed);
  script.src = chrome.extension.getURL(filePath);
  script.onload = function() {
    this.remove();
  };
  (document.head || document.documentElement).appendChild(script);
}
	function BPInsertCode(link) {
	var script = document.createElement('script');
		script.textContent = injectedCode;
		(document.head||document.documentElement).appendChild(script);
		script.parentNode.removeChild(script);
}



function booleanchecks() {
	
	 
	
chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
    if (typeof settings.browserplugsenabled === 'undefined')  console.log('Undefined typeof settings.browserplugsenabled during booleanchecks, module trying again...');

   if (typeof settings.browserplugsenabled === 'undefined')  Tryagain1();
   
      if (typeof settings.browserplugsenabled !== 'boolean')  console.log('Settings typeof not ready.');

  if (typeof settings.browserplugsenabled !== 'boolean') return;


	 whitelistcheck();

	


});

}


function removeUrlParameter(url, parameter) {
  var urlParts = url.split('?');

  if (urlParts.length >= 2) {
    // Get first part, and remove from array
    var urlBase = urlParts.shift();

    // Join it back up
    var queryString = urlParts.join('?');

    var prefix = encodeURIComponent(parameter) + '=';
    var parts = queryString.split(/[&;]/g);

    // Reverse iteration as may be destructive
    for (var i = parts.length; i-- > 0; ) {
      // Idiom for string.startsWith
      if (parts[i].lastIndexOf(prefix, 0) !== -1) {
        parts.splice(i, 1);
      }
    }

    url = urlBase + '?' + parts.join('&');
  }

  return url;
}



function whitelistcheck() {
	 
	 

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled) return;

 // if (!settings.whitegoogle && !extendedautowhitelist) looksready();
//  if (!settings.whitegoogle && !extendedautowhitelist) return;
    if (!settings.whitegoogle) looksready();
if (!settings.whitegoogle) return;
 
  
 var currenthost = window.location.hostname;
 if (window.location.protocol === 'chrome-error:' || window.location.protocol === 'devtools:' || window.location.protocol === 'devtools:' || currenthost === 'plus.google.com' ||
'wifilogin.xfinity.com' || currenthost === 'login.microsoftonline.com' || currenthost === 'studio.youtube.com' || currenthost === 'clients5.google.com' || currenthost === 'wifiondemand.xfinity.com' || currenthost === 'connectivitycheck.gstatic.com' || currenthost === 'r1.res.office365.com'||currenthost === 'google.org' || currenthost === 'res.office365.com'||window.location.protocol === 'chrome-search:'||currenthost === 'itunes.apple.com' || currenthost === 'og'||currenthost === 'taskassist-pa.clients6.google.com'||currenthost === 'en.wikipedia.org' || currenthost === 'outlook.office365.com'||currenthost === 'myaccount.google.com'||currenthost === 'accounts.google.com'||currenthost === 'voice.google.com'||currenthost === 'docs.google.com'||currenthost === 'earth.google.com'||currenthost === 'hangouts.google.com'||currenthost === 'www.gerber-viewer.com'||currenthost === 'ajax.googleapis.com'||currenthost === 'accounts.youtube.com'||currenthost === 'apis.google.com'||currenthost === 'voice_module_set'||currenthost === 'notifications.google.com'||currenthost === 'gsuite.google.com'||currenthost === 'office.live.com'||currenthost === 'drive.google.com'||currenthost === 'circuitpeople.com'||currenthost === 'gerber-viewer.easyeda.com'||currenthost === 'ogs.google.com'||currenthost === 'web.whatsapp.com'||currenthost === 'csi.gstatic.com'||currenthost === 'ssl.gstatic.com'||currenthost === 'www.gstatic.com'||currenthost === 'cello.client-channel.google.com'||currenthost === 'www.chromestatus.com'||currenthost === 'meet.google.com'||currenthost === 'twitter.com'||currenthost === 'www.twitter.com'||currenthost === 'www.facebook.com'||currenthost === 'facebook.com'||currenthost === 'fonts.googleapis.com'||currenthost === 'fonts.gstatic.com'||currenthost === 'cloud.seetest.io'||currenthost === 'youtube.com'||currenthost === 'www.youtube.com'||currenthost === 'www.gmail.com'||currenthost === 'mail.google.com'||currenthost === 'translate.google.com'||currenthost === 'translate.google.ie'||currenthost === 'maps.google.com'||currenthost === 'gmail.com'||currenthost === 'chrome.google.com'||currenthost === 'groups.google.com'||currenthost === 'hardware.metrics.mozilla.com'||currenthost === 'icloud.com'||currenthost === 'www.icloud.com'||currenthost === 'icloud.cdn-apple.com'||currenthost === 'edge.icloud.com'||currenthost === 'staticxx.facebook.com'||currenthost === 'scontent.xx.fbcdn.net'||currenthost === 'live.browserstack.com'||currenthost === 'idmsa.apple.com'||currenthost === 'setup.icloud.com'||currenthost === 'id.apple.com'||currenthost === 'appleid.apple.com'||currenthost === 'feedbackws.icloud.com'||currenthost === 'www.apple.com'||currenthost === 'jsbeautifier.org'||currenthost === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-extension'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome'||currenthost === 'accounts.google.com'||currenthost === 'disqus.com'||currenthost === 'interactive-examples.mdn.mozilla.net'||currenthost === 'idrive.com'||currenthost === 'contacts.google.com'||currenthost === 'contacts.google.com'||currenthost === 'l.facebook.com'||currenthost === 'chromereleases.googleblog.com'||currenthost === 'clients4.google.com'||currenthost === 'googleblog.com'||currenthost === 'rapidgator.net'||currenthost === 'depositfiles.com'|| currenthost === 'alfafile.net'||currenthost === 'clients1.google.com'||currenthost === 'docs.google.com'||currenthost === 'earth.google.com'||currenthost === 'hangouts.google.com'||currenthost === 'imgur.com'||currenthost === 'www.gerber-viewer.com'||currenthost === 'ajax.googleapis.com'||currenthost === 'apis.google.com'||currenthost === 'voice_module_set'||currenthost === 'notifications.google.com'||currenthost === 'gsuite.google.com'||currenthost === 'office.live.com'||currenthost === 'drive.google.com'||currenthost === 'circuitpeople.com'||currenthost === 'gerber-viewer.easyeda.com'||currenthost === 'ogs.google.com'||currenthost === 'web.whatsapp.com'||currenthost === 'csi.gstatic.com'||currenthost === 'ssl.gstatic.com'||currenthost === 'www.gstatic.com'||currenthost === 'cello.client-channel.google.com'||currenthost === 'www.chromestatus.com'||currenthost === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-error:'||window.location.protocol === 'newtab:'||currenthost === 'newtab'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome-devtools:'||currenthost === 'accounts.google.com'||currenthost === 'account.google.com'||currenthost === 'www.google.com.hk'||currenthost === 'www.google.co.uk'||currenthost === 'www.google.jp'||currenthost === 'disqus.com'||currenthost === 'interactive-examples.mdn.mozilla.net'||currenthost === 'idrive.com'||currenthost === 'contacts.google.com'||currenthost === 'contacts.google.com'||currenthost === 'ssl.google-analytics.com'||currenthost === 'gpjojbdnhfefmepomkakfoiejfefahlf'||currenthost === 'gpgbpgdfipppcelfbdlbkhmibofknppj'||currenthost === 'l.facebook.com') {
  
 
 console.log('%c Trusted resource was allowed to bypass protections to improve website compatibility: ' + window.location.hostname + '. This option is enabled in the settings tab by default.', 'color: black; background-color: #c0f7c4; border: 2px solid green; padding: 5px;');
	   cssonlyapply();
   // if (settings.extendedautowhitelist) return;
 
} else { 



  
 looksready();
 cssonlyapply();
	
}

});

};


 function looksready() {


  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
   
     if (typeof settings.browserplugsenabled !== 'boolean') console.log('Failed looksready module boolean verification');	 

  if (typeof settings.browserplugsenabled !== 'boolean') return;	 

   /*
   if (window.location.host !== "blank" && window.location.pathname !== "blank") {
   
  		   var styles = [
    'background: transparent'
    , 'border: 0px solid #3E0E02'
    , 'color: deeppink'
    , 'display: block'
    , 'text-shadow: 0 1px 0 rgba(0, 0, 0, 0.3)'
    , 'box-shadow: 0 1px 0 rgba(255, 255, 255, 0.4) inset, 0 5px 3px -5px rgba(0, 0, 0, 0.5), 0 -13px 5px -10px rgba(255, 255, 255, 0.4) inset'
    , 'line-height: 17px'
    , 'text-align: left'
    , 'font-weight: bold'
].join(';');

  	   var styles2 = [
    'background: linear-gradient(#c12c86, #fc1e4e)'
    , 'border: 1px solid #3E0E02'
    , 'color: white'
    , 'display: block'
    , 'text-shadow: 0 1px 0 rgba(0, 0, 0, 0.3)'
    , 'box-shadow: 0 1px 0 rgba(255, 255, 255, 0.4) inset, 0 5px 3px -5px rgba(0, 0, 0, 0.5), 0 -13px 5px -10px rgba(255, 255, 255, 0.4) inset'
    , 'line-height: 35px'
    , 'text-align: left'
    , 'font-weight: bold'
].join(';');

 console.log('%c Browser Plugs %c Protecting on ' + window.location.host + ' ' + decodeURIComponent(window.location.pathname), 'font-weight: bold; font-size: 37px;color: hotpink; text-shadow: 1px 1px 0 rgb(217,31,38) , 3px 3px 0 rgb(226,91,14) , 4px 4px 0 rgb(245,221,8) , 5px 5px 0 rgb(5,148,68) , 7px 7px 0 rgb(2,135,206) , 9px 9px 0 rgb(4,77,145); line-height: 50px;', styles);
   }
else {
	console.log('%c Protecting on ' + window.location.host + '' + decodeURIComponent(window.location.pathname) + ' (dynamically created IFrame)', 'font-weight: bold; color: deeppink');
//BPAppendScript("js/bpfirewall/iframe.js");

}

 */
	
  
if (settings.cleanurlz) console.log('%c Font: ' + settings.fontenabled + ' | Plugin: ' +  settings.enableplugins + ' | Audio: ' + settings.enableaudioapi + ' | CPU: ' + settings.cpuenabled + ' | FakeGL: ' + settings.blocksomewebgl + ' | WebGL: ' + settings.blockwebgl + ' | Net: ' + settings.enablenetwork + ' | Er: ' + settings.errorignore + ' | Battery: ' + settings.batteryenabled  + ' | Screen: ' + settings.enablescreen + ' | Rects : ' + settings.blockclientrects + ' ', styles2);
 if (settings.cleanurlz) console.log("BP Content JS has loaded in " + window.location.href);
if (settings.cleanurlz) console.log("╓─────[ browser plugs content loader ]──────────────┐");
  
  if (!settings || !settings.browserplugsenabled || !settings.cleanurlz) return;
	
BPAppendScript("js/bpconsole/errorhandle-details.js");
	//BPAppendScript("js/bpconsole/errorhandle-extended.js");
	 	// BPAppendScript("js/bpconsole/errorhandle-full.js");
		//	 	 BPAppendScript("js/bpconsole/log-xhr.js");
				 //	 	 BPAppendScript("js/bpconsole/log-cssmedia.js");
			 //	 	 BPAppendScript("js/bpconsole/log-eventlisteners8.js");
		 BPAppendScript("js/bpconsole/test.js");
if (settings.cleanurlz) console.log("| Detailed Console Log appended to page dom         |");

});

  
chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.batteryenabled) return;

if (settings.profileoption1 === '1') BPAppendScript("js/bpoverride/override-battery.js");
if (settings.profileoption2 === '1') BPAppendScript("js/bpoverride/override-battery.js");
if (settings.profileoption3 === '1') BPAppendScript("js/bpoverride/override-battery.js");
if (settings.profileoption4 === '1')  BPAppendScript2("js/bprandom/override-battery.js");
  
if (settings.cleanurlz) console.log("| Battery protection appended to page dom           |");

});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockiframeeval) return;
  BPAppendScript("js/bpfirewall/block-createiframe.js");
if (settings.cleanurlz) console.log("| Blocking IFrame from CreateElement or Eval        |");

});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockxhrhttp) return;
  BPAppendScript("js/bpfirewall/block-xhrhttp.js");
 
if (settings.cleanurlz) console.log("| Blocking opening XHR HTTP Requests                |");

});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockwebgl) return;
  BPAppendScript("js/bpblock/block-webgl.js");
if (settings.cleanurlz) console.log("| All WebGL blocking appended to page dom           |");

});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blocksomewebgl) return;
   
 BPAppendScript("js/bpoverride/override-webgl.js");

if (settings.cleanurlz) console.log("| Some WebGL blocking appended to page dom          |");

});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.browserplugsmagicbphash) return;
	
if (!settings.profileoption4 === '1')   BPAppendScript2("js/bpoverride/override-charat.js");
if (!settings.profileoption4 === '1')  bpSendMessage("browserplugsMagicBPhash")

if (settings.profileoption4 === '1')   BPAppendScript2("js/bpoverride/override-charat-random.js");
if (!settings.profileoption4 === '1')  bpSendMessage("browserplugsMagicBPhashRandom")


if (settings.cleanurlz) console.log("| CharAt protection added to page dom              |");
});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockclientrects) return;
    
     BPAppendScript("js/bpoverride/override-getclientrects.js");
 bpSendMessage("blockclientrects")


if (settings.cleanurlz) console.log("| getClientRects blocking appended to page dom      |");

});




chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.getcomputedstyle) return;
  BPAppendScript("js/bpfirewall/block-getcomputed.js");


});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.performanceentries) return;
  BPAppendScript("js/bpfirewall/block-performanceentries.js");


});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.svgelements) return;
  BPAppendScript("js/bpfirewall/block-svgelements.js");


});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.windowbtoa) return;
  BPAppendScript("js/bpfirewall/block-windowbtoa.js");


});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.fontenabled) return;
if (settings.cleanurlz) console.log("| Font protection appended to page dom              |");
tryfontagain();


});

function tryfontagain() {
	
	if (window.location.protocol === 'chrome'||window.location.protocol === 'chrome:'||window.location.hostname === 'chrome.google.com') return;
	
 chrome.storage.sync.get('settings', function(storage) {
    settings = storage.settings || {};
	

	var xoption1 = settings.option1;
	var xoption2 = settings.option2;
	var xoption3 = settings.option3;
	var xoption4 = settings.option4;
	var xoption5 = settings.option5;
	var xoption6 = settings.option6;
	var xoption7 = settings.option7;
	var xoption8 = settings.option8;
		
		if (xoption1 === '1') {
  
if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts-fallback.js');

bpSendMessage("bpfonts-windows10");
		  
	
	} else if (xoption2 === '1') {
		
	   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-macfonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-macfonts-fallback.js');	  




		  
		 
} else if (xoption3 === '1') {

	if (!window.location.protocol === 'chrome' && !window.location.protocol === 'chrome:' && !window.location.protocol === 'devtools:' && !window.location.protocol === 'devtools' && !window.location.hostname === 'chrome.google.com') bpSendMessage("bpfonts-windows7");

   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-win7fonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-win7fonts-fallback.js');	  

bpSendMessage("bpfonts-windows7");


		  
		 
} else if (xoption4 === '1') {
		



   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-linuxfonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-linuxfonts-fallback.js');	  


		  

	

		} else if (xoption5 === '1') {
		
		


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist1.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist1-fallback.js');	  


		  
} else if (xoption6 === '1') {
		
		


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist2.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist2-fallback.js');	  





	
		  
		} else if (xoption7 === '1') {
		
		 


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontrandom.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontrandom-fallback.js');	  


		
	
} else if (xoption8 === '1') {
	
		 	 BrowserPlugsFontLink('js/bpfonts/whitelist-nofont.js');




		
	} else {
//BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts.js');
console.log('Error: Else from Font Module');
	if (!window.location.protocol === 'chrome' && !window.location.protocol === 'chrome:' && !window.location.hostname === 'chrome.google.com') bpSendMessage("bpfonts-windows10");




}
	

});

}

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

  if (!settings || !settings.browserplugsenabled || !settings.enableaudioapi) return;
if (settings.cleanurlz) console.log("| AudioAPI protection appended to page dom          |");


   BPAppendScript("js/bpblock/block-audioapi.js");

});  

	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablenetwork) return;

if (settings.profileoption1 === '1') BPAppendScript2("js/bpoverride/override-networkapi.js");
if (settings.profileoption2 === '1')  BPAppendScript2("js/bpoverride/override-networkapi2.js");
if (settings.profileoption3 === '1')  BPAppendScript2("js/bpoverride/override-networkapi3.js");
 if (settings.profileoption4 === '1') BPAppendScript2("js/bpoverride/override-networkapi.js");
  
if (settings.cleanurlz) console.log("| NetworkAPI protection appended to page dom        |");

	
});
  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.errorignore) return;
   BPAppendScript("js/bpconsole/errorhandle.js");

if (settings.cleanurlz) console.log("| Error handling appended to page dom               |");



});
  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.replacealert) return;
   BPAppendScript("js/bpfirewall/override-alert.js");
if (settings.cleanurlz) console.log("| Alternative safe alert appended to page dom       |");



});

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enableplugins) return;

  try {
/* updatePlugins(document,"plugins"); Remove */
}
catch (err) {
  return true;
}
if (settings.pluginoption1 === "1") BPAppendScript2("js/bpblock/block-plugins-emptyarray.js");
if (settings.pluginoption2 === "1") BPAppendScript2("js/bpblock/block-plugins-undefined.js");
if (settings.pluginoption3 === "1") BPAppendScript2("js/bpblock/block-plugins-functionaly.js");
if (settings.cleanurlz) console.log("| Block Plugin and device appended to page dom |");

});   

	  	


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.randomtimersenabled) return;
 BPAppendScript("js/bpoverride/override-randomizetimers.js");

 
if (settings.cleanurlz) console.log("| Randomized event timers added to page dom         |");
	
});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.autoremoverestrictions) return;

  BPAppendScript("js/bpforms/enable-all.js");
 
if (settings.cleanurlz) console.log("| autoremoverestrictions added to page dom         |");
	
});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.setenableautoagree) return;

  BPAppendScript("js/bpforms/bpautoagree.js");
 
 
if (settings.cleanurlz) console.log("| setenableautoagree added to page dom         |");
	
});
	
	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablejsheap) return;

  BPAppendScript("js/bpoverride/override-jsheap1.js");
 
 
if (settings.cleanurlz) console.log("| JSHeap added to page dom         |");
	
});
	
	   	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.cpuenabled) return;
if (settings.cleanurlz) console.log("| Fake CPU and Memory appended to page dom          |");	

// 3 =  random , high-end = 4
// R1
if (settings.profileoption1 === '1') BPAppendScript("js/bpoverride/override-normalcpu.js");
if (settings.profileoption2 === '1') BPAppendScript("js/bpoverride/override-normalcpu-2.js");
if (settings.profileoption3 === '1')   BPAppendScript("js/bprandom/override-cpu.js");
 if (settings.profileoption4 === '1') BPAppendScript("js/bpoverride/override-normalcpu-3.js");
  	 
try {
	 //updateCpu(document,"cpu"); 
}
catch (err) {
	console.log(err);
	
  return true;
}


	
});
	   
	      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablescreen) return; 
  // 3 =  random , high-end = 4

    if (window.location.hostname !== 'www.google.com') {
	if (settings.profileoption1 === '1') BPAppendScript2("js/bpoverride/override-normalscreen-2.js");
	if (settings.profileoption2 === '1') BPAppendScript2("js/bpoverride/override-normalscreen.js");
if (settings.profileoption3 === '1')   BPAppendScript2("js/bprandom/override-screen.js");
if (settings.profileoption4 === '1')   BPAppendScript2("js/bpoverride/override-normalscreen.js");

if (settings.cleanurlz) console.log("| Fake screen properties appended to page dom       |");
	}
});

	      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablevisibility) return;
 if (!settings.blockadditionalvisibility)  BPAppendScript("js/bpblock/block-focusdetect.js");
 if (settings.blockadditionalvisibility)   BPAppendScript("js/bpblock/block-focusdetect-extended.js");
 

});


      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.timezoneenabled) return;
   
		if (settings.timeoption1 === '1')  BPAppendScript("js/bpgeo/override-time-pst.js");
	if (settings.timeoption2 === '1')  BPAppendScript("js/bpgeo/override-time-cst.js");
if (settings.timeoption3 === '1')   BPAppendScript("js/bpgeo/override-time-est.js");
 if (settings.timeoption4 === '1')   BPAppendScript("js/bpgeo/override-time-london.js");
 

});

      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.geoipenabled) return;
   
	 BPAppendScript("js/bpgeo/override-geolocation.js");

 

});


      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablepermissionapi) return;
   
	 BPAppendScript("js/bpblock/block-permissions.js");

 

});


      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablehistoryblock) return;
   
	 BPAppendScript("js/bpblock/block-history.js");

 

});

  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablecaptureevents) return;
   
	 BPAppendScript("js/bpfirewall/block-captureevents.js");

 

});

  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enableoverrideload) return;
   
	 BPAppendScript("js/bpfirewall/block-windowonload.js");

 

});

  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.cryptorandomvalues) return;
   
	 BPAppendScript("js/bpfirewall/block-crypto.js");

 

});

      	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablecssmedia) return;
   
	 BPAppendScript("js/bpfirewall/block-cssmedia.js");

  BPAppendScript("js/bpfirewall/override-cssmedia.js");


});



	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablerightclick) return;
  BPAppendScript("js/bpfirewall/bp-enablerightclick.js");
  
if (settings.cleanurlz) console.log("| Repair context menu appended to page dom          |");
	
});  
	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablelanguage) return;


 BPAppendScript("js/bpoverride/override-language.js");
 

});   

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enableua) return;


 BPAppendScript("js/bpoverride/override-ua.js");
 

});   
		   
			  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.windowcontent) return;


 BPAppendScript("js/bpfirewall/block-windowcontent.js");
 

});      

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled) return;




  OnlyTry1();

});   



		  	 
 }
	
 function cssonlyapply() {
 
chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  
if (settings.cleanurlz) console.log("╓─────[ browser plugs styles loader ]───────────────┐");
  
  if (!settings || !settings.browserplugsenabled || !settings.glyphenabled) return;
var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-improvefonts.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);



});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.upgradecss) return;
 
var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-ultrabp.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);
if (settings.cleanurlz) console.log("| Global upgraded page styles appended to page head |");
});

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.highlightcss) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-selection.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);
if (settings.cleanurlz) console.log("| Highlight colors stylesheet appended to page head |");
});


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enablescrollbar) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-improvedscrollbar.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

if (settings.cleanurlz) console.log("| Enhanced scrollbar styles appended to page head   |");

});   

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enablecss100width) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-100percentimage.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

if (settings.cleanurlz) console.log("| Do not stretch images appended to page head       |");

});   

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.upgradetransition) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/browserplugs-transition.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);



if (settings.cleanurlz) console.log("| Transition effects appended to page head          |");

});   

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.blackwhiteenabled) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/force-bw.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);



if (settings.cleanurlz) console.log("| Black White effects appended to page head          |");

});   


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enableresetsanitize) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/reset-sanitize.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

if (settings.cleanurlz) console.log("| Reset Sanitize appended to page head          |");

});   

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enableresetdoctor) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/reset-html5doctor.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

if (settings.cleanurlz) console.log("| HTML5Doctor CSS appended to page head       |");

});   


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enablewin7) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-improvedscrollbar-win7.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

});   


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enableallcaps) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/override-allcaps.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

});   

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};

 if (!settings || !settings.browserplugsenabled || !settings.enableresetnormal) return;

var link = document.createElement("link");
link.href = chrome.extension.getURL("css/reset-normalize.css");
link.type = "text/css";
link.rel = "stylesheet";
document.getElementsByTagName("head")[0].appendChild(link);

});   




chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  
  if (!settings || !settings.browserplugsenabled) return;

 if (settings.cleanurlz) console.log("╙───────────────────────────────────────────────────-");
 

});



 }
 
 function TryNext() {
	 
	 chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled) return;

  if ((settings.whitegoogle) && (window.location.hostname === 'plus.google.com' || window.location.hostname === 'studio.youtube.com' || window.location.hostname === 'clients5.google.com' || window.location.hostname === 'wifiondemand.xfinity.com' || window.location.hostname === 'connectivitycheck.gstatic.com' || window.location.hostname === 'r1.res.office365.com'||window.location.hostname === 'google.org' || window.location.hostname === 'res.office365.com'||window.location.protocol === 'chrome-search:'||window.location.hostname === 'itunes.apple.com' || window.location.hostname === 'og'||window.location.hostname === 'taskassist-pa.clients6.google.com'||window.location.hostname === 'en.wikipedia.org' || window.location.hostname === 'outlook.office365.com'||window.location.hostname === 'myaccount.google.com'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'voice.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'accounts.youtube.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'meet.google.com'||window.location.hostname === 'twitter.com'||window.location.hostname === 'www.twitter.com'||window.location.hostname === 'www.facebook.com'||window.location.hostname === 'facebook.com'||window.location.hostname === 'fonts.googleapis.com'||window.location.hostname === 'fonts.gstatic.com'||window.location.hostname === 'cloud.seetest.io'||window.location.hostname === 'youtube.com'||window.location.hostname === 'www.youtube.com'||window.location.hostname === 'www.gmail.com'||window.location.hostname === 'mail.google.com'||window.location.hostname === 'translate.google.com'||window.location.hostname === 'translate.google.ie'||window.location.hostname === 'maps.google.com'||window.location.hostname === 'gmail.com'||window.location.hostname === 'chrome.google.com'||window.location.hostname === 'groups.google.com'||window.location.hostname === 'hardware.metrics.mozilla.com'||window.location.hostname === 'icloud.com'||window.location.hostname === 'www.icloud.com'||window.location.hostname === 'icloud.cdn-apple.com'||window.location.hostname === 'edge.icloud.com'||window.location.hostname === 'staticxx.facebook.com'||window.location.hostname === 'scontent.xx.fbcdn.net'||window.location.hostname === 'live.browserstack.com'||window.location.hostname === 'idmsa.apple.com'||window.location.hostname === 'setup.icloud.com'||window.location.hostname === 'id.apple.com'||window.location.hostname === 'appleid.apple.com'||window.location.hostname === 'feedbackws.icloud.com'||window.location.hostname === 'www.apple.com'||window.location.hostname === 'jsbeautifier.org'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-extension'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'l.facebook.com'||window.location.hostname === 'chromereleases.googleblog.com'||window.location.hostname === 'clients4.google.com'||window.location.hostname === 'googleblog.com'||window.location.hostname === 'rapidgator.net'||window.location.hostname === 'depositfiles.com'|| window.location.hostname === 'alfafile.net'||window.location.hostname === 'clients1.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'imgur.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-error:'||window.location.protocol === 'newtab:'||window.location.hostname === 'newtab'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome-devtools:'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'account.google.com'||window.location.hostname === 'www.google.com.hk'||window.location.hostname === 'www.google.co.uk'||window.location.hostname === 'www.google.jp'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'ssl.google-analytics.com'||window.location.hostname === 'gpjojbdnhfefmepomkakfoiejfefahlf'||window.location.hostname === 'gpgbpgdfipppcelfbdlbkhmibofknppj'||window.location.hostname === 'l.facebook.com'||window.location.protocol === 'chrome-error:')) {


} else { 

	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.cpuenabled) return;

if (settings.profileoption1 === '1') BPAppendScript2("js/bpoverride/override-normalcpu-2.js");
	if (settings.profileoption2 === '1') BPAppendScript("js/bpoverride/override-normalcpu.js");
if (settings.profileoption3 === '1')   BPAppendScript2("js/bprandom/override-cpu.js");
if (settings.profileoption4 === '1') BPAppendScript2("js/bpoverride/override-normalcpu-3.js");
	
});

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enableplugins) return;

if (settings.pluginoption1 === "1") BPAppendScript("js/bpblock/block-plugins-emptyarray.js");
if (settings.pluginoption2 === "1") BPAppendScript("js/bpblock/block-plugins-undefined.js");
if (settings.pluginoption3 === "1") BPAppendScript("js/bpblock/block-plugins-functionaly.js");
if (settings.pluginoption4 === "1") BPAppendScript("js/bpblock/block-plugins-undefined.js"); //Update to Random?




});   

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablemediaplugins) return;

if (settings.pluginoption1 === "1") BPAppendScript("js/bpblock/block-mediadevice-emptyarray.js");
if (settings.pluginoption2 === "1") BPAppendScript("js/bpblock/block-mediadevice-undefined.js");
if (settings.pluginoption3 === "1") BPAppendScript("js/bpblock/block-mediadevice-emptyarray.js");
if (settings.cleanurlz) console.log("| Block Plugin and device appended to page dom |");

});   

	  

chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  
  if (!settings || !settings.browserplugsenabled || !settings.enableaudioapi) return;

/*
 try {
 updateAudio(document,"audio");
}
catch (err) {
 return true;
}*/
 try {
  BPAppendScript("js/bpblock/block-audioapi.js");
}
catch (err) {
 return true;
}



  

});  
	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablenetwork) return;
if (settings.profileoption1 === '1') BPAppendScript("js/bpoverride/override-networkapi.js");
if (settings.profileoption2 === '1')  BPAppendScript("js/bpoverride/override-networkapi2.js");
if (settings.profileoption3 === '1')  BPAppendScript("js/bpoverride/override-networkapi3.js");
 if (settings.profileoption4 === '1') BPAppendScript("js/bpoverride/override-networkapi.js");
	
});



chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blockwebgl) return;
  BPAppendScript("js/bpblock/block-webgl.js");
});



chrome.storage.sync.get('settings', function (storage) {
 
 const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.blocksomewebgl) return;
   
 BPAppendScript2("js/bprandom/override-webgl.js");
});

	 chrome.storage.sync.get('settings', function (storage) {

	  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.extradefense) return;
   
SecondTry1(); 

});
	 
	
}



});


 }
 
 
  function TryNext2() {
	
	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.cpuenabled) return;
// 3 =  random , high-end = 4

if (settings.profileoption1 === '1') BPAppendScript("js/bpoverride/override-normalcpu.js");
	if (settings.profileoption2 === '1') BPAppendScript("js/bpoverride/override-normalcpu-2.js");
if (settings.profileoption3 === '1')   BPAppendScript("js/bprandom/override-cpu.js");
 if (settings.profileoption4 === '1') BPAppendScript("js/bpoverride/override-normalcpu-3.js");
	
});

	  	 	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enableplugins) return;

if (settings.pluginoption1 === "1") BPAppendScript("js/bpblock/block-plugins-emptyarray.js");
if (settings.pluginoption2 === "1") BPAppendScript("js/bpblock/block-plugins-undefined.js");
if (settings.pluginoption3 === "1") BPAppendScript("js/bpblock/block-plugins-functionaly.js");


});   


chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  
  if (!settings || !settings.browserplugsenabled || !settings.enableaudioapi) return;
   BPAppendScript("js/bpblock/block-audioapi.js");

});  
	   	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.enablenetwork) return;
if (settings.profileoption1 === '1') BPAppendScript("js/bpoverride/override-networkapi.js");
if (settings.profileoption2 === '1')  BPAppendScript("js/bpoverride/override-networkapi2.js");
if (settings.profileoption3 === '1')  BPAppendScript("js/bpoverride/override-networkapi3.js");
if (settings.profileoption4 === '1')  BPAppendScript("js/bpoverride/override-networkapi.js");
	
});
  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.errorignore) return;
   BPAppendScript("js/bpconsole/errorhandle.js");


});
  	chrome.storage.sync.get('settings', function (storage) {
  const settings = storage.settings || {};
  if (!settings || !settings.browserplugsenabled || !settings.replacealert) return;
   BPAppendScript("js/bpfirewall/override-alert.js");


});
  
	 
 }
 
 
 
 
 function Tryagain1() {
	setTimeout(booleanchecks, 200);
  OnlyTry1();
 //OnlyTry2();
 }
 function Doubletry() {
	setTimeout(booleanchecks, 500);
 }
 
  function OnlyTry1() {
	setTimeout(TryNext, 1);
 }
  function OnlyTry2() {
	setTimeout(TryNext, 200);
 }
  
 function SecondTry1() {
//	setTimeout(TryNext2, 50); 
 }

	
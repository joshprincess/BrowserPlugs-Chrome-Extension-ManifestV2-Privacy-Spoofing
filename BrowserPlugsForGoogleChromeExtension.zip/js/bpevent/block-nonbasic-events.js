// readystatechange resize show slideOpen tabsload tabselecs tabsselect toggle trackEvent showInventorySearchCookies printPage scroll submit goggle trackEvent trackSocialEvent unload visibilitychange focusin focus fireTrackEvent hrpoductcClick keyup keydown keypress load message modulesRefresh mousedown mousemove mouseout mouseover orientationchange pagehide params paste input error hide hashchange dialogclose dialogopen dynamicFields dynamicUrls edmundsUnifiedContainer cut ddc-mega-menu-nav-ajax-load-complete dialog dialogReady dialogClose dialogclose copy click change blur beforeunload auxclick at-request-successed at-request-succeeded ajaxSuccess ajax ajaxFormConfirm ajaxDialogComplete addCustomFormData Pixall FDDTMEEventHandlerReady DOMContentLoaded 

	(function() { 


	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
	if (e !== 'click' || e !== 'load' || e !== 'DOMContentLoaded' || e !== 'change' || e !== 'hashchange' 
|| e !== 'input' || e !== 'message'	|| e !== 'selectionchange' || e !== 'load'}) {
	   
	   	   a.apply(this, arguments);

	   && e !== 'blur' && e !== 'focusin' 
   && e !== 'focusout' && e !== 'visibilitychange-hidden' && e !== 'visibilitychange-visibile' && e !== 'message' 
   && e !== 'pageshow' && e !== 'pagehide' && e !== 'focus' && e !== 'onblur' && e !== 'onfocus' 
   && e !== 'DOMFocusIn' && e !== 'hide' && e !== 'mousemove' && e !== 'paste' && e !== 'beforepaste'
   && e !== 'unhandledrejection' && e !== 'hashchange' && e !== 'resize' && e !== 'error' && e !== 'onerror'
   && e !== 'copy' && e !== 'popstate' && e !== 'orientationchange'  && e !== 'scroll' 
   && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' 
   && e !== 'mousewheel' && e !== 'auxclick' && e !== 'change' && e !== 'selectionchange' 
   && e !== 'keyup'  && e !== 'onabort' && e !== 'beforeunload' && e !== 'unload' && e !== 'onbeforecut' 
   && e !== 'onbeforeactivate' && e !== 'onafterprint' && e !== 'onbeforeprint' && e !== 'onbeforedeactivate'
   && e !== 'oncontextmenu' && e !== 'ondrag' && e !== 'onresizeend' && e !== 'onreset' && e !== 'onstop' 
   && e !== 'onhelp' && e !== 'onbeforeeditfocus' && e !== 'oncut' && e !== 'resizeBy' && e !== 'resizeTo'  
   && e !== 'alert' && e !== 'DOMMouseSroll' && e !== 'offline' && e !== 'mozfullsreenchange' 
   && e !== 'textInput'  && e !== 'dragenter' && e !== 'touchend' && e !== 'zoom' && e !== 'focus'
   && e !== 'IntentMediaRefresh' && e !== 'touchstart' && e !== 'swipe-verticle' && e !== 'webkitAnimationEnd' && e !== 'touchcancel' 
   && e !== 'pan-horizontal'  && e !== 'pan-verticle'  && e !== 'mouseover'  && e !== 'pointerup' 
    && e !== 'pointerleave'  && e !== 'oTransitionEnd' && e !== 'message' && e !== 'live' && e !== 'dblclick' 
   && e !== 'doubleTap' && e !== 'MSPointerMove' && e !== 'pointerdown' && e !== 'dblclick' && e !== 'onMouseMoveCapture' 
  && e !== 'onMouseMoveCapture' && e !== 'onMouseDownCapture' && e !== 'onDoubleClick'  && e !== 'onDoubleClick'  
  && e !== 'createImageBitmap'   && e !== 'blink'
) {


	   }}
	}())
	   
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      window.document.hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	      window.document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

     document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

  
	      document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

})();




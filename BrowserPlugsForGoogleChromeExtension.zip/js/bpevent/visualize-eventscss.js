/* .distinctive {
  background-color: hotpink;
}
*/
// Override for adding event listeners
var oldAddEventListener = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function(eventName, eventHandler)
{
  var $elt = $(this),
      pos = $elt.offset(),
      $div = $('<div/>')
      numHandlers = $elt.data('number-of-handlers') || 0;
  
  if (pos) {
    $elt.data('number-of-handlers', numHandlers + 1);
    $div.css({
      position: 'absolute',
      left: pos.left + numHandlers * 11,
      top: pos.top,
      width: '10px',
      height: '10px',
      padding: 0,
      margin: 0,
      border: 'none',
      'border-radius': 0,
      'background-color': 'hotpink',
      'z-index': 99999999
    });
    $div.attr('title', eventName + '\n' + eventHandler.toString());
    $('body').append($div);
  }
  
  oldAddEventListener.apply(this, arguments);
};

// Your code
function clickHandler (event) {
  $(this).toggleClass('distinctive')
}

$('.level1').on('click', clickHandler);
$('.level2').on('click', clickHandler);
$('.level2').on('mousemove', function(){});
$('.level3').on('click', clickHandler);

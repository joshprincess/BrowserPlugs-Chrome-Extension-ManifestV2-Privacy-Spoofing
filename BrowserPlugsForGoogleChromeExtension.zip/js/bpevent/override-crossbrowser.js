 var clickamount = 0;
 var bluramount = 0;
 var mousemoveamount = 0;
var blockclickevents = false;
var blockmousemoveevents = false;
var fprisk1 = 0;
var fprisk2 = 0;
var fprisk3 = 0;
var fprisk4 = 0;
var fprisk5 = 0;
var currentrisk = 0;
var fpprotect = false;
var blockblurevents = false;

 (function() {
       var interfaces = [ HTMLDivElement, HTMLImageElement, HTMLElement, HTMLFontElement, HTMLContentElement, HTMLCanvasElement, HTMLBodyElement, HTMLDocument, HTMLDialogElement, HTMLFormElement, HTMLHtmlElement, HTMLIFrameElement, HTMLObjectElement /* ... (add as many as needed) */ ];
        for (var i = 0; i < interfaces.length; i++) {
            (function(original) {
                interfaces[i].prototype.addEventListener = function(type, listener, useCapture) {

                    // DO SOMETHING HERE
                 console.log('type('+type+') currentrisk('+currentrisk+') interface('+i+') listener('+listener+') useCapture('+useCapture+')');
                        
                    if (type === 'click') clickamount = clickamount + 1;
					
					 
					 if ((type === 'click') && (clickamount === 25||clickamount > 25) && (clickamount < 70)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall for Chrome on ' + window.location.hostname + ']  Warning: This website has created a large number of event listeners to detect clicks. More than 25 active event listeners have been created. Doing nothing right now. Preparing to plug resource leak and website recording, monitoring, and fingerprinting attempt if more than 300 are opened.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 
					 if ((type === 'click') && (clickamount === 70||clickamount > 70) && (clickamount < 300)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Browser Plugs warning on' + window.location.hostname + '] Click event listeners have reached 75, Doing nothing (allowing without blocking) for now. Raising Fingerprint Risk +1. If Fingerprint Risk reaches +3, additional protections will automatically be enabled.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 if ((type === 'click') && (clickamount === 300||clickamount > 300) && (clickamount < 1000)) fprisk1 = 1;
					 if ((type === 'click') && (clickamount === 300||clickamount > 300) && (clickamount < 1000)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + '] Amount of Click type Event Listeners added: '+clickamount+' Raising Fingerprint Risk +1', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 	 if ((type === 'click') && (clickamount === 1000||clickamount > 1000)) fprisk2 = 1;
					 if ((type === 'click') && (clickamount === 1000||clickamount > 1000))  console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + ']There are more than 1,000 event listeners added for the click event. ['+clickamount+']', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
 if ((type === 'click') && (clickamount === 1000||clickamount > 1000))   blockclickevents = true;

   if (type === 'blur') bluramount = bluramount + 1;
					
					 
					 if ((type === 'blur') && (bluramount === 25||bluramount > 25) && (bluramount < 70)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall for Chrome on ' + window.location.hostname + ']  Warning: This website has created a large number of event listeners to detect blurs. More than 25 active event listeners have been created. Doing nothing right now. Preparing to plug resource leak and website recording, monitoring, and fingerprinting attempt if more than 300 are opened.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 
					 if ((type === 'blur') && (bluramount === 70||bluramount > 70) && (bluramount < 300)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Browser Plugs warning on' + window.location.hostname + '] blur event listeners have reached 10, Doing nothing (allowing without blocking) for now. Raising Fingerprint Risk +1. If Fingerprint Risk reaches +3, additional protections will automatically be enabled.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 if ((type === 'blur') && (bluramount === 300||bluramount > 300) && (bluramount < 1000)) fprisk1 = 1;
					 if ((type === 'blur') && (bluramount === 300||bluramount > 300) && (bluramount < 1000)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + '] Amount of blur type Event Listeners added: '+bluramount+' Raising Fingerprint Risk +1', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 	 if ((type === 'blur') && (bluramount === 1000||bluramount > 1000)) fprisk3 = 1;
					 if ((type === 'blur') && (bluramount === 1000||bluramount > 1000))  console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + ']There are more than 1,000 event listeners added for the blur event. ['+bluramount+']', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
 if ((type === 'blur') && (bluramount === 1000||bluramount > 1000))   blockblurevents = true;
 
   if (type === 'mousemove') mousemoveamount = mousemoveamount + 1;
					
					 
					 if ((type === 'mousemove') && (mousemoveamount === 25||mousemoveamount > 25) && (mousemoveamount < 70)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall for Chrome on ' + window.location.hostname + ']  Warning: This website has created a large number of event listeners to detect mousemoves. More than 25 active event listeners have been created. Doing nothing right now. Preparing to plug resource leak and website recording, monitoring, and fingerprinting attempt if more than 300 are opened.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 
					 if ((type === 'mousemove') && (mousemoveamount === 70||mousemoveamount > 70) && (mousemoveamount < 300)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Browser Plugs warning on' + window.location.hostname + '] mousemove event listeners have reached 75, Doing nothing (allowing without blocking) for now. Raising Fingerprint Risk +1. If Fingerprint Risk reaches +3, additional protections will automatically be enabled.', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 if ((type === 'mousemove') && (mousemoveamount === 300||mousemoveamount > 300) && (mousemoveamount < 1000)) fprisk1 = 1;
					 if ((type === 'mousemove') && (mousemoveamount === 300||mousemoveamount > 300) && (mousemoveamount < 1000)) console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + '] Amount of mousemove type Event Listeners added: '+mousemoveamount+' Raising Fingerprint Risk +1', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
					 	 if ((type === 'mousemove') && (mousemoveamount === 1000||mousemoveamount > 1000)) fprisk3 = 1;
					 if ((type === 'mousemove') && (mousemoveamount === 1000||mousemoveamount > 1000))  console.log('%c ▓▒░  🅑🅡🅞🅦🅢🅔🅡 🅟🅛🅤🅖🅢 ░▒▓ - [Privacy Firewall blocks an event or function on  ' + window.location.hostname + ']There are more than 1,000 event listeners added for the mousemove event. ['+mousemoveamount+']', 'color: black; background-color: #82b1b7; border: 2px solid black; padding: 5px;');
 if ((type === 'mousemove') && (mousemoveamount === 1000||mousemoveamount > 1000))   blockmousemoveevents = true;
 
 
currentrisk = fprisk1 + fprisk2 + fprisk3 + fprisk4 + fprisk5;
						if (currentrisk === 2||currentrisk === 3||currentrisk === 4||currentrisk === 5) fpprotect = true;
					 
				if (fpprotect) {
					    arguments[0] = 'blocked' + arguments[0];
						console.log('Currentrisk: ' + currentrisk + ' | Overriding arguments. New arguments: ' + JSON.stringify(arguments));
                        
						return undefined;
				}
					else {
						return undefined;
						//return original.apply(this, arguments); 
					}
                }
            })(interfaces[i].prototype.removeEventListener);
        }
    })();
	
	
	/*
	var buttons = document.querySelectorAll('button');

for (var i = 0; i < buttons.length; i++) {
  buttons[i].onclick = bgChange;
} */
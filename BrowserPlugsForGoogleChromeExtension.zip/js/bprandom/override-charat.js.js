(function () {
	
var oldCharAt = String.prototype.charAt;
String.prototype.charAt = function(index) {

if (index === 0||index === 1||index === 35||index === 45||index === 50||index === 60||index === 65||index === 36) {
	return [0,0,0,71,77,78,46,47,48,49,26,27,28,15,16,17,18][Math.floor(Math.random() * 17)];


}
else {

	return oldCharAt.apply(this, arguments); 

}

String.prototype.charAt.toUpperCase = function(index) { return 50; }

}


var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {

if (index === 0) {
	
	/* ASCII
0-127 is basic latin
65 - 122  is A - z
0  is  Null
1 to 20  is Control Characters
21 - 24 is device controllers
26 - 36 is more control characters
8704-8959 math
34 38 is HTML quote and Ampersand
160 is nonbreak space
32 is space
158 is pm privacy messsage
2 is start of text
1114112 is ????
1114111 is supplementary private use
688-767	Spacing Modifier Letters
880-8191 Languages
9600-9631 block elements
9984-10175	dingbat
65279 	zero width no-break space

*/
	
	
	
	/* ASCII
65 - 90   is A-z
48 - 57   is  Numbers
32 - 63   is  Numbers and Symbols
0 - 31   is  Special Hex
127 - 127   is DEL
255 - 255   is  nbsp
123 - 254  is  Extended Asii
9000 - 9999   is  Emoji
NaN   is  No character found
*/
	 return [0,0,0,0,0,0,0,0,0,63,63,665,66,67,68,69,70,71,72,73,98,119,112,77,0,8853,1853,25357,2543,12421][Math.floor(Math.random() * 30)];

}
else {

	return [65,4,5,63,0,6,8,42,25,63,87,8421,4738][Math.floor(Math.random() * 13)];
}
}
})();
(function () {
	
var oldCharAt = String.prototype.charAt;
String.prototype.charAt = function(index) {

if (index === 35||index === 45||index === 50||index === 60||index === 65||index === 36||index == 85||index === 27||index === 24||index === 16||index === 15||index === 2||index === 252) {
	
			var bpTheAlphabet = Math.floor(Math.random() * 57) + 65;
			var bpTheAlphabet2 = Math.floor(Math.random() * 100000) + 1;
			
	return [bpTheAlphabet,bpTheAlphabet2][Math.floor(Math.random() * 2)];


}
else {

	return oldCharAt.apply(this, arguments); 

}

String.prototype.charAt.toUpperCase = function(index) { return bpTheAlphabet; }

}



var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {

if (index === 0) {

	 return oldcharCodeAt.apply(this, arguments); 

}
else {
	var bpFullLatin = Math.floor(Math.random() * 127) + 1;
	var bpABC = Math.floor(Math.random() * 57) + 65;
	var bpInternational = Math.floor(Math.random() * 7311) + 880;
	var bpBlockShapes = Math.floor(Math.random() * 9600) + 31;
	var bpControlChar = Math.floor(Math.random() * 24) + 1;
	var bpDingbat = Math.floor(Math.random() * 9984) + 191;
	var bpMathChars = Math.floor(Math.random() * 8704) + 255;
	var bpSpacingModify = Math.floor(Math.random() * 688) + 79;

	return [bpFullLatin,bpMathChars,bpBlockShapes,bpDingbat,bpSpacingModify,bpInternational,32,34,38,0,158,0,2,65279,65279,65279,1114112,160,bpSpacingModify,bpSpacingModify,bpFullLatin,bpABC,bpFullLatin,65279,bpSpacingModify,65279,bpABC,bpFullLatin,bpFullLatin,bpABC,65279,bpFullLatin,bpABC,bpABC,bpFullLatin,bpABC,bpFullLatin][Math.floor(Math.random() * 37)];
}
}
})();
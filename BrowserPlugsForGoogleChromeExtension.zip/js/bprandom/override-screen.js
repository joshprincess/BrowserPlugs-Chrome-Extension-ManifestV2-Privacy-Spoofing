(function () {
	
function processFunctions(scope) {
			
if (window.location.hostname === 'voice.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'meet.google.com'||window.location.hostname === 'twitter.com'||window.location.hostname === 'www.twitter.com'||window.location.hostname === 'www.facebook.com'||window.location.hostname === 'facebook.com'||window.location.hostname === 'fonts.googleapis.com'||window.location.hostname === 'fonts.gstatic.com'||window.location.hostname === 'cloud.seetest.io'||window.location.hostname === 'youtube.com'||window.location.hostname === 'www.youtube.com'||window.location.hostname === 'www.gmail.com'||window.location.hostname === 'mail.google.com'||window.location.hostname === 'translate.google.com'||window.location.hostname === 'translate.google.ie'||window.location.hostname === 'maps.google.com'||window.location.hostname === 'gmail.com'||window.location.hostname === 'chrome.google.com'||window.location.hostname === 'groups.google.com'||window.location.hostname === 'hardware.metrics.mozilla.com'||window.location.hostname === 'icloud.com'||window.location.hostname === 'www.icloud.com'||window.location.hostname === 'icloud.cdn-apple.com'||window.location.hostname === 'edge.icloud.com'||window.location.hostname === 'staticxx.facebook.com'||window.location.hostname === 'scontent.xx.fbcdn.net'||window.location.hostname === 'live.browserstack.com'||window.location.hostname === 'idmsa.apple.com'||window.location.hostname === 'setup.icloud.com'||window.location.hostname === 'id.apple.com'||window.location.hostname === 'appleid.apple.com'||window.location.hostname === 'feedbackws.icloud.com'||window.location.hostname === 'www.apple.com'||window.location.hostname === 'jsbeautifier.org'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-extension'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'l.facebook.com'||window.location.hostname === 'chromereleases.googleblog.com'||window.location.hostname === 'clients4.google.com'||window.location.hostname === 'googleblog.com'||window.location.hostname === 'rapidgator.net'||window.location.hostname === 'depositfiles.com'|| window.location.hostname === 'alfafile.net'||window.location.hostname === 'clients1.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'imgur.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'meet.google.com'||window.location.hostname === 'twitter.com'||window.location.hostname === 'www.twitter.com'||window.location.hostname === 'www.facebook.com'||window.location.hostname === 'facebook.com'||window.location.hostname === 'fonts.googleapis.com'||window.location.hostname === 'fonts.gstatic.com'||window.location.hostname === 'cloud.seetest.io'||window.location.hostname === 'youtube.com'||window.location.hostname === 'www.youtube.com'||window.location.hostname === 'www.gmail.com'||window.location.hostname === 'mail.google.com'||window.location.hostname === 'translate.google.com'||window.location.hostname === 'translate.google.ie'||window.location.hostname === 'maps.google.com'||window.location.hostname === 'gmail.com'||window.location.hostname === 'chrome.google.com'||window.location.hostname === 'groups.google.com'||window.location.hostname === 'hardware.metrics.mozilla.com'||window.location.hostname === 'icloud.com'||window.location.hostname === 'www.icloud.com'||window.location.hostname === 'icloud.cdn-apple.com'||window.location.hostname === 'edge.icloud.com'||window.location.hostname === 'staticxx.facebook.com'||window.location.hostname === 'scontent.xx.fbcdn.net'||window.location.hostname === 'live.browserstack.com'||window.location.hostname === 'idmsa.apple.com'||window.location.hostname === 'setup.icloud.com'||window.location.hostname === 'id.apple.com'||window.location.hostname === 'appleid.apple.com'||window.location.hostname === 'feedbackws.icloud.com'||window.location.hostname === 'www.apple.com'||window.location.hostname === 'jsbeautifier.org'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-error:'||window.location.protocol === 'newtab:'||window.location.hostname === 'newtab'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome-devtools:'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'account.google.com'||window.location.hostname === 'www.google.com.hk'||window.location.hostname === 'www.google.co.uk'||window.location.hostname === 'www.google.jp'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'ssl.google-analytics.com'||window.location.hostname === 'gpjojbdnhfefmepomkakfoiejfefahlf'||window.location.hostname === 'l.facebook.com'||window.location.protocol === 'chrome-error:') {
  
} else { 
   		
 

		
		
  					}
				
				var mrrandom7 = Math.floor(Math.random()*10);
				
					
if (mrrandom7 < 8) {
	
   		
	
		
					 

			var randomnumber4 = Math.floor(Math.random() * 282) + 0;
			var randomnumber3 = Math.floor(Math.random() * 53) + 0;
			
			
 scope.Object.defineProperty(window.screen, "screenX", {enumerable: true, configurable: true, get: function(){return [randomnumber3,randomnumber3][Math.floor(Math.random() * 2)] }}); 
  						

 scope.Object.defineProperty(window.screen, "screenLeft", {enumerable: true, configurable: true, get: function(){return [randomnumber3,randomnumber3][Math.floor(Math.random() * 2)] }}); 
 
  scope.Object.defineProperty(window.screen, "screenY", {enumerable: true, configurable: true, get: function(){return [randomnumber4,randomnumber4][Math.floor(Math.random() * 2)] }}); 
  						

 scope.Object.defineProperty(window.screen, "screenTop", {enumerable: true, configurable: true, get: function(){return [randomnumber4,randomnumber4][Math.floor(Math.random() * 2)] }}); 
 
 
} else {
    
			
 scope.Object.defineProperty(window.screen, "screenX", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }}); 
  						

 scope.Object.defineProperty(window.screen, "screenLeft", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }}); 
 
  scope.Object.defineProperty(window.screen, "screenY", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }}); 
  						

 scope.Object.defineProperty(window.screen, "screenTop", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }}); 
 
		
}		 	
		

		
					/* Random Screen Properties */
				var mrrandom = Math.floor(Math.random()*10);
				
if (mrrandom < 7) {
   
scope.Object.defineProperty(window.screen, "width", {enumerable: true, configurable: true, get: function(){return 1366; }}); scope.Object.defineProperty(window.screen, "height", {enumerable: true, configurable: true, get: function(){return 768; }}); scope.Object.defineProperty(screen, "availHeight", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 4)+728)] }}); scope.Object.defineProperty(screen, "availWidth", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 4)+1356)] }});
var randomnumber = Math.floor(Math.random() * 128) + 1001;
var randomnumber2 = Math.floor(Math.random() * 200) + 405;	
scope.Object.defineProperty(window.screen, "innerWidth", {enumerable: true, configurable: true, get: function(){return [randomnumber,randomnumber,randomnumber,1366][Math.floor(Math.random() * 4)] }}); 
scope.Object.defineProperty(window.screen, "innerHeight", {enumerable: true, configurable: true, get: function(){return [randomnumber2,613,randomnumber2,662,randomnumber2][Math.floor(Math.random() * 5)] }}); 
} else {
	
scope.Object.defineProperty(window.screen, "width", {enumerable: true, configurable: true, get: function(){return 1920; }}); 
scope.Object.defineProperty(window.screen, "height", {enumerable: true, configurable: true, get: function(){return 1080; }});
scope.Object.defineProperty(window.screen, "availHeight", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 4)+1040)] }}); 
scope.Object.defineProperty(window.screen, "availWidth", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 4)+1910)] }});

scope.Object.defineProperty(window.screen, "innerWidth", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 10)+1040)] }}); 
scope.Object.defineProperty(window.screen, "innerHeight", {enumerable: true, configurable: true, get: function(){return [(Math.floor(Math.random() * 10)+1910)] }});

}
			 
	/* Common Color Depth */
 
 	
				var mrrandom2 = Math.floor(Math.random()*10);
				
if (mrrandom2 < 8) {
   scope.Object.defineProperty(window.screen, "colorDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
						
						  scope.Object.defineProperty(window.screen, "pixelDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
} else {
    scope.Object.defineProperty(window.screen, "colorDepth", {enumerable: true, configurable: true, get: function(){return 32; }});
						
						  scope.Object.defineProperty(window.screen, "pixelDepth", {enumerable: true, configurable: true, get: function(){return 32; }});
	
					 }
					 
									 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return idoc.apply(this);
				}
			}
		});

		
	(function() { 


	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
   if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout' && e !== 'visibilitychange-hidden' && e !== 'onblur' && e !== 'paste' && e !== 'unhandledrejection' && e !== 'error' && e !== 'onerror' && e !== 'copy' && e !== 'beforepaste' && e !== 'autocompleteerror' && e !== 'errorupdate' && e !== 'beforecopy' && e !== 'mousewheel' && e !== 'userproximity') {
	   a.apply(this, arguments);
	   }}
	   

})();


	 
}());
(function() {
    'use strict';


 function fakeCharging() {
	   	return [true,true,true,true,true,true,false,false][Math.floor(Math.random() * 7)];
    }
    function fakeChargingTime() {
	  var dt2 = Math.floor(Math.random() * 6100) + 1200;
	return [dt2,Infinity,0,0,0,0,0,0,Infinity,Infinity,0,0,0,0,dt2][Math.floor(Math.random() * 15)];
    }
    function fakeDischargingTime() {
     var dt = Math.floor(Math.random() * 7000) + 1150;
	 return [Infinity,Infinity,Infinity,Infinity,Infinity,Infinity,Infinity,dt,dt,dt,dt][Math.floor(Math.random() * 9)];
    }
    function fakeLevel() {
	return [1,1,1,1,1,1,1,1,56.99999999999999,57.99999999999999,58.99999999999999,58.99999999999999,70.99999999999999,0.84,0.77,0.99,0.98,0.98,0.98,0.99,0.98,0.97,0.96,0.95,0.94,0.93,0.92,0.91,0.90,0.89,0.88,0.87,0.86,0.76,0.65,0.48,0.73,0.74,0.75][Math.floor(Math.random() * 28)];

	}
 
  const fakeChargingValue = fakeCharging();
    const fakeLevelValue = fakeLevel();
	const fakeDischargingValue = fakeDischargingTime();
	const fakeChargingTimeValue = fakeChargingTime();
	
    Object.defineProperties(BatteryManager.prototype, {
        charging: {
            configurable: true,
            enumerable: true,
            get: function getCharging() {
            

                 return fakeChargingValue;
            }
        },

        
        chargingTime: {
            configurable: true,
            enumerable: true,
            get: function getChargingTime() {
            

                return fakeChargingTimeValue;
            }
        },

        dischargingTime: {
            configurable: true,
            enumerable: true,
            get: function getDischargingTime() {
        
                return fakeDischargingValue;
            }
        },

       
        level: {
            configurable: true,
            enumerable: true,
            get: function getLevel() {
         

                return fakeLevelValue;
            }
        }
    });
})();

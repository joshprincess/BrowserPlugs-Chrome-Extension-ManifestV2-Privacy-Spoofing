(function () {
	
			function processFunctions(scope) {
	var mrrandom15 = Math.floor(Math.random()*31);
	var BPCode = ""
	if (window.location.hostname === 'voice.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'meet.google.com'||window.location.hostname === 'twitter.com'||window.location.hostname === 'www.twitter.com'||window.location.hostname === 'www.facebook.com'||window.location.hostname === 'facebook.com'||window.location.hostname === 'fonts.googleapis.com'||window.location.hostname === 'fonts.gstatic.com'||window.location.hostname === 'cloud.seetest.io'||window.location.hostname === 'youtube.com'||window.location.hostname === 'www.youtube.com'||window.location.hostname === 'www.gmail.com'||window.location.hostname === 'mail.google.com'||window.location.hostname === 'translate.google.com'||window.location.hostname === 'translate.google.ie'||window.location.hostname === 'maps.google.com'||window.location.hostname === 'gmail.com'||window.location.hostname === 'chrome.google.com'||window.location.hostname === 'groups.google.com'||window.location.hostname === 'hardware.metrics.mozilla.com'||window.location.hostname === 'icloud.com'||window.location.hostname === 'www.icloud.com'||window.location.hostname === 'icloud.cdn-apple.com'||window.location.hostname === 'edge.icloud.com'||window.location.hostname === 'staticxx.facebook.com'||window.location.hostname === 'scontent.xx.fbcdn.net'||window.location.hostname === 'live.browserstack.com'||window.location.hostname === 'idmsa.apple.com'||window.location.hostname === 'setup.icloud.com'||window.location.hostname === 'id.apple.com'||window.location.hostname === 'appleid.apple.com'||window.location.hostname === 'feedbackws.icloud.com'||window.location.hostname === 'www.apple.com'||window.location.hostname === 'jsbeautifier.org'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-extension'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'l.facebook.com'||window.location.hostname === 'chromereleases.googleblog.com'||window.location.hostname === 'clients4.google.com'||window.location.hostname === 'googleblog.com'||window.location.hostname === 'rapidgator.net'||window.location.hostname === 'depositfiles.com'|| window.location.hostname === 'alfafile.net'||window.location.hostname === 'clients1.google.com'||window.location.hostname === 'docs.google.com'||window.location.hostname === 'earth.google.com'||window.location.hostname === 'hangouts.google.com'||window.location.hostname === 'imgur.com'||window.location.hostname === 'www.gerber-viewer.com'||window.location.hostname === 'ajax.googleapis.com'||window.location.hostname === 'apis.google.com'||window.location.hostname === 'voice_module_set'||window.location.hostname === 'notifications.google.com'||window.location.hostname === 'gsuite.google.com'||window.location.hostname === 'office.live.com'||window.location.hostname === 'drive.google.com'||window.location.hostname === 'circuitpeople.com'||window.location.hostname === 'gerber-viewer.easyeda.com'||window.location.hostname === 'ogs.google.com'||window.location.hostname === 'web.whatsapp.com'||window.location.hostname === 'csi.gstatic.com'||window.location.hostname === 'ssl.gstatic.com'||window.location.hostname === 'www.gstatic.com'||window.location.hostname === 'cello.client-channel.google.com'||window.location.hostname === 'www.chromestatus.com'||window.location.hostname === 'meet.google.com'||window.location.hostname === 'twitter.com'||window.location.hostname === 'www.twitter.com'||window.location.hostname === 'www.facebook.com'||window.location.hostname === 'facebook.com'||window.location.hostname === 'fonts.googleapis.com'||window.location.hostname === 'fonts.gstatic.com'||window.location.hostname === 'cloud.seetest.io'||window.location.hostname === 'youtube.com'||window.location.hostname === 'www.youtube.com'||window.location.hostname === 'www.gmail.com'||window.location.hostname === 'mail.google.com'||window.location.hostname === 'translate.google.com'||window.location.hostname === 'translate.google.ie'||window.location.hostname === 'maps.google.com'||window.location.hostname === 'gmail.com'||window.location.hostname === 'chrome.google.com'||window.location.hostname === 'groups.google.com'||window.location.hostname === 'hardware.metrics.mozilla.com'||window.location.hostname === 'icloud.com'||window.location.hostname === 'www.icloud.com'||window.location.hostname === 'icloud.cdn-apple.com'||window.location.hostname === 'edge.icloud.com'||window.location.hostname === 'staticxx.facebook.com'||window.location.hostname === 'scontent.xx.fbcdn.net'||window.location.hostname === 'live.browserstack.com'||window.location.hostname === 'idmsa.apple.com'||window.location.hostname === 'setup.icloud.com'||window.location.hostname === 'id.apple.com'||window.location.hostname === 'appleid.apple.com'||window.location.hostname === 'feedbackws.icloud.com'||window.location.hostname === 'www.apple.com'||window.location.hostname === 'jsbeautifier.org'||window.location.hostname === 'developer.mozilla.org'||window.location.protocol === 'chrome-extension:'||window.location.protocol === 'chrome-error:'||window.location.protocol === 'newtab:'||window.location.hostname === 'newtab'||window.location.protocol === 'chrome:'||window.location.protocol === 'chrome-devtools:'||window.location.hostname === 'accounts.google.com'||window.location.hostname === 'account.google.com'||window.location.hostname === 'www.google.com.hk'||window.location.hostname === 'www.google.co.uk'||window.location.hostname === 'www.google.jp'||window.location.hostname === 'disqus.com'||window.location.hostname === 'interactive-examples.mdn.mozilla.net'||window.location.hostname === 'idrive.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'contacts.google.com'||window.location.hostname === 'ssl.google-analytics.com'||window.location.hostname === 'gpjojbdnhfefmepomkakfoiejfefahlf'||window.location.hostname === 'l.facebook.com'||window.location.protocol === 'chrome-error:') { //Action } else { /Nothing }  */
console.log(mrrandom15);
					/* readystatechange			*/
if (mrrandom15 === 1||mrrandom15 === 2) {
	
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 16 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 16 }); } catch(e) {}";
try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [1,1][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [16,16][Math.floor(Math.random() * 2)] }}); } catch(e) {}

				}
if (mrrandom15 === 3) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 16 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 16 }); } catch(e) {}";
				
								try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [4,4][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [16,16][Math.floor(Math.random() * 2)] }}); } catch(e) {}
}
if (mrrandom15 === 4||mrrandom15 === 5) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
				
					
								try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [4,4][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [12,12][Math.floor(Math.random() * 2)] }}); } catch(e) {}
}
if (mrrandom15 === 6) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 6 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 6 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
				
						try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [6,6][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [8,8][Math.floor(Math.random() * 2)] }}); } catch(e) {}
				
}
if (mrrandom15 === 7) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 6 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 6 }); } catch(e) {}";
				
try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [4,4][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [6,6][Math.floor(Math.random() * 2)] }}); } catch(e) {}
				
}



if (mrrandom15 === 8||mrrandom15 === 10) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
				
								
try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [2,2][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [8,8][Math.floor(Math.random() * 2)] }}); } catch(e) {}
}
if (mrrandom15 === 11||mrrandom15 === 12||mrrandom15 === 13) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {}";
				
				try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [2,2][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [4,4][Math.floor(Math.random() * 2)] }}); } catch(e) {}
				
}

		if (mrrandom15 === 14) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 3 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 3 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
					try { scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return [3,3][Math.floor(Math.random() * 2)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return [8,8][Math.floor(Math.random() * 2)] }}); } catch(e) {}
			
}

					if (mrrandom15 === 15) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {}";
}

						 
					if (mrrandom15 === 16) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 8 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 8 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
}
				if (mrrandom15 === 17) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 8 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 8 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}
						 
		
		
				if (mrrandom15 === 18) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}
						 
				if (mrrandom15 === 19) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 10 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 10 }); } catch(e) {}";
}	
				
					if (mrrandom15 === 20||mrrandom15 === 21||mrrandom15 === 22) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {}";
}	

				if (mrrandom15 === 21||mrrandom15 === 22||mrrandom15 === 23) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
}	

		if (mrrandom15 === 24||mrrandom15 === 25) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}	
				if (mrrandom15 === 26) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}		
					if (mrrandom15 === 27) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}		
	
	
			if (mrrandom15 === 28) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}		
	
		
			if (mrrandom15 === 29) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 4 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 12 }); } catch(e) {}";
}		
	
				if (mrrandom15 === 30) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {}";
}		
	
					if (mrrandom15 === 31) {
	
   		
	BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); } catch(e) {}";
}	

			  
var script = document.createElement("script");
script.type = "text/javascript";
script.textContent = BPCode;
document.documentElement.appendChild(script);
script.onload = () => {
    script.remove();
}
try { script.remove(); } catch {}


	


		
	
 
					 
									 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return idoc.apply(this);
				}
			}
		})


}
})();
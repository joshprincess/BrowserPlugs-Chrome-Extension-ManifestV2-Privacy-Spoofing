chrome.loadTimes = function() { 
 console.log("blocked chrome.loadTimes");
 return false;

};

chrome.loadTimes.startTime = function() { 
  console.log("blocked chrome.startTime");

 return false;

};

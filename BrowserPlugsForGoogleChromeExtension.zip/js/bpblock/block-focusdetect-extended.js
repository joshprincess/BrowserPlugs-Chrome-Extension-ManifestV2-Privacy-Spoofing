(function() {
	  "use strict";

	var avsf = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(ebpb,f) {
	console.log('addEventListener Requested* ' + ebpb + ' ' + f + ' | arguments: ' + JSON.stringify(arguments))	
 if (ebpb !== 'visibilitychange' && ebpb !== 'webkitvisibilitychange' && ebpb !== 'focusout' && ebpb !== 'visibilitychange-hidden' &&
 ebpb !== 'visibilitychange-visibile' && ebpb !== 'paste' && ebpb !== 'beforepaste' && ebpb !== 'orientationchange' 
 && ebpb !== 'MSFullscreenChange' && ebpb !== 'fullscreenchange' && ebpb !== 'webkitfullscreenchange' && ebpb !== 'oncut' 
 && ebpb !== 'mozfullsreenchange' && ebpb !== 'onbeforecut' && ebpb !== 'onbeforeprint' && ebpb !== 'onafterprint'
 && ebpb !== 'onresize' && ebpb !== 'resize' && ebpb !== 'onresizestart' && ebpb !== 'onblur' && ebpb !== 'pagehide'&& ebpb !== 'onresizeend' 
 && ebpb !== 'onpagehide' && ebpb !== 'zoom' && ebpb !== 'reset' && ebpb !== 'onerror' && ebpb !== 'mouseover' && ebpb !== 'mouseout' && ebpb !== 'pointerover' && ebpb !== 'error' && ebpb !== 'pointerout' && ebpb !== 'pointerleave'  && ebpb !== 'unload' && ebpb !== 'onunload' && ebpb !== 'beforeunload' 
 && ebpb !== 'refreshOffline'  && ebpb !== 'touchend' && ebpb !== 'popstate'

) {

	  console.log(ebpb + ' ' + f)
	 avsf.apply(this, arguments);
	 
}}})(); 


if (window.hj) console.log('window.hj detected');

if (document.hj) console.log('document.hj detected');


(function() {
	  "use strict";

	var a = Node.prototype.removeEventListener;
	 Node.prototype.removeEventListener = function(ebpb,f) {
	console.log('----removeEventListener Requested: ' + ebpb + ' ' + f)	
 if (ebpb !== 'AllowedDOMContentLoaded' && ebpb !== 'RequestedDOMContentLoaded' && ebpb !== 'RequestedDOMNodeRemoved' && ebpb !== 'AllowedDOMNodeInserted' 
 && ebpb !== 'Requestedvisibilitychange' && ebpb !== 'AllowedDOMNodeInserted' && ebpb !== 'Requestedvisibilitychange' && ebpb !== 'RequestedDOMNodeInserted') {

 console.log('----removeEventListener Allowed' + ebpb + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 


(function() {
	var vx = String.prototype.trim;
	 String.prototype.trim = function(ebpb) {
		 JSON.stringify(ebpb);
	console.log('----trim Requested' + ebpb + ' | arguments: ' + JSON.stringify(arguments))	
 if (ebpb !== 'tabIndex' && ebpb !== 'readOnly' && ebpb !== 'lasterror') {

 console.log('----trim Allowed' + ebpb)	
	 vx.apply(this, arguments);
	 
}}})(); 

(function() {
	  "use strict";
   
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      var hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

  
	  
  })(); 

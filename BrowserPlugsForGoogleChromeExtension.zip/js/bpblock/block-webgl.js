(function() {
    'use strict';

var BR0WSERplugsGL2={7936:"WebKit",7937:"WebKit WebGL",7938:"WebGL 2.0 (OpenGL ES 3.0 Chromium)",37445:"Google Inc.",37446:null,35724:"WebGL GLSL ES 3.00 (OpenGL ES GLSL ES 3.0 Chromium)",34921:"32",36347:"256",35660:"16",36348:"32",35658:"1036",35371:"12",37154:"64",35659:"128",35978:"64",35979:"4",35968:"64",33902:"[1, 1]",33901:"[0.125, 8192]",36349:"224",34930:"16",34852:"8",36063:"8",36183:"4",3410:"8",3411:"8",3412:"8",3413:"8",3414:"24",3415:"8",34024:"8192",3386:"[8192, 8192]",3379:"8192",34076:"8192",35661:"32",34047:"16",32883:"8192",35071:"8192",34045:"12",35375:"24",35376:"16384",35380:"4",35374:"24",35377:"50188",35379:"50060"};
var getBPugsGL=WebGL2RenderingContext.prototype.getParameter;
WebGL2RenderingContext.prototype.getParameter=function(e){return BR0WSERplugsGL2[e]?BR0WSERplugsGL2[e]:getBPugsGL.apply(this,arguments)};
var getBPugsGLx=WebGLRenderingContext.prototype.getParameter;
WebGLRenderingContext.prototype.getParameter=function(e){return BR0WSERplugsGL2[e]?BR0WSERplugsGL2[e]:getBPugsGLx.apply(this,arguments)};

})();

if (!window.ogcctxfunc8675309) {
 window.ogcctxfunc8675309 = HTMLCanvasElement.prototype.getContext;
 HTMLCanvasElement.prototype.getContext = function (a, b) {
	 var myJSON = JSON.stringify(b);
  var la = a.toLowerCase();
  if (la.indexOf("webgl") >= 0) {
   
  return null;
  };
      if (la.indexOf("webgl2") >= 0) {
   
  return null;
  };
      if (la.indexOf("webgl2-compute") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2-compute of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };
 
       if (la.indexOf("webgl2-compute-context") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2-compute-context of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };
   if (la.indexOf("webgl2compute") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2Compute of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };

        if (la.indexOf("experimental-webgl") >= 0) {
   console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement experimental-webgl of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return null;
  };
          if (la.indexOf("experimental-webgl2") >= 0) {
   console.log('%c ð”¹ð•£ð• ð•¨ð•¤ð•–ð•£ â„™ð•ð•¦ð•˜ð•¤ ð”½ð•šð•£ð•–ð•¨ð•’ð•ð• ð•—ð• ð•£ â„‚ð•™ð•£ð• ð•žð•– has blocked __HTMLCanvasElement experimental-webgl2 of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl2 is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return null;
  };
  if (b) {
   return window.ogcctxfunc8675309.call(this, a, b);
  } else {
   return window.ogcctxfunc8675309.call(this, a);
  };
 };
};


	 HTMLCanvasElement.prototype.toDataURL = function () {
   console.log('%c Browser Plug Firewall for Chrome has blocked __HTMLCanvasElement toDataURL on ' + window.location.host + '. Canvas toDataURL is blocked in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return '';
  
 }
 HTMLCanvasElement.prototype.toBlob = function () {
   console.log('%c Browser Plug Firewall for Chrome has blocked __HTMLCanvasElement toBlob on ' + window.location.host + '. Canvas toDataURL is blocked in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return '';
  
 }
 CanvasRenderingContext2D.prototype.getImageData = function () {
   console.log('%c Browser Plug Firewall for Chrome has blocked CanvasRenderingContext2D getImageData on ' + window.location.host + '. Canvas getImageData is blocked in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return '';
  
 }
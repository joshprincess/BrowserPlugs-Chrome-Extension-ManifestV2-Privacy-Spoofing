var getBPugsGLComp=WebGL2ComputeRenderingContext.prototype.getParameter;
WebGL2ComputeRenderingContext.prototype.getParameter=function(e){return BR0WSERplugsGL2[e]?BR0WSERplugsGL2[e]:getBPugsGLComp.apply(this,arguments)};

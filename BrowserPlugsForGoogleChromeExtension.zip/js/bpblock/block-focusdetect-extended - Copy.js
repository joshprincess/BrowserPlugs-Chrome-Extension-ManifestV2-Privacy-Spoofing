/*(function() {
	  "use strict";

	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e,f) {
	console.log('addEventListener Requested* ' + e + ' ' + f + ' | arguments: ' + JSON.stringify(arguments))	
 if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout' && e !== 'visibilitychange-hidden' &&
 e !== 'visibilitychange-visibile' && e !== 'paste' && e !== 'beforepaste' && e !== 'orientationchange' 
 && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' && e !== 'oncut' 
 && e !== 'mozfullsreenchange' && e !== 'zoom' && e !== 'onbeforecut' && e !== 'onbeforeprint' && e !== 'onafterprint'
 && e !== 'onresize' && e !== 'resize' && e !== 'onresizestart' && e !== 'onblur' && e !== 'pagehide'&& e !== 'onresizeend' 
 && e !== 'onpagehide' && e !== 'zoom' && e !== 'reset' && e !== 'onerror' && e !== 'error' && e !== 'compositionstart') {

	  console.log(e,f)
	 a.apply(this, arguments);
	 
}}})(); 

*/

let my_details =  
            {
               "0"  : "isFunction",
            }
let my_details_in_json = JSON.stringify(my_details);


(function() {
	var a = Object.prototype.hasOwnProperty;
	 Object.prototype.hasOwnProperty = function(e) {
	console.log('----hasOwnProperty Requested: ' + e + ' | arguments: ' + JSON.stringify(arguments))	
 if (e !== '_rollbar_wrapped' && e !== 'gtm' && e !== 'adblockernotdetected:Gateway_right-2_desktop') {

// console.log('----Object.hasOwnProperty Allowed: ' + e)	
	 a.apply(this, arguments);
	 
}}})(); 

(function() {
	var a = Object.prototype.isFunction;
	 Object.prototype.isFunction = function(e,f) {
	console.log('----Object.isFunction Requested: ' + e + ' ' + f)	
 if (e !== 'load' && e !== 'unload') {

 console.log('----Object.isFunction Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 





// Object.prototype.hasOwnProperty , Array.prototype.push  , Array.prototype.slice , 
// Object.prototype.toString Array.prototype.slice.call
/*
        Array.prototype.slice.call(m.documentElement.childNodes, 0)[0].nodeType
		
		getElementFromEvent
		isDescribedElement
		captureDomEvent
		
		
		EventTarget,Window,Node,ApplicationCache,AudioTrackList,ChannelMergerNode,CryptoOperation,EventSource,FileReader,HTMLUnknownElement,IDBDatabase,IDBRequest,IDBTransaction,KeyOperation,MediaController,MessagePort,ModalWindow,Notification,SVGElementInstance,Screen,TextTrack,TextTrackCue,TextTrackList,WebSocket,WebSocketWorker,Worker,XMLHttpRequest,XMLHttpRequestEventTarget,XMLHttpRequestUpload
		
		 r.prototype.global = function(t) {
    return this.client.global(t),
    this
  }
  
  
		
		Array.prototype.slice
		
		i.prototype.deinstrumentDom = function() {
    ("addEventListener"in this._window || "attachEvent"in this._window) && this.removeListeners("dom")
  }
		
*/

/*

(function() {
	var a = Node.prototype.attachEvent;
	 Node.prototype.attachEvent = function(e,f) {
	console.log('attachEvent Requested* ' + e + ' ' + f)	
 if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout' && e !== 'visibilitychange-hidden' &&
 e !== 'visibilitychange-visibile' && e !== 'paste' && e !== 'beforepaste' && e !== 'orientationchange' 
 && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' && e !== 'oncut' 
 && e !== 'mozfullsreenchange' && e !== 'zoom' && e !== 'onbeforecut' && e !== 'onbeforeprint' && e !== 'onafterprint'
 && e !== 'onresize' && e !== 'resize' && e !== 'onresizestart' && e !== 'onblur' && e !== 'pagehide'&& e !== 'onresizeend' 
 && e !== 'onpagehide' && e !== 'zoom' && e !== 'reset' && e !== 'onerror' && e !== 'error' && e !== 'compositionstart') {

	  console.log(e,f)
	 a.apply(this, arguments);
	 
}}})(); 



(function() {
	  "use strict";

	var a = Node.prototype.removeEventListener;
	 Node.prototype.removeEventListener = function(e,f) {
	console.log('----removeEventListener Requested' + e + ' ' + f)	
 if (e !== 'load' && e !== 'unload') {

 console.log('----removeEventListener Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

(function() {
	  "use strict";

	var a = Node.prototype.createEvent;
	 Node.prototype.createEvent = function(e,f) {
	console.log('----createEvent Requested' + e + ' ' + f)	
 if (e !== 'error' && e !== 'onerror' && e !== 'lasterror') {

 console.log('----createEvent Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

/*
(function() {
	  "use strict";

	var a = Node.prototype.getAttribute;
	 Node.prototype.getAttribute = function(e,f) {
	console.log('----getAttribute Requested' + e + ' ' + f)	
 if (e !== 'disabled' && e !== 'readOnly' && e !== 'unload') {

 console.log('----createEvent Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

(function() {
	  "use strict";

	var a = Node.prototype.call;
	 Node.prototype.call = function(e,f) {
	console.log('----call Requested' + e + ' ' + f)	
 if (e !== 'disabled' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----call Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

(function() {
	  "use strict";

	var a = Node.prototype.propHooks;
	 Node.prototype.propHooks = function(e,f) {
	console.log('----propHooks Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----propHooks Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

(function() {
	  "use strict";

	var a = window.prototype.getPreventDefault;
	 Node.prototype.getPreventDefault = function(e,f) {
	console.log('----getPreventDefault Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----getPreventDefault Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 


(function() {
	  "use strict";

	var a = window.Node.prototype.getModifierState;
	 Node.prototype.getModifierState = function(e,f) {
	console.log('----getModifierState Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----getModifierState Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 



(function() {
	  "use strict";

	var a = Node.prototype.setInterval;
	 Node.prototype.setInterval = function(e,f) {
	console.log('----setInterval Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----setInterval Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

/*
(function() {
	  "use strict";

	var a = Node.prototype.appendChild;
	 Node.prototype.appendChild = function(e,f) {
	console.log('----appendChild Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----appendChild Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 
*/

(function() {
	var vx = String.prototype.trim;
	 String.prototype.trim = function(e) {
		 JSON.stringify(e);
	console.log('----trim Requested' + e + ' | arguments: ' + JSON.stringify(arguments))	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----trim Allowed' + e)	
	 vx.apply(this, arguments);
	 
}}})(); 

/*
(function() {
	var a = Array.prototype.indexOf;
	 Array.prototype.indexOf = function(e,f) {
	console.log('----Array.indexOf Requested' + e + ' ' + f)	
 if (e !== 'tabIndex' && e !== 'readOnly' && e !== 'lasterror') {

 console.log('----Array.indexOf Allowed' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 

*/

/*
(function() {
	  "use strict";

	var a = Node.prototype.getAttribute;
	 Node.prototype.getAttribute = function(e,f) {
	console.log('----getAttribute Requested' + e + ' ' + f)	
 if (e !== 'load' && e !== 'unload') {

	console.log('----getAttribute Allowed ' + e + ' ' + f)	
	 a.apply(this, arguments);
	 
}}})(); 
*/

(function() {
	  "use strict";
   
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      var hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

  
	  
  })(); 

(function () {


function processFunctions(scope) {
			
	

					try { AudioBuffer.prototype.getChannelData = function(){} } catch (err) { /* do nothing*/ }

						scope.Object.defineProperty(window, "OfflineAudioContext", {enumerable: true, configurable: true, get: function() {
					return [];
				}});
				
				
						scope.Object.defineProperty(window, "AudioContext", {enumerable: true, configurable: true, get: function() {
					return [];
				}});
				
				
						scope.Object.defineProperty(window, "webkitAudioContext", {enumerable: true, configurable: true, get: function() {
				
					return [];
				}});
				
		
				
				 }

	
				try { processFunctions(window) } catch (err) { /* do nothing*/ }
		try { processFunctions(document) } catch (err) { /* do nothing*/ }
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});

		

	 
}());

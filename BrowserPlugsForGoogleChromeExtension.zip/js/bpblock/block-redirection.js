/* 


<meta content='86400' http-equiv='refresh'>


window.location



*/
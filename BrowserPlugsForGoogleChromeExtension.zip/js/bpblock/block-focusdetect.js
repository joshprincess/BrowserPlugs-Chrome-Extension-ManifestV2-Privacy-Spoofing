(function() {
	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e,f) {
		
   if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'visibilitychange-hidden') {
	  // console.log(e,f)
	 a.apply(this, arguments);
	 
   } 
	   }
	   
	 
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      window.document.hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	      window.document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

     document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

  
	      document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	   
/*

	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
  if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout'
  && e !== 'visibilitychange-hidden' && e !== 'visibilitychange-visibile' 
  && e !== 'pagehide' && e !== 'onpagehide' && e !== 'onbeforepagehide' && e !== 'onblur' && e !== 'mousemove'
  && e !== 'paste' 
   && e !== 'beforepaste' && e !== 'unhandledrejection' && e !== 'resize' && e !== 'onerror'
   && e !== 'copy' && e !== 'orientationchange'  && e !== 'scroll' 
   && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' 
   && e !== 'mousewheel' && e !== 'keyup' && e !== 'onabort' && e !== 'onbeforecut' 
  && e !== 'onafterprint' && e !== 'onbeforeprint' && e !== 'oncontextmenu' && e !== 'ondrag' 
  && e !== 'onresizeend' && e !== 'onstop' 
  && e !== 'oncut' && e !== 'resizeBy' && e !== 'resizeTo'  
   && e !== 'DOMMouseSroll' && e !== 'offline' && e !== 'mozfullsreenchange' 
   && e !== 'dragenter' && e !== 'touchend' && e !== 'zoom' 
   && e !== 'touchstart' && e !== 'swipe-verticle' && e !== 'webkitAnimationEnd'
   && e !== 'touchcancel' && e !== 'pan-horizontal'  && e !== 'pan-verticle' 
   && e !== 'pointerup' && e !== 'pointerleave'  && e !== 'oTransitionEnd' && e !== 'live' && e !== 'dblclick' 
   && e !== 'doubleTap' && e !== 'MSPointerMove' && e !== 'pointerdown' && e !== 'onMouseMoveCapture' 
  && e !== 'onMouseDownCapture' && e !== 'onDoubleClick') {
	  
	  */

})();

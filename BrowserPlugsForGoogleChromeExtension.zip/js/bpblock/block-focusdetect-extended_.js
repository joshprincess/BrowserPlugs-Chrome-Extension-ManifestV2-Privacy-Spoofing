	(function() { 


	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
 if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout' && e !== 'visibilitychange-hidden' &&
 e !== 'visibilitychange-visibile' && e !== 'paste' && e !== 'beforepaste' && e !== 'orientationchange' 
 && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' && e !== 'oncut' 
 && e !== 'mozfullsreenchange' && e !== 'zoom' && e !== 'onbeforecut' && e !== 'onbeforeprint' && e !== 'onafterprint'
 && e !== 'onresize' && e !== 'resize' && e !== 'onresizestart' && e !== 'onblur') {
	   
	   
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      window.document.hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	      window.document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

     document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

  
	      document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

})();




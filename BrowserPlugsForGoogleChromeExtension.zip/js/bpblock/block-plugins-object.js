(function () {
	
function processFunctions(scope) {
		
				pluginbackup = navigator.plugins;
			pluginbackup2 = pluginbackup + pluginbackup;
			scope.Object.defineProperty(navigator, "plugins", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_plugins';
					browserplugins_triggerblock.title = 'navigator.plugins';
					document.documentElement.appendChild(browserplugins_triggerblock);
					return pluginbackup2; 


				}});
		
	
				
			

  window.navigator.mimeTypes = {
   length: 3,
   namedItem: function(){},
 filename: function(){},
    index: function(){}
}



				
	
									 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
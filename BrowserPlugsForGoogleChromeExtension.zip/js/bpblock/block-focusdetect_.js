//DETM_DTV_MOBILE_TRACK  DETM_DTV_TRACK  TagNotifier 

//?? DETM_DMF_PARSED  DTM_SATELLITE_STATE   detmScriptsReady    INQ-DETM-READY     hashchange

(function() {
	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e,f) {
		
   if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'visibilitychange-hidden') {
	  // console.log(e,f)
	 a.apply(this, arguments);
	 
   } 
	   }
	   
	 
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      window.document.hidden = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	      window.document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

     document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

  
	      document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }


})();
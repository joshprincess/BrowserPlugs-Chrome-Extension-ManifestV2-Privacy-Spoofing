function processFunctions(scope) {
		
		
			  

				     

					   window.Object.defineProperty(navigator, "webkitGetUserMedia", {enumerable: true, configurable: true, get: function() {
				
					return [];
}});
  

					   window.Object.defineProperty(navigator, "getUserMedia", {enumerable: true, configurable: true, get: function() {
				
					return [];
}});
  

					   window.Object.defineProperty(navigator, "enumerateDevices", {enumerable: true, configurable: true, get: function() {
				
					return [];
}});

				   window.Object.defineProperty(navigator, "mediaDevices", {enumerable: true, configurable: true, get: function() {
				
					return [];
}});

  window.navigator.mediaDevices.getUserMedia  = {
   length: 3,
   kind: function(){},
 label: function(){},
  deviceId: function(){}
}



  window.navigator.mediaDevices.enumerateDevices  = {
   length: 3,
   kind: function(){},
 label: function(){},
  deviceId: function(){}
}

}		

processFunctions(window);	

		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return idoc.apply(this);
				}
			}
		})
	

	 

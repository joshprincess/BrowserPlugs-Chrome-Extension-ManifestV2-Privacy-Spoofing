if (!window.ogcctxfunc8675309) {
 window.ogcctxfunc8675309 = HTMLCanvasElement.prototype.getContext;
 HTMLCanvasElement.prototype.getContext = function (a, b) {
	 var myJSON = JSON.stringify(b);
  var la = a.toLowerCase();
  if (la.indexOf("webgl") >= 0) {
   
  return null;
  };
      if (la.indexOf("webgl2") >= 0) {
   
  return null;
  };
      if (la.indexOf("webgl2-compute") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2-compute of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };
 
       if (la.indexOf("webgl2-compute-context") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2-compute-context of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };
   if (la.indexOf("webgl2compute") >= 0) {
      console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement webgl2Compute of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

  return null;
  };

        if (la.indexOf("experimental-webgl") >= 0) {
   console.log('%c Browser Plugs •– has blocked __HTMLCanvasElement experimental-webgl of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return null;
  };
          if (la.indexOf("experimental-webgl2") >= 0) {
   console.log('%c ð”¹ð•£ð• ð•¨ð•¤ð•–ð•£ â„™ð•ð•¦ð•˜ð•¤ ð”½ð•šð•£ð•–ð•¨ð•’ð•ð• ð•—ð• ð•£ â„‚ð•™ð•£ð• ð•žð•– has blocked __HTMLCanvasElement experimental-webgl2 of ' + a + ' attempting function  ' + myJSON + ' on ' + window.location.host + '. experimental-webgl2 is blocked as part of Block All WebGL in your settings.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');
  return null;
  };
  if (b) {
   return window.ogcctxfunc8675309.call(this, a, b);
  } else {
   return window.ogcctxfunc8675309.call(this, a);
  };
 };
};

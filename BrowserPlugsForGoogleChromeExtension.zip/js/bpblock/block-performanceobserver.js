PerformanceObserver.observe = function() { 
  console.log("Browser Plugs Firewall has blocked an attempt to use PerformanceObserver.observe");

 return;

};

PerformanceObserver.prototype.observe = function(list, observer) { 
 console.log("Browser Plugs Firewall has blocked an attempt to use PerformanceObserver.prototype.observe with type: " + type + " and observer: " + observer);
 
 return;

};

PerformanceObserver.prototype.takeRecords = function() { 
   console.log("Browser Plugs Firewall has blocked an attempt to use PerformanceObserver.prototype.takeRecords");

 return [];

};

window.navigator.__defineGetter__('PerformanceObserver', function() { console.log("__defineGetter__ for PerformanceObserver") });

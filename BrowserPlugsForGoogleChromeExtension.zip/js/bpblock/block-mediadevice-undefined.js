
 
  navigator.mediaDevices.enumerateDevices  = {
   length: 3,
   kind: function(){},
 label: function(){},
  deviceId: function(){},
}

(function () {
	
function processFunctions(scope) {
		

		   
			
  
   

					   scope.Object.defineProperty(navigator, "webkitGetUserMedia", {enumerable: true, configurable: true, get: function() {
				
					return true;
					}});

				
	
									 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
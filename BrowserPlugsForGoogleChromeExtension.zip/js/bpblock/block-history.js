	   window.history = function () {
			console.log('Browser Plugs blocked an attempt to view the history length');
return 2; 
	   }
	  
window.history.length = function () {
			console.log('Browser Plugs blocked an attempt to view the history length');
return 2; 
	   }

	  window.history.forward = function () {
					console.log('Browser Plugs blocked an attempt to manipulate browser history.');

		// Nothing
	   } 
	   

window.__defineGetter__('history', function() { return 2;});


	  
	(function() { 


	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
   if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'focusout' 
   && e !== 'visibilitychange-hidden' && e !== 'visibilitychange-visibile'
   && e !== 'paste' && e !== 'beforepaste' && e !== 'onpagehide' && e !== 'beforecopy' && e !== 'onpaste' && e !== 'onbeforepaste') {
	   a.apply(this, arguments);
	   }}
	   

})();




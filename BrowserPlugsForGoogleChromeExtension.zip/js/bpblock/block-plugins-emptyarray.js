(function () {
	
function processFunctions(scope) {
		
		
			   scope.Object.defineProperty(navigator, "plugins", {enumerable: true, configurable: true, get: function() {
					return [];
					}});

				
	
			   scope.Object.defineProperty(navigator, "mimeTypes", {enumerable: true, configurable: true, get: function() {
					return undefined;
					}});

				
				
			
/*
  window.navigator.mimeTypes = {
   length: 3,
   namedItem: function(){},
 filename: function(){},
    index: function(){}
}
*/


	
				
	
									 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					try { processFunctions(frame); } catch (err) { /* do nothing*/ }
					return idoc.apply(this);
				}
			}
		});



	 
}());
	(function() { 


	var a = Node.prototype.addEventListener;
	 Node.prototype.addEventListener = function(e) {
   if (e !== 'visibilitychange' && e !== 'webkitvisibilitychange' && e !== 'blur' && e !== 'focusin' 
   && e !== 'focusout' && e !== 'visibilitychange-hidden' && e !== 'visibilitychange-visibile' && e !== 'message' 
   && e !== 'pageshow' && e !== 'pagehide' && e !== 'focus' && e !== 'onblur' && e !== 'onfocus' 
   && e !== 'DOMFocusIn' && e !== 'hide' && e !== 'mousemove' && e !== 'paste' && e !== 'beforepaste'
   && e !== 'unhandledrejection' && e !== 'hashchange' && e !== 'resize' && e !== 'error' && e !== 'onerror'
   && e !== 'copy' && e !== 'popstate' && e !== 'orientationchange'  && e !== 'scroll' 
   && e !== 'MSFullscreenChange' && e !== 'fullscreenchange' && e !== 'webkitfullscreenchange' 
   && e !== 'mousewheel' && e !== 'auxclick' && e !== 'change' && e !== 'selectionchange' 
   && e !== 'keyup'  && e !== 'onabort' && e !== 'beforeunload' && e !== 'unload' && e !== 'onbeforecut' 
   && e !== 'onbeforeactivate' && e !== 'onafterprint' && e !== 'onbeforeprint' && e !== 'onbeforedeactivate'
   && e !== 'oncontextmenu' && e !== 'ondrag' && e !== 'onresizeend' && e !== 'onreset' && e !== 'onstop' 
   && e !== 'onhelp' && e !== 'onbeforeeditfocus' && e !== 'oncut' && e !== 'resizeBy' && e !== 'resizeTo'  
   && e !== 'alert' && e !== 'DOMMouseSroll' && e !== 'offline' && e !== 'mozfullsreenchange' 
   && e !== 'textInput'  && e !== 'dragenter' && e !== 'touchend' && e !== 'zoom' && e !== 'focus'
   && e !== 'IntentMediaRefresh' && e !== 'touchstart' && e !== 'swipe-verticle' && e !== 'webkitAnimationEnd' && e !== 'touchcancel' 
   && e !== 'pan-horizontal'  && e !== 'pan-verticle'  && e !== 'mouseover'  && e !== 'pointerup' 
    && e !== 'pointerleave'  && e !== 'oTransitionEnd' && e !== 'message' && e !== 'live' && e !== 'dblclick' 
   && e !== 'doubleTap' && e !== 'MSPointerMove' && e !== 'pointerdown' && e !== 'dblclick' && e !== 'onMouseMoveCapture' 
  && e !== 'onMouseMoveCapture' && e !== 'onMouseDownCapture' && e !== 'onDoubleClick'  && e !== 'onDoubleClick'  
  && e !== 'createImageBitmap' && e !== 'blink' && e !== 'selenium-evaluate' && e !== 'webdriver-evaluate' && e !== 'webdriverCommand'
  && e !== 'webdriver-evaluate-response' && e !== 'devicemotion' && e !== 'wheel' && e !== 'mouseleave' && e !== 'ftr;dt' && e !== 'driver-evaluate' 
  && e !== 'load'  && e !== 'DOMAutoComplete' && e !== 'cut'  && e !== 'bxPathChange' && e !== 'blur,' && e !== 'backgroundImage'
  && e !== 'keydown' && e !== 'keypress' && e !== 'remove' && ebpb !== 'mouseout' && ebpb !== 'pointerover' && ebpb !== 'pointerout' && ebpb !== 'onunload'
 ) {
	   
	   a.apply(this, arguments);
	   }}
	   
	    window.Document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
	   }
	  
	   window.Document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }
	   
	      window.document.hidden	 = function (text) {
		   
console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

	      window.document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

     document.visibilityState = function (text) {
			console.log('Browser Plugs blocked an attempt to view the visibility state of the page');
return 'visible'; 
}

  
	      document.hidden	 = function (text) {
		   console.log('Browser Plugs blocked an attempt to find out if the page was hidden');
return false; 
	   }

})();




//window.requestAnimationFrame(step);
//var oldrequestAnimationFrame = String.prototype.charAt;

 window.requestAnimationFrame = function now(frame) {
    return 0;
  };
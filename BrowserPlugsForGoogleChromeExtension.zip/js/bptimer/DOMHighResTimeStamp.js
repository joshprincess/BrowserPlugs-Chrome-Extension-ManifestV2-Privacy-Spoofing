var oldResAt = Type.prototype.DOMHighResTimeStamp;
Type.prototype.DOMHighResTimeStamp = function(timestamp) {

			var bpTheRandomChange = Math.floor(Math.random() * 57) + 65;
			var bpCombinedNewTimestamp = oldResAt + bpTheRandomChange;
	return bpCombinedNewTimestamp;


}
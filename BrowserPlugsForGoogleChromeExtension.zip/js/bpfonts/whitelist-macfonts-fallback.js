var pvft = '(' + function () {
	'use strict';
	function defineobjectproperty(val, e, c, w) {
		// Makes an object describing a property
		return {
			value: val,
			enumerable: !!e,
			configurable: !!c,
			writable: !!w
		}
	}
	
	

	
	
	var originalStyleSetProperty = CSSStyleDeclaration.prototype.setProperty
	var originalSetAttrib = Element.prototype.setAttribute
	var originalNodeAppendChild = Node.prototype.appendChild

			var DEFAULT = 'auto';
		
   var baseFonts = ["default"]
   
		  var FontWhiteList = ["default","sans-serif","serif","monospace","cursive","fantasy","Apple Braille Outline 6 Dot","Apple Braille Outline 8 Dot","Apple Braille Pinpoint 6 Dot","Apple Braille Pinpoint 8 Dot","Apple Braille","Apple Symbols","AppleGothic","AquaKana","Courier","Geeza Pro Bold","Geeza Pro","Geneva","HelveLTMM","Helvetica LT MM","Helvetica","HelveticaNeue","Hiragino Kaku Gothic ProN W3","Hiragino Kaku Gothic ProN W6","Hiragino Mincho ProN W3","Hiragino Mincho ProN W6","Keyboard","LastResort","LiHei Pro","LucidaGrande","Menlo","Monaco","STHeiti","STHeiti Light","STXihei","Symbol","Thonburi","ThonburiBold","Times LT MM","Times","TimesLTMM","ZapfDingbats","AmericanTypewriter","Andale Mono","Apple Chancery","Apple LiGothic Medium","Arial Black","Arial Bold Italic","Arial Bold","Arial Italic","Arial Narrow Bold Italic","Arial Narrow Bold","Arial Narrow Italic","Arial Narrow","Arial Rounded Bold","Arial Unicode","Arial","Baskerville","BigCaslon","Brush Script","Chalkboard","Chalkduster","Cochin","Comic Sans MS Bold","Comic Sans MS","Copperplate","Courier New Bold Italic","Courier New Bold","Courier New Italic","Courier New","Didot","Futura","Georgia Bold Italic","Georgia Bold","Georgia Italic","Georgia","GillSans","Hei","Herculanum","Hiragino Kaku Gothic Pro W3","Hiragino Kaku Gothic Pro W6","Hiragino Kaku Gothic Std W8","Hiragino Kaku Gothic StdN W8","Hiragino Maru Gothic Pro W4","Hiragino Maru Gothic ProN W4","Hiragino Mincho Pro W3","Hiragino Mincho Pro W6","Hoefler Text","Hoefler Text Ornaments","Impact","Kai","MarkerFelt","Microsoft Sans Serif","Optima","Osaka","OsakaMono","Papyrus","Skia","Tahoma Bold","Tahoma","Times New Roman Bold Italic","Times New Roman Bold","Times New Roman Italic","Times New Roman","Trebuchet MS Bold Italic","Trebuchet MS Bold","Trebuchet MS Italic","Trebuchet MS","Verdana Bold Italic","Verdana Bold","Verdana Italic","Verdana","Webdings","Wingdings 2","Wingdings 3","Wingdings","Zapfino"].map(function(x){return x.toLowerCase()})
		  

		var keywords = ["default","sans-serif","serif","monospace","cursive","fantasy","inherit","auto","!important"]
		

	baseFonts.push.apply(baseFonts, FontWhiteList)
	baseFonts.push.apply(baseFonts, keywords)




	function getAllowedFontFamily(family) {
		var fonts = family.replace(/"|'/g,'').split(',')
		var allowedFonts = fonts.filter(function(font) {
			if(font && font.length) {
				var normalised = font.trim().toLowerCase()
				// Allow base fonts
				for(var allowed of baseFonts)
					if(normalised == allowed) return true
				// Allow web fonts
				for (var allowed of document.fonts.values())
					if(normalised == allowed) return true
			}
		})
		return allowedFonts.map(function(f){
			var trimmed = f.trim()
			return ~trimmed.indexOf(' ') ? "'" + trimmed + "'" : trimmed
		}).join(", ")
	}
	

	function modifiedCssSetProperty(key, val) {
		if(key.toLowerCase() == 'font-family') {
			var keyresult = key.toLowerCase()
			//var allowed = getAllowedFontFamily(val)
			var allowed = getAllowedFontFamily(val)
			var oldFF = this.fontFamily
					
			return originalStyleSetProperty.call(this, 'font-family', allowed || DEFAULT)
		}
		return originalStyleSetProperty.call(this, key, val)
	}
	
	function makeModifiedSetCssText(originalSetCssText) {
		return function modifiedSetCssText(css) {
			var fontFamilyMatch = css.match(/\b(?:font-family:([^;]+)(?:;|$))/i)
			if(fontFamilyMatch && fontFamilyMatch.length == 1) {
				css = css.replace(/\b(font-family:[^;]+(;|$))/i, '').trim()
				var allowed = getAllowedFontFamily(fontFamilyMatch[1]) || DEFAULT
				if(css.length && css[css.length - 1] != ';')
					css += ';'
				css += "font-family: " + allowed + ";"
			}
			return originalSetCssText.call(this, css)
		}
	}
	
	var modifiedSetAttribute = (function() {
		var innerModify = makeModifiedSetCssText(function (val) {
			return originalSetAttrib.call(this, 'style', val)
		})
		return function modifiedSetAttribute(key, val) {
			if(key.toLowerCase() == 'style') {
				return innerModify.call(this, val)
			}
			return originalSetAttrib.call(this, key, val)
		}
	})();
	
	function makeModifiedInnerHTML(originalInnerHTML) {
		return function modifiedInnerHTML(html) {
			//Add as normal, then fix before returning
			var retval = originalInnerHTML.call(this, html)
			recursivelyModifyFonts(this.parentNode)
			return retval
		}
	}
	
	function recursivelyModifyFonts(elem) {
		if(elem) {
			if(elem.style && elem.style.fontFamily) {
				modifiedCssSetProperty.call(elem.style, 'font-family', elem.style.fontFamily) // Uses the special setter
			}
			if(elem.childNodes)
				elem.childNodes.forEach(recursivelyModifyFonts)
		}
		return elem
	}

	function modifiedAppend(child) {
		child = recursivelyModifyFonts(child)
		return originalNodeAppendChild.call(this, child)
	}
	
		
	var success = true
	
	function overrideFunc(obj, name, f) {
		try {
			Object.defineProperty(obj.prototype, name, defineobjectproperty(f, true))
		} catch(e) {success=false;}
	}
	
	
	function overrideSetter(obj, name, makeSetter) {
		try {
			var current = Object.getOwnPropertyDescriptor(obj.prototype, name)
			current.set = makeSetter(current.set)
			current.configurable = false
			Object.defineProperty(obj.prototype, name, current)
		} catch(e) {success=false;}
	}
	
	overrideFunc(Node, 'appendChild', modifiedAppend)
	overrideFunc(CSSStyleDeclaration, 'setProperty', modifiedCssSetProperty)
	overrideFunc(Element, 'setAttribute', modifiedSetAttribute)
	
		try {
		Object.defineProperty(CSSStyleDeclaration.prototype, "fontFamily", {
			set: function fontFamily(f) {
				modifiedCssSetProperty.call(this, 'font-family', f)
			},
			get: function fontFamily() {
				return this.getPropertyValue('font-family')
			}
		})
	} catch(e) {success=false;}
	
	
	overrideSetter(CSSStyleDeclaration,'cssText', makeModifiedSetCssText)
	overrideSetter(Element,'innerHTML', makeModifiedInnerHTML)
	overrideSetter(Element,'outerHTML', makeModifiedInnerHTML)
	
} + ')();';

var script = document.createElement('script')
script.textContent = pvft;
(document.head||document.documentElement).appendChild(script)
script.parentNode.removeChild(script)

	
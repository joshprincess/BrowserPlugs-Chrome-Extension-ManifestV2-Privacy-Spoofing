let option1 = {};
let option2 = {};
let option3 = {};
let option4 = {};
let option5 = {};
let option6 = {};
let option7 = {};
let option8 = {};




function fontmaster() {

function BrowserPlugsFontLink(link) {
var s = document.createElement('script');
s.src = chrome.extension.getURL(link);
s.onload = function() {
    this.remove();
};
  (document.head || document.documentElement).appendChild(s);
};


 chrome.storage.sync.get('settings', function(storage) {
    settings = storage.settings || {};
	

	option1 = settings.option1;
		option2 = settings.option2;
		option3 = settings.option3;
		option4 = settings.option4;
		option5 = settings.option5;
		option6 = settings.option6;
		option7 = settings.option7;
		option8 = settings.option8;
		
		if (option1 === '1') {
  
   	
		if (option1 === '1') {
  
   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts-fallback.js');


		  
	
	} else if (option2 === '1') {
		
	   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-macfonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-macfonts-fallback.js');	  




		  
		 
} else if (option3 === '1') {


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-win7fonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-win7fonts-fallback.js');	  



		  
		 
} else if (option4 === '1') {
		



   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-linuxfonts.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-linuxfonts-fallback.js');	  


		  

	

		} else if (option5 === '1') {
		
		


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist1.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist1-fallback.js');	  


		  
} else if (option6 === '1') {
		
		


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist2.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontlist2-fallback.js');	  





	
		  
		} else if (option7 === '1') {
		
		 


   if (!settings.allowfallback) BrowserPlugsFontLink('js/bpfonts/whitelist-fontrandom.js');
if (settings.allowfallback)  BrowserPlugsFontLink('js/bpfonts/whitelist-fontrandom-fallback.js');	  


		
	
} else if (option8 === '1') {
	
		 	 BrowserPlugsFontLink('js/bpfonts/whitelist-nofont.js');




		
	} else {
	  
BrowserPlugsFontLink('js/bpfonts/whitelist-win10fonts.js');



	
	}
		}
		
});

}


	/*
function audiomaster() {

 	  var saudio = document.createElement('script');
saudio.src = chrome.extension.getURL('js/bpblock/block-audioapi.js');
saudio.onload = function() {


(document.head||document.documentElement).appendChild(saudio);

}
} */
		(function () {
var bpfont = '(' + function () {
	'use strict';
	function defineobjectproperty(val, e, c, w) {
		// Makes an object describing a property
		return {
			value: val,
			enumerable: !!e,
			configurable: !!c,
			writable: !!w
		}
	}
	
	

	
	
	var originalStyleSetProperty = CSSStyleDeclaration.prototype.setProperty
	var originalSetAttrib = Element.prototype.setAttribute
	var originalNodeAppendChild = Node.prototype.appendChild

			var DEFAULT = 'auto';
	
  // var baseFonts = ["default"]
   var baseFonts = ["auto"]

		  var FontWhiteList = ["Arial","Calibri","Cambria","Cambria Math","Candara","Comic Sans MS","Comic Sans MS Bold","Comic Sans","Consolas","Constantia","Corbel","Courier New","Caurier Regular","Ebrima","Fixedsys Regular","Franklin Gothic","Gabriola Regular","Gadugi","Georgia","HoloLens MDL2 Assets Regular","Impact Regular","Javanese Text Regular","Leelawadee UI","Lucida Console Regular","Lucida Sans Unicode Regular","Malgun Gothic","Microsoft Himalaya Regular","Microsoft JhengHei","Microsoft JhengHei UI","Microsoft PhangsPa","Microsoft Sans Serif Regular","Microsoft Tai Le","Microsoft YaHei","Microsoft YaHei UI","Microsoft Yi Baiti Regular","MingLiU_HKSCS-ExtB Regular","MingLiu-ExtB Regular","Modern Regular","Mongolia Baiti Regular","MS Gothic Regular","MS PGothic Regular","MS Sans Serif Regular","MS Serif Regular","MS UI Gothic Regular","MV Boli Regular","Myanmar Text","Nimarla UI","MV Boli Regular","Myanmar Tet","Nirmala UI","NSimSun Regular","Palatino Linotype","PMingLiU-ExtB Regular","Roman Regular","Script Regular","Segoe MDL2 Assets Regular","Segoe Print","Segoe Script","Segoe UI","Segoe UI Emoji Regular","Segoe UI Historic Regular","Segoe UI Symbol Regular","SimSun Regular","SimSun-ExtB Regular","Sitka Banner","Sitka Display","Sitka Heading","Sitka Small","Sitka Subheading","Sitka Text","Small Fonts Regular","Sylfaen Regular","Symbol Regular","System Bold","Tahoma","Terminal","Times New Roman","Trebuchet MS","Verdana","Webdings Regular","Wingdings Regular","Yu Gothic","Yu Gothic UI","Arial","Arial Black","Calibri","Calibri Light","Cambria","Cambria Math","Candara","Comic Sans MS","Consolas","Constantia","Corbel","Courier","Courier New","Ebrima","Fixedsys","Franklin Gothic Medium","Gabriola","Gadugi","Georgia","HoloLens MDL2 Assets","Impact","Javanese Text","Leelawadee UI","Leelawadee UI Semilight","Lucida Console","Lucida Sans Unicode","MS Gothic","MS PGothic","MS Sans Serif","MS Serif","MS UI Gothic","MV Boli","Malgun Gothic","Malgun Gothic Semilight","Marlett","Microsoft Himalaya","Microsoft JhengHei","Microsoft JhengHei Light","Microsoft JhengHei UI","Microsoft JhengHei UI Light","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Sans Serif","Microsoft Tai Le","Microsoft YaHei","Microsoft YaHei Light","Microsoft YaHei UI","Microsoft YaHei UI Light","Microsoft Yi Baiti","MingLiU-ExtB","MingLiU_HKSCS-ExtB","Modern","Mongolian Baiti","Myanmar Text","NSimSun","Nirmala UI","Nirmala UI Semilight","PMingLiU-ExtB","Palatino Linotype","Roman","Script","Segoe MDL2 Assets","Segoe Print","Segoe Script","Segoe UI","Segoe UI Black","Segoe UI Emoji","Segoe UI Historic","Segoe UI Light","Segoe UI Semibold","Segoe UI Semilight","Segoe UI Symbol","SimSun","SimSun-ExtB","Sitka Banner","Sitka Display","Sitka Heading","Sitka Small","Sitka Subheading","Sitka Text","Small Fonts","Sylfaen","Symbol","System","Tahoma","Terminal","Times New Roman","Trebuchet MS","Verdana","Webdings","Wingdings","Yu Gothic","Yu Gothic Light","Yu Gothic Medium","Yu Gothic UI","Yu Gothic UI Light","Yu Gothic UI Semibold","Yu Gothic UI Semilight"].map(function(x){return x.toLowerCase()});
		  

		var keywords = ["inherit", "auto", "default", "!Important"]
		

	baseFonts.push.apply(baseFonts, FontWhiteList)
	baseFonts.push.apply(baseFonts, keywords)




	function getAllowedFontFamily(family) {
		var fonts = family.replace(/"|'/g,'').split(',')
		var allowedFonts = fonts.filter(function(font) {
			if(font && font.length) {
				var normalised = font.trim().toLowerCase()
				// Allow base fonts
				for(var allowed of baseFonts)
					if(normalised == allowed) return true
				// Allow web fonts
				for (var allowed of document.fonts.values())
					if(normalised == allowed) return true
			}
		})
		return allowedFonts.map(function(f){
			var trimmed = f.trim()
			return ~trimmed.indexOf(' ') ? "'" + trimmed + "'" : trimmed
		}).join(", ")
	}
	

	function modifiedCssSetProperty(key, val) {
		if(key.toLowerCase() == 'font-family') {
			var keyresult = key.toLowerCase()
			var allowed = getAllowedFontFamily(val)
			var oldFF = this.fontFamily
			return originalStyleSetProperty.call(this, 'font-family', allowed || DEFAULT)
		}
		return originalStyleSetProperty.call(this, key, val)
	}
	
	function makeModifiedSetCssText(originalSetCssText) {
		return function modifiedSetCssText(css) {
			var fontFamilyMatch = css.match(/\b(?:font-family:([^;]+)(?:;|$))/i)
			if(fontFamilyMatch && fontFamilyMatch.length == 1) {
				css = css.replace(/\b(font-family:[^;]+(;|$))/i, '').trim()
				var allowed = getAllowedFontFamily(fontFamilyMatch[1]) || DEFAULT
				if(css.length && css[css.length - 1] != ';')
					css += ';'
				css += "font-family: " + allowed + ";"
			}
			return originalSetCssText.call(this, css)
		}
	}
	
	var modifiedSetAttribute = (function() {
		var innerModify = makeModifiedSetCssText(function (val) {
			return originalSetAttrib.call(this, 'style', val)
		})
		return function modifiedSetAttribute(key, val) {
			if(key.toLowerCase() == 'style') {
				return innerModify.call(this, val)
			}
			return originalSetAttrib.call(this, key, val)
		}
	})();
	
	function makeModifiedInnerHTML(originalInnerHTML) {
		return function modifiedInnerHTML(html) {
			//Add as normal, then fix before returning
			var retval = originalInnerHTML.call(this, html)
			recursivelyModifyFonts(this.parentNode)
			return retval
		}
	}
	
	function recursivelyModifyFonts(elem) {
		if(elem) {
			if(elem.style && elem.style.fontFamily) {
				modifiedCssSetProperty.call(elem.style, 'font-family', elem.style.fontFamily) // Uses the special setter
			}
			if(elem.childNodes)
				elem.childNodes.forEach(recursivelyModifyFonts)
		}
		return elem
	}

	function modifiedAppend(child) {
		child = recursivelyModifyFonts(child)
		return originalNodeAppendChild.call(this, child)
	}
	
		
	var success = true
	
	function overrideFunc(obj, name, f) {
		try {
			Object.defineProperty(obj.prototype, name, defineobjectproperty(f, true))
		} catch(e) {success=false;}
	}
	
	
	function overrideSetter(obj, name, makeSetter) {
		try {
			var current = Object.getOwnPropertyDescriptor(obj.prototype, name)
			current.set = makeSetter(current.set)
			current.configurable = false
			Object.defineProperty(obj.prototype, name, current)
		} catch(e) {success=false;}
	}
	
	overrideFunc(Node, 'appendChild', modifiedAppend)
	overrideFunc(CSSStyleDeclaration, 'setProperty', modifiedCssSetProperty)
	overrideFunc(Element, 'setAttribute', modifiedSetAttribute)
	
		try {
		Object.defineProperty(CSSStyleDeclaration.prototype, "fontFamily", {
			set: function fontFamily(f) {
				modifiedCssSetProperty.call(this, 'font-family', f)
			},
			get: function fontFamily() {
				return this.getPropertyValue('font-family')
			}
		})
	} catch(e) {success=false;}
	
	
	overrideSetter(CSSStyleDeclaration,'cssText', makeModifiedSetCssText)
	overrideSetter(Element,'innerHTML', makeModifiedInnerHTML)
	overrideSetter(Element,'outerHTML', makeModifiedInnerHTML)
	 document.documentElement.dataset.bpsecure = "true";
	 
} + ')();';

if(document.documentElement) {
var script = document.createElement('script')
script.textContent = bpfont;
(document.documentElement).appendChild(script)
script.parentNode.removeChild(script)
}

}());
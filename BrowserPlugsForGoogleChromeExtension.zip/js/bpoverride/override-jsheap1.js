(function () {
'use strict';
					var faketimestamp = Math.round((new Date()).getTime() / 1);
	var faketimestamp2 = faketimestamp + Math.floor(Math.random() * 15);
	var faketimestamp3 = faketimestamp2 + Math.floor(Math.random() * 200);
var faketimestamp4 = faketimestamp3 + Math.floor(Math.random() * 40);
var faketimestamp5 = faketimestamp4 + Math.floor(Math.random() * 800);
var faketimestamp6 = faketimestamp5 + Math.floor(Math.random() * 25);
var faketimestamp7 = faketimestamp6 + Math.floor(Math.random() * 5000);
var faketimestamp8 = faketimestamp7 + Math.floor(Math.random() * 8);
var faketimestampc =  Math.floor(Math.random() * 50000);
var faketimestampw = Math.floor(Math.random() * 1280000000) + 793000000;
var faketimestampx = Math.floor(Math.random() * 50005030) + 59300000;
var faketimestampg = Math.floor(Math.random() * 37100000) + 17100000;

 // console.log('realtimer: ' + ' | faketimestamp : ' + faketimestamp + ' | ' + faketimestamp3 + ' | ' + faketimestamp4); 
function processFunctions(scope) {


				
					scope.Object.defineProperty(window.performance.memory.__proto__, "jsHeapSizeLimit", {enumerable: true, configurable: true, get: function() {
						
									return [1280000000,1136000000,2107857923,1136000000,2217857052,1620000000,1136000000,2173634263,faketimestampw,faketimestampw,faketimestampw,faketimestampw][Math.floor(Math.random() * 12)];

	
				}});
				
			
						scope.Object.defineProperty(window.performance.memory.__proto__, "totalJSHeapSize", {enumerable: true, configurable: true, get: function() {
						
								return [29400000,84152320,56800000,29400000,29400000,1530000000,faketimestampx,faketimestampx][Math.floor(Math.random() * 8)];

	
				}});
					

						
				
				scope.Object.defineProperty(window.performance.memory.__proto__, "usedJSHeapSize", {enumerable: true, configurable: true, get: function() {
							   console.log('window.performance.memory.__proto__, usedJSHeapSize on ' + window.location.hostname);

						return [13400000,20500000,16100000,17100000,47400000,faketimestampg,faketimestampg,faketimestampg][Math.floor(Math.random() * 8)];

	
				}});
				
				
			

				/* Imported /*
				
				
window.performance.memory.totalJSHeapSize = function() {
	   console.log('5a Browser Plugs firewall blocks totalJSHeapSize on ' + window.location.hostname);

	return [29400000,84152320,56800000,11900000,47400000][Math.floor(Math.random() * 5)];
	
}
//1280000000 793000000  |   2217857988 / 56365056 / 25475440
window.performance.memory.jsHeapSizeLimit = function() {
	   console.log('4a Browser Plugs firewall blocks totalJSHeapSize on ' + window.location.hostname);

	return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
}

performance.memory.__proto__.constructor.jsHeapSizeLimit = function() {
	   console.log('4a Browser Plugs firewall blocks performance.memory.__proto__.constructor.jsHeapSizeLimit on ' + window.location.hostname);

	return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
}

performance.memory.__proto__.constructor.prototype.constructor.prototype.jsHeapSizeLimit = function() {
											return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
				}
				
				performance.memory.__proto__.constructor.prototype.constructor.prototype.constructor.prototype.jsHeapSizeLimit = function() {
				
				
											return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
				}
				
					window.performance.memory.__proto__.usedJSHeapSize 	 = function() 	
				{
	return [29400000,84152320,56800000,11900000,47400000][Math.floor(Math.random() * 5)];
				}
				
					performance.memory.__proto__.usedJSHeapSize 	 = function() 
				{
	return [29400000,84152320,56800000,11900000,47400000][Math.floor(Math.random() * 5)];
				}
				
				
						performance.memory.__proto__.jsHeapSizeLimit		 = function() {
				
											return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
				}
				
				performance.memory.__proto__.totalJSHeapSize		 = function() 
				{
	return [29400000,84152320,156872400,11900000,47400000,47400000,10768334][Math.floor(Math.random() * 7)];
				}

				
				performance.memory.__proto__.constructor.prototype.totalJSHeapSize = function() {
											return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
				}
				
						window.performance.memory.__proto__.constructor.prototype.totalJSHeapSize = function() {
											return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
				}

				
performance.memory = function() {
	   console.log('15 Browser Plugs firewall blocks totalJSHeapSize on ' + window.location.hostname);

	return [29400000,84152320,56800000,11900000,47400000][Math.floor(Math.random() * 5)];
}

performance.memory.prototype = function() {
	   console.log('Browser Plugs firewall blocks prototype memory on ' + window.location.hostname);

	return [793000000,1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 12)];
}


window.performance.memory.totalJSHeapSize = function() {
	   console.log('h6 Browser Plugs firewall blocks totalJSHeapSize on ' + window.location.hostname);
	return [29400000,84152320,156872400,11900000,47400000,17680334][Math.floor(Math.random() * 5)];
}

window.performance.memory.jsHeapSizeLimit = function() {
	   console.log('y6 Browser Plugs firewall blocks jsHeapSizeLimit on ' + window.location.hostname);
	return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
}
*/
				
				
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});




}());

	performance.memory.__proto__.constructor.jsHeapSizeLimit = function() {
	   console.log('4a Browser Plugs firewall blocks performance.memory.__proto__.constructor.jsHeapSizeLimit on ' + window.location.hostname);

	return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
}

				performance.memory = (function() {
 console.log('H3 Browser Plugs firewall randomizes performance.memory on ' + window.location.hostname);   
   window._policy = true;
	return [1280000000,1280000000,1280000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 9)];

})();
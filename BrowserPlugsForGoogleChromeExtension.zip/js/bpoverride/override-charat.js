

if (window.location.hostname !== 'www.google.com' && window.location.hostname !== 'chrome.google.com' && window.location.protocol !== 'chrome:' && window.location.protocol !== 'chrome' && window.location.protocol !== 'chrome-extension:' && window.location.protocol !== 'devtools:') {

	
var oldCharAt = String.prototype.charAt;
String.prototype.charAt = function(index) {

if (index === 250||index === 151||index === 85||index === 86||index === 87||index === 88||index === 89||index === 90||index === 91||index ==250||index === 500) {
	
			var bpTheAlphabet = Math.floor(Math.random() * 57) + 65;
			
	return bpTheAlphabet;


}
else {
 if (index !== 0) console.log('CharAt Index '  + index + ' on ' + window.location.hostname + window.location.pathname);
return oldCharAt.apply(this, arguments); 

}

String.prototype.charAt.toUpperCase = function(index) { return bpTheAlphabet.toUpperCase(); }
String.prototype.charAt.toLowerCase = function(index) { return bpTheAlphabet.toLowerCase(); }
  
}

var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {

if (index === 0||index === -1||index === -2||index === 176||index === 177||index === 178) {

	 return oldcharCodeAt.apply(this, arguments); 

}
else {
	/*	var bpFullLatin = Math.floor(Math.random() * 127) + 1; */
/* var bpMath = Math.floor(Math.random() * 57) + 65;  */
	var bpABC = Math.floor(Math.random() * 57) + 65;
	console.log('NEW CodeCharAt: ' + bpABC + ' oldcharCodeAt Index '  + index + ' on ' + window.location.hostname + window.location.pathname); 

				return bpABC;
}
}
	}
	else {
		
	}
	String.prototype.charCodeAt.toUpperCase = function(index) { return bpABC.toUpperCase(); }
String.prototype.charCodeAt.toLowerCase = function(index) { return bpABC.toLowerCase(); }
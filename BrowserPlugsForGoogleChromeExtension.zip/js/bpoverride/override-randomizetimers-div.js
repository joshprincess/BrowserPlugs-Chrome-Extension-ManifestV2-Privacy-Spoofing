(function () {
	
function processFunctions(scope) {
	

				var faketimestamp = Math.round((new Date()).getTime() / 1);
	var faketimestamp2 = faketimestamp + Math.floor(Math.random() * 15);
	var faketimestamp3 = faketimestamp2 + Math.floor(Math.random() * 200);
var faketimestamp4 = faketimestamp3 + Math.floor(Math.random() * 40);
var faketimestamp5 = faketimestamp4 + Math.floor(Math.random() * 800);
var faketimestamp6 = faketimestamp5 + Math.floor(Math.random() * 25);
var faketimestamp7 = faketimestamp6 + Math.floor(Math.random() * 5000);
var faketimestamp8 = faketimestamp7 + Math.floor(Math.random() * 8);
// console.log('realtimer: ' + ' | faketimestamp : ' + faketimestamp + ' | ' + faketimestamp3 + ' | ' + faketimestamp4); 



				scope.Object.defineProperty(window.performance.timing, "loadEventStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'loadEventStart';
					browserplugins_triggerblock.title = 'loadEventStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp7][Math.floor(Math.random() * 1)];
				}})
				
					scope.Object.defineProperty(window.performance.timing, "requestStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-requestStart';
					browserplugins_triggerblock.title = 'requestStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp2][Math.floor(Math.random() * 1)];
				}})
				
					scope.Object.defineProperty(window.performance.timing, "redirectStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-redirectStart';
					browserplugins_triggerblock.title = 'redirectStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return 0;
				}})
				
					scope.Object.defineProperty(window.performance.timing, "redirectEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-redirectEnd';
					browserplugins_triggerblock.title = 'redirectEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return 0;
				}})
				/*
						scope.Object.defineProperty(window.performance.navigation, "redirectCount", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-performance-redirectCount';
					browserplugins_triggerblock.title = 'redirectCount';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [0][Math.floor(Math.random() * 1)];
				}})
				*/
		
				
								scope.Object.defineProperty(window.performance.timing, "loadEventEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-loadEventEnd';
					browserplugins_triggerblock.title = 'loadEventEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp8][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domComplete", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domComplete';
					browserplugins_triggerblock.title = 'domComplete';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp7][Math.floor(Math.random() * 1)];
				}})
				
				scope.Object.defineProperty(window.performance.navigation, "navigationStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-navigationStart';
					browserplugins_triggerblock.title = 'navigationStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
						}})
					/*
					scope.Object.defineProperty(window.performance.timing, "navigationStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-navigationStart';
					browserplugins_triggerblock.title = 'navigationStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
				*/
					scope.Object.defineProperty(window.performance.timing, "domInteractive", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domInteractive';
					browserplugins_triggerblock.title = 'domInteractive';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp5][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "fetchStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-fetchStart';
					browserplugins_triggerblock.title = 'fetchStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})

				scope.Object.defineProperty(window.performance.timing, "domainLookupStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domainLookupStart';
					browserplugins_triggerblock.title = 'domainLookupStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domainLookupEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domainLookupEnd';
					browserplugins_triggerblock.title = 'domainLookupEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "connectStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-connectStart';
					browserplugins_triggerblock.title = 'connectStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
						
						scope.Object.defineProperty(window.performance.timing, "secureConnectionStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-secureConnectionStart';
					browserplugins_triggerblock.title = 'secureConnectionStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
			
						scope.Object.defineProperty(window.performance.timing, "connectEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-connectEnd';
					browserplugins_triggerblock.title = 'connectEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "responseStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-responseStart';
					browserplugins_triggerblock.title = 'responseEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "responseEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-responseEnd';
					browserplugins_triggerblock.title = 'responseEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp4][Math.floor(Math.random() * 1)];
				}})
				
				scope.Object.defineProperty(window.performance.timing, "domLoading", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domLoading';
					browserplugins_triggerblock.title = 'domLoading';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domContentLoadedEventStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domContentLoadedEventStart';
					browserplugins_triggerblock.title = 'domContentLoadedEventStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domContentLoadedEventEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domContentLoadedEventEnd';
					browserplugins_triggerblock.title = 'domContentLoadedEventEnd';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
						scope.Object.defineProperty(window.performance.timing, "domContentunloadEventStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domContentunloadEventStart';
					browserplugins_triggerblock.title = 'domContentunloadEventStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}});
				
						scope.Object.defineProperty(window.performance.timing, "unloadEventStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-unloadEventStart';
					browserplugins_triggerblock.title = 'unloadEventStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
	
				}});
	scope.Object.defineProperty(window.performance.timing, "unloadEventEnd", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-domContentunloadEventStart';
					browserplugins_triggerblock.title = 'domContentunloadEventStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
	
				}});
				
				
					scope.Object.defineProperty(window.performance.timing, "workerStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-workerStart';
					browserplugins_triggerblock.title = 'workerStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
	
				}});
				
					scope.Object.defineProperty(window.performance.memory, "totalJSHeapSize", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-totalJSHeapSize';
					browserplugins_triggerblock.title = 'totalJSHeapSize';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [29400000,84152320,56800000,11900000,47400000,][Math.floor(Math.random() * 5)];
	
				}});
				
					scope.Object.defineProperty(window.performance.memory, "jsHeapSizeLimit", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-jsHeapSizeLimit';
					browserplugins_triggerblock.title = 'jsHeapSizeLimit';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [1280000000,1280000000,1280000000,793000000,793000000,1620000000,1530000000,2217857988,1136000000,2190000000][Math.floor(Math.random() * 10)];
	
				}});
				
				
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});




}());
(function () {
	
function processFunctions(scope) {
			scope.Object.defineProperty(window.screen, "width", {enumerable: true, configurable: true, get: function(){return 1920; }}); 
			
			scope.Object.defineProperty(window.screen, "height", {enumerable: true, configurable: true, get: function(){return 1080; }}); 
			
   
 scope.Object.defineProperty(window.screen, "availHeight", {enumerable: true, configurable: true, get: function(){return [1040,1040][Math.floor(Math.random() * 2)] }});
  scope.Object.defineProperty(window.screen, "availWidth", {enumerable: true, configurable: true, get: function(){return [1920,1920][Math.floor(Math.random() * 2)] }});
  			
					 scope.Object.defineProperty(window.screen, "colorDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
						  scope.Object.defineProperty(window.screen, "pixelDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
		   
		    scope.Object.defineProperty(window.screen, "availLeft", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }});
  scope.Object.defineProperty(window.screen, "availTop", {enumerable: true, configurable: true, get: function(){return [0,0][Math.floor(Math.random() * 2)] }});
  			
		   
			 scope.Object.defineProperty(window.screen, "innerWidth", {enumerable: true, configurable: true, get: function(){return [1914,1914][Math.floor(Math.random() * 2)] }});
  scope.Object.defineProperty(window.screen, "innerHeight", {enumerable: true, configurable: true, get: function(){return [1014,1014][Math.floor(Math.random() * 2)] }});
  			
		innerWidth
		
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
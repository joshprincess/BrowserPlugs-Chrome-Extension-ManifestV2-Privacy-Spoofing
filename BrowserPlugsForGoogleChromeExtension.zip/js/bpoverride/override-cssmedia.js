function getCSSMediaRules() {
    var stylesheets = document.styleSheets;
    var mediaRules = new Array();

    // loop through all CSS files
    for (var i in stylesheets) {
        if (stylesheets.hasOwnProperty(i)) {
            var stylesheets = stylesheets[i];
            var stylesheetRules = stylesheets.cssRules;
            // for every CSS file, loop through all CSS rules
            for (var i in stylesheetRules) {
                if (stylesheetRules.hasOwnProperty(i)) {
                    var stylesheetRule = stylesheetRules[i];
                    // check CSS rule is a type 4 'MEDIA_RULE'
	
                    if (stylesheetRule.type == 4) {
				
                            mediaRules.push(stylesheetRule);

                    }
                }
            }
        }
    }
	console.log ('[BPCSS] mediaRules (Detailed Log is ON)');

    return mediaRules;
	
}
function replaceMaxDeviceWidth(rule) {
    rule.media.mediaText = rule.media.mediaText.replace('max-device-width', 'max-width');
}


console.log ('[BrowserPlugs Detailed Log Mode - document.styleSheets]');
console.log(document.styleSheets[0]);
/* console.log(document.styleSheets[0].media.mediaText); */


getCSSMediaRules();
replaceMaxDeviceWidth(5022);

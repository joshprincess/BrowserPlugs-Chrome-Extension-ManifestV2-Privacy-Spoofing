(function() {
    'use strict';

    function fakeCharging1() {
      return true;
    }
    function fakeChargingTime1() {
      return 0;
    }
    function fakeDischargingTime1() {
      return Infinity;
    }
    function fakeLevel1() {
      return 1.0;
    }


    const fakeChargingValue1        = fakeCharging1();
    const fakeChargingTimeValue1    = fakeChargingTime1();
    const fakeDischargingValue1     = fakeDischargingTime1();
    const fakeLevelValue1           = fakeLevel1();

    Object.defineProperties(BatteryManager.prototype, {
        charging: {
            configurable: true,
            enumerable: true,
            get: function getCharging() {

                 return fakeChargingValue1;
            }
        },

        
        chargingTime: {
            configurable: true,
            enumerable: true,
            get: function getChargingTime() {

                return fakeChargingTimeValue1;
            }
        },

        dischargingTime: {
            configurable: true,
            enumerable: true,
            get: function getDischargingTime() {

                return fakeDischargingValue1;
            }
        },

        level: {
            configurable: true,
            enumerable: true,
            get: function getLevel() {

                return fakeLevelValue1;
            }
        }
    });
})();

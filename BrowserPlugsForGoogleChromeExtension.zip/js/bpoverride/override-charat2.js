// 




var injectrects = function () {
	
	
var oldCharAt = String.prototype.charAt;

String.prototype.charAt = function(index) {
			if (index == 1||index == 2||index == 3||index == 4||index == 5||index == 6||index == 7||index == -1||index == -2)  return oldCharAt.apply(this, arguments);
			
			var bpTheAlphabet = Math.floor(Math.random() * 57) + 65;

	if (index == 88||index == 57||index == 117) return bpTheAlphabet;

		//	console.log('charAt index String Randomized ' + bpTheAlphabet);

		String.prototype.charAt.toUpperCase = function(index) { return bpTheAlphabet.toUpperCase(); }
		String.prototype.charAt.CreateListFromArrayLike = function(index) { return bpTheAlphabet(); }

	return oldCharAt.apply(this, arguments);


}

var oldcharCodeAt = String.prototype.charCodeAt;
String.prototype.charCodeAt = function(index) {
if (index == 1||index == 0||index == 2||index == 3||index == -1||index == 4||index == 73||index == -2||index == 88||index == 103) return oldcharCodeAt.apply(this, arguments);

	var bpABC = Math.floor(Math.random() * 57) + 65;

//String.prototype.charCodeAt.toUpperCase = function(index) { return bpABC.toUpperCase(); }
String.prototype.charCodeAt.toLowerCase = function(index) {
console.log('CharCodeAt toLowerCase index String Randomized ' + bpABC + ' index ' + index);
	return bpABC.toLowerCase(); }
	
			//	console.log('CharCodeAt index String Randomized ' + bpABC + ' index ' + index);
				return bpABC;

}
	

	
}




var injectrects2 = function () {

    const iframes = window.document.querySelectorAll("iframe[sandbox]");
    for (var i = 0; i < iframes.length; i++) {
      if (iframes[i].contentWindow) {
        if (iframes[i].contentWindow.String) {
          iframes[i].contentWindow.String.prototype.charCodeAt = String.prototype['charCodeAt'];;
   
        }
      }
    }
}

  var script_1 = document.createElement('script');
script_1.textContent = "(" + injectrects + ")()";
try {document.documentElement.appendChild(script_1);} catch(e) { }



if (document.documentElement.dataset.bpsecure !== "true") {
console.log('document.documentElement.dataset.bpsecure trying iframe insert on ' + window.location.hostname) 

 var script_2 = document.createElement('script');
 // script_2.textContent = ``;
 script_2.textContent = "(" + injectrects2 + ")()";
try {window.document.documentElement.appendChild(script_2);} catch(e) {}
  
}
  
  


(function () {
	
var BPCode = "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe'); "+
               "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {} }); "+
               "try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 1 }); } catch(e) {}"+
			   "document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');"+
			   "for (i=0; i<iFrames.length; i++) try { Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {} }); "+
			    "try { Object.defineProperty(clientInformation, 'deviceMemory', { value: 4 }); } catch(e) {}";
			  
var script = document.createElement("script");
script.type = "text/javascript";
script.textContent = BPCode;
document.documentElement.appendChild(script);
script.onload = () => {
    this.remove();
};


}());


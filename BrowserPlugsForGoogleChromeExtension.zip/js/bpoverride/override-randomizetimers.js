(function () {
'use strict';
					var faketimestamp = Math.round((new Date()).getTime() / 1);
	var faketimestamp2 = faketimestamp + Math.floor(Math.random() * 15);
	var faketimestamp3 = faketimestamp2 + Math.floor(Math.random() * 200);
var faketimestamp4 = faketimestamp3 + Math.floor(Math.random() * 40);
var faketimestamp5 = faketimestamp4 + Math.floor(Math.random() * 800);
var faketimestamp6 = faketimestamp5 + Math.floor(Math.random() * 25);
var faketimestamp7 = faketimestamp6 + Math.floor(Math.random() * 5000);
var faketimestamp8 = faketimestamp7 + Math.floor(Math.random() * 8);
var faketimestampc =  Math.floor(Math.random() * 50000);
var faketimestampw = Math.floor(Math.random() * 1280000000) + 793000000;
var faketimestampx = Math.floor(Math.random() * 50005030) + 59300000;
var faketimestampg = Math.floor(Math.random() * 37100000) + 17100000;

 // console.log('realtimer: ' + ' | faketimestamp : ' + faketimestamp + ' | ' + faketimestamp3 + ' | ' + faketimestamp4); 
function processFunctions(scope) {

	scope.Object.defineProperty(window.Performance, "timeOrigin", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp2,faketimestamp,faketimestamp2,faketimestamp2,faketimestamp][Math.floor(Math.random() * 5)];
				}})

				scope.Object.defineProperty(window.performance.timing, "loadEventStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp5][Math.floor(Math.random() * 1)];
				}})
				
					scope.Object.defineProperty(window.performance.timing, "requestStart", {enumerable: true, configurable: true, get: function() {
				
						return [faketimestamp2][Math.floor(Math.random() * 1)];
				}})
				
					scope.Object.defineProperty(window.performance.timing, "redirectStart", {enumerable: true, configurable: true, get: function() {
					
						return 0;
				}})
				
					scope.Object.defineProperty(window.performance.timing, "redirectEnd", {enumerable: true, configurable: true, get: function() {
				
						return 0;
				}})
				/*
						scope.Object.defineProperty(window.performance.navigation, "redirectCount", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'bp-performance-redirectCount';
					browserplugins_triggerblock.title = 'redirectCount';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [0][Math.floor(Math.random() * 1)];
				}})
				*/
		
				
								scope.Object.defineProperty(window.performance.timing, "loadEventEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp8][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domComplete", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp7][Math.floor(Math.random() * 1)];
				}})
				
				scope.Object.defineProperty(window.performance.navigation, "navigationStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
						}})
					/*
					scope.Object.defineProperty(window.performance.timing, "navigationStart", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-navigationStart';
					browserplugins_triggerblock.title = 'navigationStart';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
				*/
					scope.Object.defineProperty(window.performance.timing, "domInteractive", {enumerable: true, configurable: true, get: function() {
					
					
						return [faketimestamp5][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "fetchStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})

				scope.Object.defineProperty(window.performance.timing, "domainLookupStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domainLookupEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "connectStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
						
						scope.Object.defineProperty(window.performance.timing, "secureConnectionStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
			
						scope.Object.defineProperty(window.performance.timing, "connectEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "responseStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "responseEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp4][Math.floor(Math.random() * 1)];
				}})
				
				scope.Object.defineProperty(window.performance.timing, "domLoading", {enumerable: true, configurable: true, get: function() {
				
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domContentLoadedEventStart", {enumerable: true, configurable: true, get: function() {
				
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}})
					scope.Object.defineProperty(window.performance.timing, "domContentLoadedEventEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp3][Math.floor(Math.random() * 1)];
				}})
						scope.Object.defineProperty(window.performance.timing, "domContentunloadEventStart", {enumerable: true, configurable: true, get: function() {
				
						return [faketimestamp][Math.floor(Math.random() * 1)];
				}});
				
						scope.Object.defineProperty(window.performance.timing, "unloadEventStart", {enumerable: true, configurable: true, get: function() {
				
						return [faketimestamp][Math.floor(Math.random() * 1)];
	
				}});
				
	scope.Object.defineProperty(window.performance.timing, "unloadEventEnd", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp][Math.floor(Math.random() * 1)];
	
				}});
				
				
					scope.Object.defineProperty(window.performance.timing, "workerStart", {enumerable: true, configurable: true, get: function() {
					
						return [faketimestamp,faketimestamp,faketimestamp,faketimestamp2][Math.floor(Math.random() * 1)];
	
				}});
				
				
				
				/* max : 
				17100000
				
				
				793000000
				793000000
				793000000 
				1280000000
				1136000000
				1620000000
				  
				767557632
				
				totalJSHeapSize
				254000000
				35100000
				42100000
				767557632
				8244736
			
				usedJSHeapSize
				47400000
				 42100000
				2217857988
				13400000
				
				1280000000
				2190000000
				29400000
				793000000
				793000000
				35100000
				17100000
				35100000
				12700000
				20500000
				44700000
				16100000
				35100000
				
				
					scope.Object.defineProperty(window.performance.memory.__proto__, "jsHeapSizeLimit", {enumerable: true, configurable: true, get: function() {
						
									return [1280000000,1136000000,2107857923,1136000000,2217857052,1620000000,1136000000,2173634263,faketimestampw,faketimestampw,faketimestampw,faketimestampw][Math.floor(Math.random() * 12)];

	
				}});
				
			
						scope.Object.defineProperty(window.performance.memory.__proto__, "totalJSHeapSize", {enumerable: true, configurable: true, get: function() {
						
								return [29400000,84152320,56800000,29400000,29400000,1530000000,faketimestampx,faketimestampx][Math.floor(Math.random() * 8)];

	
				}});
					

						
				
				scope.Object.defineProperty(window.performance.memory.__proto__, "usedJSHeapSize", {enumerable: true, configurable: true, get: function() {
						
						return [13400000,20500000,16100000,17100000,47400000,faketimestampg,faketimestampg,faketimestampg][Math.floor(Math.random() * 8)];

	
				}});
				
				*/
				
				
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});




}());
			const chromeVersion = navigator.userAgent.match(/Chrom(e|ium)\/([0-9.]+)/)[2];

const userAgent = `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeVersion} Safari/537.36`;

(function () {
	
function processFunctions(scope) {

 scope.Object.defineProperty(navigator, "platform", {enumerable: true, configurable: true, get: function(){return ['Win32','Win32'][Math.floor(Math.random() * 2)] }});
	
		   	scope.Object.defineProperty(navigator, "vendor", {enumerable: true, configurable: true, get: function(){return ['Google Inc.','Google Inc.'][Math.floor(Math.random() * 2)] }});
				
		   	scope.Object.defineProperty(navigator, "userAgent", {enumerable: true, configurable: true, get: function(){return userAgent; }});
					   	scope.Object.defineProperty(navigator, "appName", {enumerable: true, configurable: true, get: function(){return 'Netscape'; }});
					   	scope.Object.defineProperty(navigator, "userAgent", {enumerable: true, configurable: true, get: function(){return userAgent; }});
				   	scope.Object.defineProperty(navigator, "appCodeName", {enumerable: true, configurable: true, get: function(){return 'Mozilla'; }});
					
					   	scope.Object.defineProperty(navigator, "productSub", {enumerable: true, configurable: true, get: function(){return '20030107' }});
					
					  	scope.Object.defineProperty(navigator, "vendorSub", {enumerable: true, configurable: true, get: function(){return ''; }});
					
				
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
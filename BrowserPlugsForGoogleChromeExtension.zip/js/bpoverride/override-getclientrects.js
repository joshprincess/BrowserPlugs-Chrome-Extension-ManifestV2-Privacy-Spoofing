		(function () {
			
			 
var injectrects = function () {
	
 Object.defineProperty(Element.prototype, "getClientRects", {
    "value": function () {
		   console.log('%c Browser Plug Firewall for Chrome has blocked getClientRects using Object.defineProperty on ' + window.location.host + '.', 'color: red; background-color: orange; border: 2px solid black; padding: 5px;');

 return [{
	 
'top': Math.floor(Math.random() * 25) - 5,
'bottom': Math.floor(Math.random() * 25) - 1,
'left': Math.floor(Math.random() * 25) - 3,
'right': Math.floor(Math.random() * 25) - 4,
'height': Math.floor(Math.random() * 100) - 5,
'width': Math.floor(Math.random() * 50) - 10
                    }];
    }
  })
  //

	
 document.documentElement.dataset.bpsecure = true;

}
  var script_1 = document.createElement('script');
script_1.textContent = "(" + injectrects + ")()";
document.documentElement.appendChild(script_1)



if (document.documentElement.dataset.bpsecure !== true) {
//console.log('document.documentElement.dataset.bpsecure trying iframe insert on ' window.location.hostname) 

 var script_2 = document.createElement('script');
  script_2.textContent = `{
    const iframes = window.document.querySelectorAll("iframe[sandbox]");
    for (var i = 0; i < iframes.length; i++) {
      if (iframes[i].contentWindow) {
        if (iframes[i].contentWindow.Element) {
          iframes[i].contentWindow.Element.prototype.getClientRects = Element.prototype['getClientRects'];
   
        }
      }
    }
  }`;
 
window.document.documentElement.appendChild(script_2);
  
}
  }());
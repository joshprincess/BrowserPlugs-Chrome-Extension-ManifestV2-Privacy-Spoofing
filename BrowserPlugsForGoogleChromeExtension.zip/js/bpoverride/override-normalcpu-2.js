(function () {

 document.addEventListener('DOMContentLoaded', function(event) { 
 var iFrames = document.getElementsByTagName('iframe');
               for (i=0; i<iFrames.length; i++) try { 
			   
			  Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'hardwareConcurrency', { value: 2 });
			  } catch(e) {
			  } });
              try { Object.defineProperty(clientInformation, 'hardwareConcurrency', { value: 2 }); } catch(e) {}
			  
			
			
			document.addEventListener('DOMContentLoaded', function(event) { var iFrames = document.getElementsByTagName('iframe');
			   for (i=0; i<iFrames.length; i++) try {
				   Object.defineProperty(iFrames[i].contentWindow.clientInformation, 'deviceMemory', { value: 8 }); 
				   } catch(e) {} });
			    try { 
				Object.defineProperty(clientInformation, 'deviceMemory', { value: 8 }); 
				} catch(e) {};
			
}());
	   const BR0WSERplugsGL2 = {
	    7936: 'WebKit', // Vendor
		7937: 'WebKit WebGL', // Renderer
		7938: 'WebGL 2.0 (OpenGL ES 3.0 Chromium)', // GL Version	
		37445: 'Google Inc.', // UNMASKED_VENDOR_WEBGL
        37446: 'Google SwiftShader', // UNMASKED_RENDERER_WEBGL
		35724: 'WebGL GLSL ES 3.00 (OpenGL ES GLSL ES 3.0 Chromium)', // Shading Language Version	
		34921: '32', // Max Vertex Attributes	  8-16
		36347: '256', // Max Vertex Uniform Vectors   128 - 4096
		35660: '16', // Max Vertex Texture Image Units    0 - 16
		36348: '32', // Max Varying Vectors	  8  - 32   Max Varying Vectors	
		35658: '1036', // Max Vertex Uniform Components
		35371: '12', // Max Vertex Uniform Blocks
		37154: '64', // Max Vertex Output Components
		35659: '128', // Max Varying Components
		35978: '64', // Max Interleaved Components
		35979: '4', //Max Separate Attribs
		35968: '64', //Max Separate Components
		33902: '[1, 1]', // Aliased Line Width Range	[1-1] minimum 1
		33901: '[0.125, 8192]', // Aliased Point Size Range [1, 1024] minimum 1
		36349: '224', // Max Fragment Uniform Vectors	 16 - 1024
		34930: '16', // Max Texture Image Units		 8 - 16
		34852: '8', // Max Draw Buffers
		36063: '8', // Max Color Attachments:	
		36183: '4', // Max Samples
		3410: '8', // Red bits
		3411: '8', // Green bits
		3412: '8', // Blue bits
		3413: '8', // Alpha bits
		3414: '24', // Depth bits
		3415: '8', // Stencil bits
		34024: '8192', // Max Render Buffer Size	
		3386: '[8192, 8192]', // Max Viewport Dimensions	
		3379: '8192', // Max Texture Size   64 - 16384
		34076: '8192', // Max Cube Map Texture Size	   16 - 16384
		35661: '32', // Max Combined Texture Image Units	8 - 32
		34047: '16', // Max Anisotropy	2 - 16
		32883: '8192', // Max 3D Texture Size:	
		35071: '8192', // Max Array Texture Layers
		34045: '12', // Max Texture LOD Bias
		35375: '24', // Max Uniform Buffer Bindings
		35376: '16384', // Max Uniform Block Size
		35380: '4', // Uniform Buffer Offset Alignment
		35374: '24', // Max Combined Uniform Blocks
		35377: '50188', // Max Combined Vertex Uniform Components
		35379: '50060' // Max Combined Fragment Uniform Components
    }
    
  
      var getBPugsGL = WebGL2RenderingContext.prototype.getParameter;
    WebGL2RenderingContext.prototype.getParameter = function (parameter) {
    if (BR0WSERplugsGL2[parameter])
            return BR0WSERplugsGL2[parameter]
        return getBPugsGL.apply(this, arguments)
   }; 
   
         var getBPugsGLx = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function (parameter) { 
    if (BR0WSERplugsGL2[parameter])
            return BR0WSERplugsGL2[parameter]
        return getBPugsGLx.apply(this, arguments)
   }; 
var inject = function(o) {
    const GMT = function(n) {
        const _format = function(v) {
            return (v < 10 ? '0' : '') + v
        };
        return (n <= 0 ? '+' : '-') + _format(Math.abs(n) / 60 | 0) + _format(Math.abs(n) % 60);
    };
    const resolvedOptions = Intl.DateTimeFormat()
        .resolvedOptions();
    const {
        getDay,
        getDate,
        getYear,
        getMonth,
        getHours,
        toString,
        getMinutes,
        getSeconds,
        getFullYear,
        toLocaleString,
        getMilliseconds,
        getTimezoneOffset,
        toLocaleTimeString,
        toLocaleDateString
    } = Date.prototype;
    Object.defineProperty(Date.prototype, 'getDay', {
        "value": function() {
            return getDay.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getDate', {
        "value": function() {
            return getDate.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getYear', {
        "value": function() {
            return getYear.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getTimezoneOffset', {
        "value": function() {
            return Number(o.value)
        }
    });
    Object.defineProperty(Date.prototype, 'getMonth', {
        "value": function() {
            return getMonth.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getHours', {
        "value": function() {
            return getHours.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getMinutes', {
        "value": function() {
            return getMinutes.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getSeconds', {
        "value": function() {
            return getSeconds.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getFullYear', {
        "value": function() {
            return getFullYear.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, '_offset', {
        "configurable": true,
        get() {
            return getTimezoneOffset.call(this)
        }
    });
    Object.defineProperty(Date.prototype, 'toLocaleString', {
        "value": function() {
            return toLocaleString.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'getMilliseconds', {
        "value": function() {
            return getMilliseconds.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'toLocaleTimeString', {
        "value": function() {
            return toLocaleTimeString.call(this._date)
        }
    });
    Object.defineProperty(Date.prototype, 'toLocaleDateString', {
        "value": function() {
            return toLocaleDateString.call(this._date)
        }
    });
    Object.defineProperty(Intl.DateTimeFormat.prototype, 'resolvedOptions', {
        "value": function() {
            return Object.assign(resolvedOptions, {
                "timeZone": o.name
            })
        }
    });
    Object.defineProperty(Date.prototype, '_date', {
        "configurable": true,
        get() {
            return this._nd === undefined ? new Date(this.getTime() + (this._offset - o.value) * 60 * 1000) : this._nd
        }
    });
    Object.defineProperty(Date.prototype, 'toString', {
        "value": function() {
            return toString.call(this._date)
                .replace(GMT(this._offset), GMT(o.value))
                .replace(/\(.*\)/, '(' + o.name.replace(/\//g, ' ') + ' Standard Time)')
        }
    });
    document.documentElement.dataset.datetimescriptallow = true;
};
var script_1 = document.createElement('script');
script_1.textContent = "(" + inject + ")(" + JSON.stringify(timeZone) + ")";
document.documentElement.appendChild(script_1);
if (document.documentElement.dataset.datetimescriptallow !== "true") {
    var script_2 = document.createElement('script');
    script_2.textContent = `{
    const iframes = window.top.document.querySelectorAll("iframe[sandbox]");
    for (var i = 0; i < iframes.length; i++) {
      if (iframes[i].contentWindow) {
        if (iframes[i].contentWindow.Intl.DateTimeFormat.prototype) {
          if (iframes[i].contentWindow.Intl.DateTimeFormat.prototype.resolvedOptions !== Intl.DateTimeFormat.prototype.resolvedOptions) {
            iframes[i].contentWindow.Intl.DateTimeFormat.prototype.resolvedOptions = Intl.DateTimeFormat.prototype.resolvedOptions;
          }
        }
        if (iframes[i].contentWindow.Date.prototype) {
          if (!iframes[i].contentWindow.Date.prototype._date) iframes[i].contentWindow.Date.prototype._date = Date.prototype._date;
          if (!iframes[i].contentWindow.Date.prototype._offset) iframes[i].contentWindow.Date.prototype._offset = Date.prototype._offset;
          if (iframes[i].contentWindow.Date.prototype.getDay !== Date.prototype.getDay) iframes[i].contentWindow.Date.prototype.getDay = Date.prototype.getDay;
          if (iframes[i].contentWindow.Date.prototype.getDate !== Date.prototype.getDate) iframes[i].contentWindow.Date.prototype.getDate = Date.prototype.getDate;
          if (iframes[i].contentWindow.Date.prototype.getYear !== Date.prototype.getYear) iframes[i].contentWindow.Date.prototype.getYear = Date.prototype.getYear;
          if (iframes[i].contentWindow.Date.prototype.getMonth !== Date.prototype.getMonth) iframes[i].contentWindow.Date.prototype.getMonth = Date.prototype.getMonth;
          if (iframes[i].contentWindow.Date.prototype.getHours !== Date.prototype.getHours) iframes[i].contentWindow.Date.prototype.getHours = Date.prototype.getHours;
          if (iframes[i].contentWindow.Date.prototype.toString !== Date.prototype.toString) iframes[i].contentWindow.Date.prototype.toString = Date.prototype.toString;
          if (iframes[i].contentWindow.Date.prototype.getMinutes !== Date.prototype.getMinutes) iframes[i].contentWindow.Date.prototype.getMinutes = Date.prototype.getMinutes;
          if (iframes[i].contentWindow.Date.prototype.getSeconds !== Date.prototype.getSeconds) iframes[i].contentWindow.Date.prototype.getSeconds = Date.prototype.getSeconds;
          if (iframes[i].contentWindow.Date.prototype.getFullYear !== Date.prototype.getFullYear) iframes[i].contentWindow.Date.prototype.getFullYear = Date.prototype.getFullYear;
          if (iframes[i].contentWindow.Date.prototype.toLocaleString !== Date.prototype.toLocaleString) iframes[i].contentWindow.Date.prototype.toLocaleString = Date.prototype.toLocaleString;
          if (iframes[i].contentWindow.Date.prototype.getMilliseconds !== Date.prototype.getMilliseconds) iframes[i].contentWindow.Date.prototype.getMilliseconds = Date.prototype.getMilliseconds;
          if (iframes[i].contentWindow.Date.prototype.getTimezoneOffset !== Date.prototype.getTimezoneOffset) iframes[i].contentWindow.Date.prototype.getTimezoneOffset = Date.prototype.getTimezoneOffset;
          if (iframes[i].contentWindow.Date.prototype.toLocaleTimeString !== Date.prototype.toLocaleTimeString) iframes[i].contentWindow.Date.prototype.toLocaleTimeString = Date.prototype.toLocaleTimeString;
          if (iframes[i].contentWindow.Date.prototype.toLocaleDateString !== Date.prototype.toLocaleDateString) iframes[i].contentWindow.Date.prototype.toLocaleDateString = Date.prototype.toLocaleDateString;
        }
      }
    }
  }`;
    window.top.document.documentElement.appendChild(script_2);
}

if (!window.ogcctxfunc8675309) {
 window.ogcctxfunc8675309 = Element.prototype.getClientRects;
 Element.prototype.getClientRects = function () {

    return [{
                        'top': 0,
                        'bottom': 0,
                        'left': 0,
                        'right': 0,
                        'height': 0,
                        'width': 0
                    }];
  };
   if document.location.hostname == "test.blank" {
   return window.ogcctxfunc8675309.call(this);
  } else {
   return window.ogcctxfunc8675309.call(this);
  };
 };
};
 const _nativeRemoveAttribute = Element.prototype.removeAttribute; 
 Element.prototype['removeAttribute'] = function(name) { 
   var myJSON = JSON.stringify(arguments);
  console.log('%c [BP Element Log] removeAttribute: ' + name, 'color: red; font-weight: bold;');
   return _nativeRemoveAttribute.apply(this, arguments);
 }; 
 
 
  const _nativeSetAttribute = Element.prototype.setAttribute; 
 Element.prototype['setAttribute'] = function(name, value) { 
      var myJSON = JSON.stringify(arguments);

     console.log('%c [BP Element Log] setAttribute: ' + name + ' Value: ' + value + ' Attributes: ' + myJSON, 'color: green; font-weight: bold;');
 return _nativeSetAttribute.apply(this, arguments);
 }; 
 
 
   const _nativegetClientRects = Element.prototype.getClientRects; 
 Element.prototype['getClientRects'] = function(name) { 
     console.log('%c [BP Element Log] getClientRects ' + name + ' ' + window.location.hostname, 'color: orange; font-weight: bold;');

 return _nativegetClientRects.apply(this, arguments); 

 }; 
 
 
  const _nativegetBoundingClientRect = Element.prototype.getBoundingClientRect; 
 Element.prototype['getBoundingClientRect'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Element Log] getBoundingClientRect: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');
return;
  /* return _nativegetBoundingClientRect.apply(this, arguments);*/
 }; 
 
 

  const _nativegetAttribute = Element.prototype.getAttribute; 
 Element.prototype.getAttribute = function(name, value) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Element Log] getAttribute: ' + name + ' Value: ' + value + ' Attributes: ' + myJSON, 'color: brown;');
return false;
  /*  return _nativegetAttribute.apply(this, arguments);*/
 }; 

 
 
 var __createElement = document.createElement;
var __eval = window.eval;
var __write = document.write;
 
document.createElement = function(name) {
   var myJSON = JSON.stringify(arguments);
console.log('%c [BP Document Log] createElement: ' + name + ' Attributes: ' + myJSON, 'color: brown;');
  
   if (name === 'iframe'||name === 'IFRAME')   
 return __createElement.apply(this, arguments);

    else
 return __createElement.apply(this, arguments);

}

document.write = function(name, value) {
   var myJSON = JSON.stringify(arguments);

console.log('%c [BP Document Log] Write: ' + name + ' value : ' + value + ' Attributes: ' + myJSON, 'color: red;');
  
   return __write.apply(this, arguments);

}
window.eval = function(name, value) {
    console.log('%c [BP Eval Log] Eval: ' + name + ' value : ' + value + ' Attributes: ' + myJSON, 'color: red;');

	if (name.indexOf('open') !== -1 || name.indexOf('window') !== -1 || name.indexOf('script') != -1) {
           console.log('%c [BP Eval Log Known] Eval: ' + name + ' value : ' + value + ' Attributes: ' + myJSON, 'color: red;');

        return;
    } else {
        return __eval.apply(this, arguments);
    }
}
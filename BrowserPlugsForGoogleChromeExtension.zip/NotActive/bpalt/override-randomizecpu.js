(function () {
	
function processFunctions(scope) {
	
 scope.Object.defineProperty(navigator, "hardwareConcurrency", {enumerable: true, configurable: true, get: function(){return ['1','2','4','6','8','2','2','2','2','2','2','2','2','2','2','2','2','2','1','8','8','16','32','10','2','2','2','2','2'][Math.floor(Math.random() * 29)] }});
 scope.Object.defineProperty(navigator, "deviceMemory", {enumerable: true, configurable: true, get: function(){return ['4','4','4','4','4','4','4','4','8','8','8','4','4','4','16','16','32','8','4','8','8','16','32','4','4','4','4','4','8'][Math.floor(Math.random() * 29)] }});
	 scope.Object.defineProperty(navigator, "platform", {enumerable: true, configurable: true, get: function(){return ['Win32','Win32'][Math.floor(Math.random() * 2)] }});
	 scope.Object.defineProperty(navigator, "language", {enumerable: true, configurable: true, get: function(){return ['en-US','en-US'][Math.floor(Math.random() * 2)] }});
	 	 scope.Object.defineProperty(navigator, "languages", {enumerable: true, configurable: true, get: function(){return ['en-US,en','en-US,en'][Math.floor(Math.random() * 2)] }});
				
		   
					
		   
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
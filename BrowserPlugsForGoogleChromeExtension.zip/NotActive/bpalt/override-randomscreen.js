(function () {
	
function processFunctions(scope) {
			
    scope.Object.defineProperty(window.screen, "width", {enumerable: true, configurable: true, get: function(){return 1366; }});
   scope.Object.defineProperty(window.screen, "height", {enumerable: true, configurable: true, get: function(){return 768; }});
 scope.Object.defineProperty(window, "availHeight", {enumerable: true, configurable: true, get: function(){return ['728','728'][Math.floor(Math.random() * 2)] }});
  scope.Object.defineProperty(window, "availWidth", {enumerable: true, configurable: true, get: function(){return ['1366','1366'][Math.floor(Math.random() * 2)] }});
  			
			scope.Object.defineProperty(window, "innerWidth", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-innerWidth';
					browserplugins_triggerblock.title = 'innerWidth';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return ['1366','1366','1366','1366','1366'][Math.floor(Math.random() * 5)];
				}});
				
					scope.Object.defineProperty(window, "innerHeight", {enumerable: true, configurable: true, get: function() {
					var browserplugins_triggerblock = scope.document.createElement('div');
					browserplugins_triggerblock.className = 'mfp_tbd_experimental-innerHeight';
					browserplugins_triggerblock.title = 'innerHeight';
					document.documentElement.appendChild(browserplugins_triggerblock);
						return ['768','768','768','768','768'][Math.floor(Math.random() * 5)];
				}});
				 scope.Object.defineProperty(window.screen, "colorDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
						
						  scope.Object.defineProperty(window.screen, "pixelDepth", {enumerable: true, configurable: true, get: function(){return 24; }});
		   
					 }
	processFunctions(window);
		var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'), idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
		Object.defineProperties(HTMLIFrameElement.prototype, {
			contentWindow: {
				get: function() {
					var frame = iwin.apply(this);
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return frame;
				}
			},
			contentDocument: {
				get: function() {
					if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
					var frame = iwin.apply(this);
					try { frame.HTMLCanvasElement } catch (err) { /* do nothing*/ }
					processFunctions(frame);
					return idoc.apply(this);
				}
			}
		});



	 
}());
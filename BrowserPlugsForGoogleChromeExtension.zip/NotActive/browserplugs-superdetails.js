 const _nativeRemoveAttribute = Element.prototype.removeAttribute; 
 Element.prototype['removeAttribute'] = function(name) { 
   var myJSON = JSON.stringify(arguments);
  console.log('%c [BP Super Log] removeAttribute: ' + name, 'color: red; font-weight: bold;');
   return _nativeRemoveAttribute.apply(this, arguments);
 }; 
 
  const _nativeSetAttribute = Element.prototype.setAttribute; 
 Element.prototype['setAttribute'] = function(name, value) { 
      var myJSON = JSON.stringify(arguments);

     console.log('%c [BP Super Log] setAttribute: ' + name + ' Value: ' + value + ' Attributes: ' + myJSON, 'color: green; font-weight: bold;');
 return _nativeSetAttribute.apply(this, arguments);
 }; 
 
   const _nativegetClientRects = Element.prototype.getClientRects; 
 Element.prototype['getClientRects'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Super Log] getClientRects: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');

 return _nativegetClientRects.apply(this, arguments);
 }; 
  const _nativegetBoundingClientRect = Element.prototype.getBoundingClientRect; 
 Element.prototype['getBoundingClientRect'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Super Log] getBoundingClientRect: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');

 return _nativegetBoundingClientRect.apply(this, arguments);
 }; 

  const _nativeclientHeight = Element.prototype.clientHeight; 
 Element.prototype['clientHeight'] = function(name) { 
      var myJSON = JSON.stringify(arguments);
     console.log('%c [BP Super Log] clientHeight: ' + name + ' Attributes: ' + myJSON, 'color: orange; font-weight: bold;');

 return _nativeclientHeight.apply(this, arguments);
 }; 

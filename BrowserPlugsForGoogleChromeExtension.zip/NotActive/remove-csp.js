chrome.webRequest.onHeadersReceived.addListener(
    function(details) {
        for (var i = 0; i < details.responseHeaders.length; ++i) {
            if (details.responseHeaders[i].name.toLowerCase()
                .indexOf('x-frame-options') > -1 ||
                details.responseHeaders[i].name.toLowerCase()
                .indexOf('strict-transport-security') > -1 ||
                details.responseHeaders[i].name.toLowerCase()
                .indexOf('x-xss-protection') > -1 ||
                details.responseHeaders[i].name.toLowerCase()
                .indexOf('content-security-policy') > -1 ||
                details.responseHeaders[i].name.toLowerCase()
                .indexOf('x-content-type-options') > -1) {
                details.responseHeaders.splice(i, 1);
            }
        }
        return {
            responseHeaders: details.responseHeaders
        };
    }, {
        urls: ["<all_urls>"]
    }, ["blocking", "responseHeaders"]);
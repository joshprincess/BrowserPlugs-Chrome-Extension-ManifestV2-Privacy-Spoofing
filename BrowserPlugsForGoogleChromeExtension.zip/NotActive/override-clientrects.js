(function () {
	
function processFunctions(scope) {
		
					
					
   var clientrects_triggerblock = scope.document.createElement('div');
                clientrects_triggerblock.className = 'scriptsafe_oiigbmnaadbkfbmpbfijlflahbdbdgdf_clientrects';
                Element.prototype.getClientRects = function() {
					clientrects_triggerblock.title = 'getClientRects';
                    document.documentElement.appendChild(clientrects_triggerblock);
                    return [{
                        'top': 0,
                        'bottom': 0,
                        'left': 0,
                        'right': 0,
                        'height': 0,
                        'width': 0
                    }];
                }
				
				  }
        processFunctions(window);
        var iwin = HTMLIFrameElement.prototype.__lookupGetter__('contentWindow'),
            idoc = HTMLIFrameElement.prototype.__lookupGetter__('contentDocument');
        Object.defineProperties(HTMLIFrameElement.prototype, {
            contentWindow: {
                get: function() {
                    var frame = iwin.apply(this);
                    if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return frame;
                    try {
                        frame.HTMLCanvasElement
                    } catch (err) { /* do nothing*/ }
                    processFunctions(frame);
                    return frame;
                }
            },
            contentDocument: {
                get: function() {
                    if (this.src && this.src.indexOf('//') != -1 && location.host != this.src.split('/')[2]) return idoc.apply(this);
                    var frame = iwin.apply(this);
                    try {
                        frame.HTMLCanvasElement
                    } catch (err) { /* do nothing*/ }
                    processFunctions(frame);
         			}
			}
		});



	 
}());
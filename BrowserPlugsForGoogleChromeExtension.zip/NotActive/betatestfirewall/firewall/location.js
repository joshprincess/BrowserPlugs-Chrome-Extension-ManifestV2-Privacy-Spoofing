Object.freeze(location);
